/**
 * Dior Medical - DocBooker Interactive Appointment Booking Modal Controller
 * Automatically detects HIPAAtizer form completions, manages service selection
 * (Video Visit / Phone Consultation), live slot availability, and dual-dashboard synchronization.
 */
(function() {
    'use strict';

    // State management
    window.diorDocBookerState = {
        doctorId: 1957,
        doctorName: 'Dr. Marcus Sterling, DO',
        serviceType: 'Video Visit (HD)',
        date: '',
        time: '09:00 AM - 10:00 AM',
        isSubmitting: false,
        cachedAvailability: {}
    };

    /**
     * The appointment modal only exists on a signed-in portal dashboard.
     *
     * The controller is enqueued only there, but the check is repeated here as
     * a second line of defence: if the markup is missing, or the visitor has no
     * portal session, nothing may auto-open. This is what previously let a
     * guest on Start Your Visit have the modal pop up after submitting the
     * HIPAAtizer form — the listener fired and diorOpenDocBookerModal() had a
     * site-wide modal to open.
     */
    function isPortalBookingContext() {
        if (!document.getElementById('dior-docbooker-modal')) {
            return false;
        }
        if (typeof dior_vars === 'undefined' || !dior_vars) {
            return false;
        }
        return parseInt(dior_vars.is_logged_in, 10) === 1;
    }

    /**
     * Open the DocBooker Booking Modal
     */
    window.diorOpenDocBookerModal = function(options) {
        options = options || {};
        var modal = document.getElementById('dior-docbooker-modal');
        if (!modal) {
            console.warn('[Dior Medical] Booking modal DOM not found.');
            return;
        }

        // Hard gate: no portal session, no modal. Everything else in this file
        // is already scoped to the dashboard, so this only ever blocks the
        // accidental case (a stray caller on a public page).
        if (!isPortalBookingContext()) {
            console.warn('[Dior Medical] Booking modal is portal-only; ignored.');
            return;
        }

        // Reset views
        var body = document.getElementById('dior-db-modal-body');
        var success = document.getElementById('dior-db-modal-success');
        var statusBox = document.getElementById('dior-db-status-box');
        if (body) body.style.display = 'block';
        if (success) success.style.display = 'none';
        if (statusBox) statusBox.style.display = 'none';

        // Pre-fill / update date
        var dateInput = document.getElementById('dior-db-date-input');
        var today = new Date().toISOString().split('T')[0];
        if (dateInput) {
            dateInput.min = today;
            if (!dateInput.value) {
                dateInput.value = today;
            }
            window.diorDocBookerState.date = dateInput.value;
        }

        // Pre-fill reason if passed or from options
        if (options.reason) {
            var notesInput = document.getElementById('dior-db-patient-notes');
            if (notesInput && !notesInput.value) {
                notesInput.value = options.reason;
            }
        }

        // Pre-fill patient details from global vars if available
        if (typeof dior_vars !== 'undefined' && dior_vars.patient_profile) {
            var p = dior_vars.patient_profile;
            var nameInput = document.getElementById('dior-db-patient-name');
            var emailInput = document.getElementById('dior-db-patient-email');
            var phoneInput = document.getElementById('dior-db-patient-phone');
            if (nameInput && !nameInput.value && p.full_name) nameInput.value = p.full_name;
            if (emailInput && !emailInput.value && p.email) emailInput.value = p.email;
            if (phoneInput && !phoneInput.value && p.phone) phoneInput.value = p.phone;
        }

        // Fetch live availability for current date
        if (window.diorDocBookerState.date) {
            window.diorFetchDocBookerAvailability(window.diorDocBookerState.date);
        }

        modal.style.display = 'flex';
        // Trigger reflow for CSS transition
        void modal.offsetHeight;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
    };

    /**
     * Close the DocBooker Booking Modal
     */
    window.diorCloseDocBookerModal = function() {
        var modal = document.getElementById('dior-docbooker-modal');
        if (!modal) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        setTimeout(function() {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }, 300);
    };

    /**
     * Service selection: Video Visit vs Phone Consultation
     */
    window.diorSelectServiceType = function(serviceType, el) {
        window.diorDocBookerState.serviceType = serviceType;

        var input = document.getElementById('dior-db-service-type');
        var inputFinal = document.getElementById('dior-db-final-type');
        if (input) input.value = serviceType;
        if (inputFinal) inputFinal.value = serviceType;

        // Toggle visual active state
        var cards = document.querySelectorAll('.dior-db-service-card');
        cards.forEach(function(c) { c.classList.remove('active'); });
        if (el) el.classList.add('active');
    };

    /**
     * Time slot selection
     */
    window.diorSelectTimeSlot = function(time, el) {
        if (el && el.disabled) return;
        window.diorDocBookerState.time = time;

        var timeInput = document.getElementById('dior-db-selected-time');
        var timeFinal = document.getElementById('dior-db-final-time');
        if (timeInput) timeInput.value = time;
        if (timeFinal) timeFinal.value = time;

        var buttons = document.querySelectorAll('.dior-db-slot-btn');
        buttons.forEach(function(b) { b.classList.remove('active'); });
        if (el) el.classList.add('active');
    };

    /**
     * Date changed callback
     */
    window.diorOnDateChanged = function(newDate) {
        window.diorDocBookerState.date = newDate;
        window.diorFetchDocBookerAvailability(newDate);
    };

    /**
     * Query DocBooker live availability for given date
     */
    window.diorFetchDocBookerAvailability = function(dateStr) {
        if (!dateStr) return;
        var spinner = document.getElementById('dior-db-slots-loading');
        var grid = document.getElementById('dior-db-slots-grid');
        if (spinner) spinner.style.display = 'inline-block';

        var restUrl = (typeof dior_vars !== 'undefined' && dior_vars.rest_url) || '/wp-json/';
        var restNonce = (typeof dior_vars !== 'undefined' && dior_vars.rest_nonce) || '';
        var apiUrl = restUrl + 'doctor-details-booking/v1/doctors/' + window.diorDocBookerState.doctorId + '/availability?date=' + encodeURIComponent(dateStr);

        fetch(apiUrl, {
            method: 'GET',
            headers: {
                'X-WP-Nonce': restNonce
            }
        })
        .then(function(res) {
            if (!res.ok) throw new Error('API returned ' + res.status);
            return res.json();
        })
        .then(function(data) {
            if (spinner) spinner.style.display = 'none';
            if (data && data.clinics && data.clinics.length > 0 && data.clinics[0].timings) {
                var timings = data.clinics[0].timings;
                window.diorRenderAvailableSlots(timings);
            }
        })
        .catch(function(err) {
            if (spinner) spinner.style.display = 'none';
            console.log('[Dior Medical] Using default DocBooker slots for ' + dateStr, err);
            // Default slots
            var defaultSlots = [
                { time: '09:00 AM - 10:00 AM', is_available: true },
                { time: '10:00 AM - 11:00 AM', is_available: true },
                { time: '11:00 AM - 12:00 PM', is_available: true },
                { time: '01:00 PM - 02:00 PM', is_available: true },
                { time: '02:00 PM - 03:00 PM', is_available: true },
                { time: '03:00 PM - 04:00 PM', is_available: true },
                { time: '04:00 PM - 05:00 PM', is_available: true }
            ];
            window.diorRenderAvailableSlots(defaultSlots);
        });
    };

    /**
     * Render slot buttons inside the grid
     */
    window.diorRenderAvailableSlots = function(timings) {
        var grid = document.getElementById('dior-db-slots-grid');
        if (!grid) return;
        grid.innerHTML = '';

        var firstAvailable = null;
        timings.forEach(function(item, idx) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'dior-db-slot-btn';
            btn.setAttribute('data-time', item.time);
            btn.textContent = item.time;

            if (item.is_available) {
                if (!firstAvailable) {
                    firstAvailable = item.time;
                    btn.classList.add('active');
                }
                btn.onclick = function() {
                    window.diorSelectTimeSlot(item.time, btn);
                };
            } else {
                btn.disabled = true;
                btn.classList.add('is-booked');
                btn.title = 'Slot Booked';
            }
            grid.appendChild(btn);
        });

        if (firstAvailable) {
            window.diorDocBookerState.time = firstAvailable;
            var timeInput = document.getElementById('dior-db-selected-time');
            var timeFinal = document.getElementById('dior-db-final-time');
            if (timeInput) timeInput.value = firstAvailable;
            if (timeFinal) timeFinal.value = firstAvailable;
        }
    };

    /**
     * Submit Booking Form
     */
    window.diorSubmitDocBookerBooking = function(e) {
        if (e && e.preventDefault) e.preventDefault();
        if (window.diorDocBookerState.isSubmitting) return false;

        var form = document.getElementById('dior-docbooker-form');
        var submitBtn = document.getElementById('dior-db-submit-btn');
        var statusBox = document.getElementById('dior-db-status-box');

        // Validation
        var nameInput = document.getElementById('dior-db-patient-name');
        var emailInput = document.getElementById('dior-db-patient-email');
        var phoneInput = document.getElementById('dior-db-patient-phone');
        var dateInput = document.getElementById('dior-db-date-input');

        if (!nameInput.value.trim() || !emailInput.value.trim() || !phoneInput.value.trim()) {
            if (statusBox) {
                statusBox.className = 'dior-db-alert alert-error';
                statusBox.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Please provide your full name, email address, and contact phone number.';
                statusBox.style.display = 'flex';
            }
            return false;
        }

        window.diorDocBookerState.isSubmitting = true;
        if (statusBox) statusBox.style.display = 'none';

        if (submitBtn) {
            submitBtn.disabled = true;
            var btnText = submitBtn.querySelector('.dior-db-btn-text');
            var btnSpinner = submitBtn.querySelector('.dior-db-btn-spinner');
            if (btnText) btnText.style.display = 'none';
            if (btnSpinner) btnSpinner.style.display = 'inline-block';
        }

        var formData = new FormData(form);
        // Ensure values match current state
        formData.set('type', window.diorDocBookerState.serviceType);
        formData.set('visit_type', window.diorDocBookerState.serviceType);
        formData.set('time', window.diorDocBookerState.time);
        formData.set('appt_time', window.diorDocBookerState.time);
        formData.set('date', dateInput.value);
        formData.set('appt_date', dateInput.value);
        formData.set('doctor_id', window.diorDocBookerState.doctorId);
        formData.set('doctorId', window.diorDocBookerState.doctorId);
        formData.set('provider', window.diorDocBookerState.doctorName);
        formData.set('doctor_name', window.diorDocBookerState.doctorName);

        var ajaxUrl = (typeof dior_vars !== 'undefined' && dior_vars.ajax_url) || '/wp-admin/admin-ajax.php';

        fetch(ajaxUrl, {
            method: 'POST',
            body: formData
        })
        .then(function(res) { return res.json(); })
        .then(function(res) {
            window.diorDocBookerState.isSubmitting = false;
            if (submitBtn) {
                submitBtn.disabled = false;
                var btnText = submitBtn.querySelector('.dior-db-btn-text');
                var btnSpinner = submitBtn.querySelector('.dior-db-btn-spinner');
                if (btnText) btnText.style.display = 'inline-block';
                if (btnSpinner) btnSpinner.style.display = 'none';
            }

            if (res.success) {
                // Populate Success screen
                var body = document.getElementById('dior-db-modal-body');
                var success = document.getElementById('dior-db-modal-success');
                if (body) body.style.display = 'none';
                if (success) success.style.display = 'block';

                var apptData = (res.data && res.data.appointment) || {};
                var apptUid = apptData.appt_uid || apptData.id || ('APT-' + Math.floor(1000 + Math.random() * 9000));

                var successUid = document.getElementById('dior-success-uid');
                var successType = document.getElementById('dior-success-service-type');
                var successDt = document.getElementById('dior-success-datetime');
                var successDoc = document.getElementById('dior-success-doc-name');

                if (successUid) successUid.textContent = apptUid;
                if (successType) successType.textContent = window.diorDocBookerState.serviceType;
                if (successDt) successDt.textContent = dateInput.value + ' at ' + window.diorDocBookerState.time;
                if (successDoc) successDoc.textContent = window.diorDocBookerState.doctorName;

                if (window.diorDocBookerState) {
                    window.diorDocBookerState.lastBookedDate = dateInput.value;
                }

                // Dynamically update dashboard elements if present on page
                window.diorInjectAppointmentIntoDashboards({
                    uid: apptUid,
                    appt_uid: apptUid,
                    doctor: window.diorDocBookerState.doctorName,
                    spec: 'Emergency Medicine & Telehealth Urgent Care',
                    date: dateInput.value,
                    time: window.diorDocBookerState.time,
                    type: window.diorDocBookerState.serviceType,
                    patientName: nameInput.value,
                    phone: phoneInput.value,
                    join_url: (apptData.join_url || apptData.meeting_url || ''),
                    notes: (apptData.notes || window.diorDocBookerState.serviceType || 'Telehealth Consultation')
                });

            } else {
                if (statusBox) {
                    statusBox.className = 'dior-db-alert alert-error';
                    statusBox.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + ((res.data && res.data.message) || 'Booking failed. Please try again.');
                    statusBox.style.display = 'flex';
                }
            }
        })
        .catch(function(err) {
            window.diorDocBookerState.isSubmitting = false;
            if (submitBtn) {
                submitBtn.disabled = false;
                var btnText = submitBtn.querySelector('.dior-db-btn-text');
                var btnSpinner = submitBtn.querySelector('.dior-db-btn-spinner');
                if (btnText) btnText.style.display = 'inline-block';
                if (btnSpinner) btnSpinner.style.display = 'none';
            }
            if (statusBox) {
                statusBox.className = 'dior-db-alert alert-error';
                statusBox.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Connection issue while booking appointment. Please try again.';
                statusBox.style.display = 'flex';
            }
            console.error('[Dior Medical] Booking error:', err);
        });

        return false;
    };

    /**
     * Injects the newly booked appointment into Patient Dashboard tables & cards in real-time
     */
    window.diorInjectAppointmentIntoDashboards = function(appt) {
        try {
            var todayYmd = new Date().toISOString().split('T')[0];
            var isToday = (appt.date === todayYmd);
            var tbodyToday = document.getElementById('dior-today-appointments-tbody');
            var tbodyUpcoming = document.getElementById('dior-upcoming-appointments-tbody');

            var apptUid = appt.uid || appt.appt_uid || ('APT-' + Math.floor(1000 + Math.random() * 9000));
            var joinUrl = appt.join_url || '';
            var nonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.meeting_nonce) || '';

            // Build 3 Action Icons:
            // 1. Join Zoom Meeting (video icon)
            // 2. Reschedule Appointment (calendar-alt icon)
            // 3. Cancel Appointment (times icon)
            var videoBtnHtml = '';
            if (joinUrl && joinUrl.indexOf('https://') === 0) {
                videoBtnHtml = '<a class="action-icon-btn edit-btn btn" href="' + joinUrl + '" data-dior-meeting-join data-appt-uid="' + apptUid + '" data-meeting-nonce="' + nonce + '" target="_blank" rel="noopener noreferrer" title="Join Zoom Meeting" aria-label="Join Zoom Meeting"><i class="fas fa-video text-success"></i></a>';
            } else {
                videoBtnHtml = '<button type="button" class="action-icon-btn edit-btn btn" disabled title="Meeting link unavailable" aria-label="Meeting link unavailable"><i class="fas fa-video text-muted"></i></button>';
            }

            var actionsHtml = '<div class="cell-actions">' +
                videoBtnHtml +
                '<button type="button" class="action-icon-btn edit-btn btn dior-today-reschedule" data-appt-uid="' + apptUid + '" data-appt-date="' + appt.date + '" data-appt-time="' + appt.time + '" title="Reschedule Appointment" aria-label="Reschedule Appointment"><i class="fas fa-calendar-alt"></i></button>' +
                '<button type="button" class="action-icon-btn delete-btn btn dior-today-cancel" data-appt-uid="' + apptUid + '" title="Cancel Appointment" aria-label="Cancel Appointment"><i class="fas fa-times"></i></button>' +
            '</div>';

            // 1. Row for Today\'s Table: DOCTOR, SPECIALIZATION, DATE, TIME, TREATMENT, CONTACT, STATUS, ACTIONS (8 cols)
            var todayRowHtml = '<tr class="dior-newly-added-row" style="background: #f0fdf4; transition: background 1.5s ease;">' +
                '<td><div class="cell-content cell-image-name"><span class="cell-text doctor-name" style="font-weight:700;">' + (appt.doctor || '') + '</span></div></td>' +
                '<td><span class="cell-text">' + (appt.spec || 'Emergency Medicine & Telehealth Urgent Care') + '</span></td>' +
                '<td><div class="cell-content cell-icon-text"><i class="far fa-calendar cell-icon"></i><span class="cell-text">' + (appt.date || '') + '</span></div></td>' +
                '<td><span class="cell-text" style="font-weight:600;">' + (appt.time || '') + '</span></td>' +
                '<td><span class="cell-text" style="color:#d4af37; font-weight:600;">' + (appt.type || 'Video Visit (HD)') + '</span></td>' +
                '<td><span class="cell-text">' + (appt.phone || 'On file') + '</span></td>' +
                '<td><span class="status-cell-text status-confirm" style="background:#d1fae5; color:#047857; font-weight:700; padding:4px 8px; border-radius:6px;">Confirmed</span></td>' +
                '<td class="dior-ic-d5c209e67c">' + actionsHtml + '</td>' +
            '</tr>';

            // 2. Row for Upcoming Table: Checkbox, DOCTOR, DATE, TIME, INJURY, STATUS, NOTES, ACTIONS (8 cols)
            var upcomingRowHtml = '<tr class="dior-newly-added-row" style="background: #f0fdf4; transition: background 1.5s ease;">' +
                '<td class="dior-ic-d5c209e67c"><input type="checkbox" class="master-checkbox upcoming-row-checkbox form-check-input" onclick="diorUpdateUpcomingSelectedCount()"></td>' +
                '<td><span class="cell-text doctor-name" style="font-weight:700;">' + (appt.doctor || '') + '</span></td>' +
                '<td><div class="cell-content cell-icon-text"><i class="far fa-calendar cell-icon"></i><span class="cell-text">' + (appt.date || '') + '</span></div></td>' +
                '<td><span class="cell-text" style="font-weight:600;">' + (appt.time || '') + '</span></td>' +
                '<td><span class="cell-text">' + (appt.type || 'Video Visit (HD)') + '</span></td>' +
                '<td><span class="status-cell-text status-upcoming" style="background:#e0e7ff; color:#3730a3; font-weight:700; padding:4px 8px; border-radius:6px;">Confirmed</span></td>' +
                '<td><span class="cell-text notes-text">' + (appt.notes || '—') + '</span></td>' +
                '<td class="dior-ic-d5c209e67c">' + actionsHtml + '</td>' +
            '</tr>';

            if (isToday && tbodyToday) {
                tbodyToday.insertAdjacentHTML('afterbegin', todayRowHtml);
                var countToday = document.getElementById('dior-today-page-count');
                if (countToday) {
                    var currentTotal = parseInt(countToday.textContent.replace(/[^0-9]/g, ''), 10) || 0;
                    countToday.textContent = '0 selected / ' + (currentTotal + 1) + ' total';
                }
            }

            if (tbodyUpcoming) {
                tbodyUpcoming.insertAdjacentHTML('afterbegin', upcomingRowHtml);
                var countUpcoming = document.getElementById('dior-upcoming-page-count');
                if (countUpcoming) {
                    var currentUpTotal = parseInt(countUpcoming.textContent.replace(/[^0-9]/g, ''), 10) || 0;
                    countUpcoming.textContent = '0 selected / ' + (currentUpTotal + 1) + ' total';
                }
            }

            // Keep in-memory appointment data synced
            var memAppt = {
                id: apptUid,
                appt_uid: apptUid,
                doc: appt.doctor,
                doctor: appt.doctor,
                spec: appt.spec || 'Emergency Medicine & Telehealth Urgent Care',
                date: appt.date,
                ymd: appt.date,
                time: appt.time,
                type: appt.type || 'Video Visit (HD)',
                status: 'Confirmed',
                join_url: joinUrl,
                notes: appt.notes || '—'
            };
            if (Array.isArray(window.dior_patient_appts_data)) window.dior_patient_appts_data.unshift(memAppt);
            if (Array.isArray(window.dior_inline_appts_data)) window.dior_inline_appts_data.unshift(memAppt);
            if (window.dior_patient_dashboard && Array.isArray(window.dior_patient_dashboard.appointments)) {
                window.dior_patient_dashboard.appointments.unshift(memAppt);
            }

            // 2. Increment Overview Counters
            var statCards = document.querySelectorAll('.stat-card .stat-num');
            if (statCards.length >= 2) {
                var totalEl = statCards[0];
                var upEl = statCards[1];
                if (totalEl) {
                    var curT = parseInt(totalEl.textContent, 10) || 0;
                    totalEl.textContent = String(curT + 1).padStart(2, '0');
                }
                if (upEl) {
                    var curU = parseInt(upEl.textContent, 10) || 0;
                    upEl.textContent = String(curU + 1).padStart(2, '0');
                }
            }

            // 3. Update Next Appointment Card in Overview
            var nextDocName = document.querySelector('.hero-appointment-card .doctor-name');
            var nextDocDate = document.querySelector('.hero-appointment-card .appointment-date');
            if (nextDocName) nextDocName.textContent = appt.doctor;
            if (nextDocDate) nextDocDate.textContent = appt.date + ' at ' + appt.time;

        } catch (err) {
            console.error('[Dior Medical] Live DOM update warning:', err);
        }
    };

    /**
     * Called when user clicks "View in Appointments Tab" from success screen
     */
    window.diorOnBookingSuccessDone = function() {
        window.diorCloseDocBookerModal();
        var todayYmd = new Date().toISOString().split('T')[0];
        var targetSub = (window.diorDocBookerState && window.diorDocBookerState.lastBookedDate === todayYmd) ? 'today' : 'upcoming';
        if (typeof diorSwitchTab === 'function') {
            diorSwitchTab('appointments');
            if (typeof diorSwitchApptSubTab === 'function') {
                diorSwitchApptSubTab(targetSub);
            }
        } else {
            window.location.hash = '#tab=appointments';
            window.location.reload();
        }
    };

    /**
     * HIPAAtizer completion detection.
     *
     * The intake form is a multi-step workflow. While the patient walks through
     * it, HIPAAtizer posts progress messages (`submitted`, `form_submitted`,
     * `stepCompleted`, plain strings) for every step that is saved. The booking
     * modal may only appear once the WHOLE intake is finished, so progress
     * messages must never count as a completion.
     *
     * Matching is therefore an allowlist of terminal events only — never a
     * substring search, and never a bare `submitted`, which a single step also
     * emits.
     */
    var HIPAATIZER_ORIGINS = [
        'https://app.hipaatizer.com',
        'https://www.hipaatizer.com',
        'https://hipaatizer.com'
    ];

    var HIPAATIZER_COMPLETE_EVENTS = [
        'submitSuccess',
        'workflowSubmitted',
        'formCompleted',
        'submissionSuccess'
    ];

    // A completion redirect is the url the workflow sends the browser to after
    // the final step; a step save never carries one.
    var HIPAATIZER_COMPLETE_REDIRECT = /(intake_completed|intake=success|submitted=1|booking=1)/i;

    // One completion may arrive two or three times: the page renders two copies
    // of the form (the tab form and the hidden footer source), and each renderer
    // can post the same message. Open the modal for the first one only.
    var hipaatizerCompletionHandled = false;

    /**
     * Which form instance sent this message?
     *
     * The dashboard renders the SAME workflow twice: the real form on the Book
     * Appointment tab (#dior-hipaa-tab-form) and a hidden copy in the footer
     * (#dior-hipaatizer-form-source-v17) that exists only as the markup source
     * for the intake popup. Both renderers are live, so both post messages.
     *
     * Only the instance the patient is actually looking at may drive the UI:
     * the visible tab form, or the footer form after it has been relocated into
     * the popup slot (the popup MOVES that node, so it leaves the footer and
     * loses its id — the depth check is what identifies it there).
     *
     * A chatty hidden renderer can therefore never open the booking modal.
     */
    function isVisibleHipaatizerForm(event) {
        var frame = null;
        try {
            frame = event.source && event.source.frameElement ? event.source.frameElement : null;
        } catch (e) {
            return true;    // cross-origin frameElement access → fall through
        }
        if (!frame || !frame.closest) {
            return true;    // not posted from a framed renderer
        }

        // Inside the real tab form.
        if (frame.closest('#dior-hipaa-tab-form')) return true;

        // Inside the hidden footer copy: depth 1 means it is still the footer
        // source and the patient is not looking at it.
        var inSource = frame.closest('#dior-hipaatizer-form-source-v17');
        if (inSource) return inSource.parentElement === document.body;

        return true;
    }

    function isHipaatizerOrigin(event) {
        // Same-origin posts (some renderers proxy through the parent page).
        try {
            if (event.origin === window.location.origin) return true;
        } catch (e) { /* ignore */ }
        return HIPAATIZER_ORIGINS.indexOf(event.origin) !== -1;
    }

    function hipaatizerEventName(d) {
        if (!d) return '';
        if (typeof d === 'string') return d.trim();
        if (typeof d === 'object') {
            return String(d.type || d.event || d.action || d.name || d.message || '').trim();
        }
        return '';
    }

    function isHipaatizerCompletion(d) {
        if (!d) return false;

        // A plain string is only ever a step/progress message ("submitted",
        // "form_submitted"). It is never treated as a completion.
        if (typeof d === 'string') {
            try { d = JSON.parse(d); } catch (e) { return false; }
            if (typeof d === 'string') return false;
        }

        if (typeof d !== 'object') return false;

        var name = hipaatizerEventName(d);
        if (name && HIPAATIZER_COMPLETE_EVENTS.indexOf(name) !== -1) return true;

        // An explicit terminal NAME above wins even if the payload also carries
        // a step number: a real final submit may report which step it closed.
        // Only the weaker flag-based detection below has to reject step payloads,
        // because a step save can carry `completed: true` ("this step is done")
        // and that must never read as "the whole workflow is done".
        if (/step/i.test(name)) return false;
        if (d.step !== undefined && d.step !== null && d.step !== '') return false;

        // Unambiguous "whole workflow finished" flags only. Bare `completed`
        // is deliberately NOT accepted: it is exactly the ambiguous word a
        // step save uses.
        if (d.isComplete === true || d.isFinal === true ||
            d.workflowComplete === true || d.isWorkflowComplete === true) return true;

        // Final-step redirect url.
        if (typeof d.url === 'string' && HIPAATIZER_COMPLETE_REDIRECT.test(d.url)) return true;
        if (typeof d.redirect === 'string' && HIPAATIZER_COMPLETE_REDIRECT.test(d.redirect)) return true;

        return false;
    }

    /**
     * Shared completion detector — the single source of truth.
     *
     * Answers "is this postMessage a FINISHED intake?" using the origin
     * allowlist, the visible-instance check and the terminal-event match, and
     * latches so one completion is reported exactly once. Other dashboard
     * scripts (dior-dashboard.js) call this instead of keeping their own copy
     * of the rules, so the screens can never disagree about what counts as
     * finished.
     */
    // The latched event OBJECT, not a boolean: several listeners receive the
    // very same MessageEvent, and each of them still has to act on it once. A
    // second, later event — the duplicate renderer's copy, or a retry — is
    // rejected because it is a different object.
    var hipaatizerCompletionEvent = null;

    window.diorHipaatizerCompletion = function (event) {
        if (!event || !event.data) return false;

        // Already accepted this exact event: let the remaining listeners run.
        if (event === hipaatizerCompletionEvent) return true;

        if (!isHipaatizerOrigin(event)) return false;
        if (!isVisibleHipaatizerForm(event)) return false;
        if (!isHipaatizerCompletion(event.data)) return false;

        // A completion was already accepted; this is a duplicate. Drop it.
        if (hipaatizerCompletionEvent !== null) return false;

        hipaatizerCompletionEvent = event;
        return true;
    };

    /**
     * Automatic HIPAAtizer Listener
     * Listens to cross-origin iframe postMessage events from HIPAAtizer renderer
     */
    window.addEventListener('message', function(event) {
        // Guests, and any page without the dashboard modal, must never react to
        // a HIPAAtizer postMessage — the guest intake form is submitted on the
        // public Start Your Visit page and nothing may open there.
        if (!isPortalBookingContext()) return;

        if (!event || !event.data) return;

        // ------------------------------------------------------------------
        // TEMPORARY DIAGNOSTIC — remove once the live payload is confirmed.
        //
        // The terminal event name of the configured workflow cannot be verified
        // from source code. Run the intake with ?dior_hipaa_debug=1 in the url
        // and every postMessage HIPAAtizer sends is logged with its origin, the
        // step the patient is on, and whether our matcher would treat it as a
        // completion. Only the intended final Submit may read "completion=YES".
        // Silent unless the query flag is present.
        // ------------------------------------------------------------------
        try {
            if (/(^|[?&])dior_hipaa_debug=1/.test(window.location.search || '')) {
                var probeOrigin = event.origin;
                var probeData = event.data;
                console.log(
                    '%c[HIPAAtizer probe] origin=' + probeOrigin +
                    ' data=' + (function () {
                        try { return typeof probeData === 'string' ? probeData : JSON.stringify(probeData); }
                        catch (e) { return String(probeData); }
                    })(),
                    'color:#0a7;font-weight:600'
                );
                console.log('[HIPAAtizer probe] completion=' +
                    (isHipaatizerCompletion(probeData) ? 'YES' : 'no') +
                    ' | name=' + hipaatizerEventName(probeData));
            }
        } catch (probeErr) {}


        // Origin, visible instance, terminal event and the open-once latch are
        // all decided in one place so every screen agrees on what "finished"
        // means. Step saves fail this check and are ignored.
        if (!window.diorHipaatizerCompletion(event)) return;

        var d = event.data;
        console.log('[Dior Medical] ✨ HIPAAtizer Intake Completion detected:', d);

        // 1. Close any open intake popup / modal first
        if (typeof window.diorCloseHipaaModal === 'function') {
            window.diorCloseHipaaModal();
        }
        if (typeof window.diorCloseModal === 'function') {
            window.diorCloseModal('modal-book-appointment');
        }
        if (typeof Swal !== 'undefined' && Swal.isVisible && Swal.isVisible()) {
            Swal.close();
        }

        // 2. Open DocBooker Appointment Booking Modal
        setTimeout(function() {
            window.diorOpenDocBookerModal({
                reason: 'Telehealth Intake Completed'
            });
        }, 450);
    });

    /**
     * Check if current URL/hash indicates the modal should auto-open (e.g. from HIPAAtizer redirection)
     */
    function shouldAutoOpenBookingModal() {
        var s = (window.location.search || '').toLowerCase();
        var h = (window.location.hash || '').toLowerCase();
        var combined = s + '&' + h;
        return (
            combined.indexOf('open_booking=1') !== -1 ||
            combined.indexOf('book=1') !== -1 ||
            combined.indexOf('booking=1') !== -1 ||
            combined.indexOf('open_docbooker=1') !== -1 ||
            combined.indexOf('docbooker=1') !== -1 ||
            h.indexOf('book-appointment') !== -1 ||
            h.indexOf('open-booking') !== -1 ||
            h.indexOf('book-visit-modal') !== -1
        );
    }

    function checkAndAutoOpenModal() {
        // Never auto-open for a guest or on a page without the dashboard modal.
        if (!isPortalBookingContext()) return;

        if (shouldAutoOpenBookingModal()) {
            if (typeof diorSwitchTab === 'function') {
                try { diorSwitchTab('appointments'); } catch (e) {}
            }
            setTimeout(function() {
                window.diorOpenDocBookerModal({
                    reason: 'HIPAAtizer Intake Completed'
                });
            }, 400);
        }
    }

    // Initialize auto-listeners on DOM ready and on hashchange
    document.addEventListener('DOMContentLoaded', function() {
        checkAndAutoOpenModal();

        // Delegate clicks for any button with data-action="open-docbooker" or .dior-open-docbooker-btn
        document.body.addEventListener('click', function(e) {
            var btn = e.target.closest('[data-action="open-docbooker"], .dior-open-docbooker-btn');
            if (btn) {
                e.preventDefault();
                window.diorOpenDocBookerModal();
            }
        });
    });

    window.addEventListener('hashchange', function() {
        checkAndAutoOpenModal();
    });

})();
