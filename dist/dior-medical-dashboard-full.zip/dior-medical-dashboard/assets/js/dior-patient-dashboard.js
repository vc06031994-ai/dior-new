/**
 * Dior Medical — Patient Dashboard page-specific JavaScript.
 * Extracted from the dashboard template without changing existing behavior.
 */

/* ------------------------------------------------------------------
 * Shared pager for every patient dashboard table.
 * Renders the exact same markup as the Doctor Dashboard pager
 * (.dior-page-btn: prev / numbers / next) so both dashboards share
 * one visual language: light square buttons + blue active page.
 * ------------------------------------------------------------------ */
/* ------------------------------------------------------------------
 * Submenu-parent detection.
 * A nav row that owns a submenu (the patient's "Appointments") must never
 * take the .active fill — the Doctor Dashboard's parent row does not, and
 * the fill was the stray background to remove. Declared at top level so it
 * is available to the very first function that needs it; it previously sat
 * inside diorSwitchApptSubTab's own body and threw ReferenceError, which
 * killed the sub-tab switching entirely.
 * ------------------------------------------------------------------ */
function diorIsSubmenuParentBtn(btn) {
    if (!btn) return false;
    if (btn.classList.contains('submenu-btn')) return false;
    return !!(btn.closest('.dior-nav-item-has-children') ||
              btn.closest('.dior-nav-item.has-submenu'));
}

function diorPagerChevron(direction) {
    return '<i class="fa-solid fa-chevron-' + direction + ' dior-pager-chevron"></i>';
}

function diorBuildPagerHtml(currentPage, totalPages, goFunctionName) {
    if (!totalPages || totalPages < 2) {
        return '';
    }

    var html = '';

    html += '<button type="button" class="dior-page-btn" ' + (currentPage <= 1 ? 'disabled' : '') +
        ' onclick="' + goFunctionName + '(' + (currentPage - 1) + ')" title="Previous Page">' +
        diorPagerChevron('left') + '</button>';

    if (totalPages <= 7) {
        for (var i = 1; i <= totalPages; i++) {
            html += '<button type="button" class="dior-page-btn' + (i === currentPage ? ' active' : '') +
                '" onclick="' + goFunctionName + '(' + i + ')">' + i + '</button>';
        }
    } else {
        for (var j = 1; j <= totalPages; j++) {
            if (j === 1 || j === totalPages || (j >= currentPage - 1 && j <= currentPage + 1)) {
                html += '<button type="button" class="dior-page-btn' + (j === currentPage ? ' active' : '') +
                    '" onclick="' + goFunctionName + '(' + j + ')">' + j + '</button>';
            } else if (j === currentPage - 2 || j === currentPage + 2) {
                html += '<span class="dior-pager-gap">...</span>';
            }
        }
    }

    html += '<button type="button" class="dior-page-btn" ' + (currentPage >= totalPages ? 'disabled' : '') +
        ' onclick="' + goFunctionName + '(' + (currentPage + 1) + ')" title="Next Page">' +
        diorPagerChevron('right') + '</button>';

    return html;
}

// --- Extracted dashboard script 1 ---
let diorBookingState = {
                departmentId: null,
                departmentName: null,
                doctorId: null,
                doctorName: null,
                date: null,
                day: null,
                clinicId: null,
                time: null,
                patient: {
                    name: (window.dior_patient_dashboard && window.dior_patient_dashboard.patient ? window.dior_patient_dashboard.patient.name : ''),
                    email: (window.dior_patient_dashboard && window.dior_patient_dashboard.patient ? window.dior_patient_dashboard.patient.email : ''),
                    phone: (window.dior_patient_dashboard && window.dior_patient_dashboard.patient ? window.dior_patient_dashboard.patient.phone : ''),
                    notes: ""
                }
            };

            const diorRestUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.rest_url) || (window.dior_vars && window.dior_vars.rest_url) || '';
            const diorAjaxUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '';
            const diorRestNonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.rest_nonce) || (window.dior_vars && window.dior_vars.rest_nonce) || '';
            const diorPortalNonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.portal_nonce) || (window.dior_vars && window.dior_vars.nonce) || '';

            document.addEventListener('DOMContentLoaded', function () {
    const patientAppointmentForm = document.getElementById('dior-patient-appointment-form');
    if (patientAppointmentForm) {
        patientAppointmentForm.addEventListener('submit', function (event) {
            event.preventDefault();
            diorSubmitPatientAppointmentForm(this);
        });
    }

    // Mark patient notifications read using the existing secured AJAX endpoint.
    document.addEventListener('click', function (e) {
        const button = e.target.closest('.dior-mark-notification-read');
        if (!button) return;
        const notificationId = button.getAttribute('data-notif-id');
        if (!notificationId) return;
        const body = new URLSearchParams({
            action: 'dior_patient_mark_notification_read',
            nonce: diorPortalNonce,
            notif_id: notificationId
        });
        fetch(diorAjaxUrl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (data && data.success) {
                    const row = button.closest('tr');
                    if (row) {
                        const statusCell = row.querySelector('.dior-dyn-status');
                        if (statusCell) {
                            statusCell.textContent = 'Read';
                            statusCell.className = 'dior-dyn-status dior-dyn-bg-D1FAE5 dior-dyn-color-10B981';
                        }
                        button.remove();
                    }
                    if (typeof diorRenderNotifPagination === 'function') {
                        diorRenderNotifPagination();
                    }
                }
            })
            .catch(function () {});
    });
                diorFetchTreatments();
            });

            function diorBookingGoToStep(step) {
                document.querySelectorAll('.booking-step').forEach(el => el.style.display = 'none');
                document.getElementById('step-' + step + (step === 1 ? '-treatment' : (step === 2 ? '-doctor' : (step === 3 ? '-time' : '-confirm')))).style.display = 'block';
            }

            function diorFetchTreatments() {
                fetch(diorRestUrl + 'get-doctor/v1/departments')
                    .then(res => res.json())
                    .then(data => {
                        let html = '';
                        if (data && data.length) {
                            data.forEach(dept => {
                                html += `<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(${dept.id}, '${dept.name.replace(/'/g, "\\'")}')">${dept.name}</button>`;
                    });
                } else {
                    html = '<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(1, \'Urgent Care Telehealth\')">Urgent Care Telehealth</button><button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(2, \'Primary Care & General Medicine\')">Primary Care</button>';
                }
                let el = document.getElementById('treatments-list');
                if (el) el.innerHTML = html;
            })
            .catch(() => {
                let el = document.getElementById('treatments-list');
                if (el) el.innerHTML = '<button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(1, \'Urgent Care Telehealth\')">Urgent Care Telehealth</button><button type="button" class="dior-grid-btn" onclick="diorSelectTreatment(2, \'Primary Care & General Medicine\')">Primary Care</button>';
            });
    }

    function diorSelectTreatment(id, name) {
        diorBookingState.departmentId = id;
        diorBookingState.departmentName = name;
        document.getElementById('doctors-list').innerHTML = '<p>Loading doctors...</p>';
        diorBookingGoToStep(2);

        fetch(diorRestUrl + 'get-doctor-by-departments/v1/' + id)
            .then(res => res.json())
            .then(data => {
                let html = '';
                if (data && data.length) {
                    data.forEach(doc => {
                        html += `<div class="dior-doctor-card-select" onclick="diorSelectDoctor(${doc.id}, '${doc.name.replace(/'/g, "\\'")}')">
                                                                            <h4>${doc.name}</h4>
                                                                            <p>${doc.speciality}</p>
                                                                        </div>`;
                    });
                } else {
                    html = `<div class="dior-doctor-card-select" onclick="diorSelectDoctor(1695, 'Dr. James Chen, DO')">
                                                                        <h4>Dr. James Chen, DO</h4>
                                                                        <p>Primary Care & Urgent Care</p>
                                                                    </div>
                                                                    <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1693, 'Dr. Marcus Sterling, DO')">
                                                                        <h4>Dr. Marcus Sterling, DO</h4>
                                                                        <p>Urgent Care Physician</p>
                                                                    </div>`;
                }
                document.getElementById('doctors-list').innerHTML = html;
            })
            .catch(() => {
                document.getElementById('doctors-list').innerHTML = `
                                                            <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1695, 'Dr. James Chen, DO')">
                                                                <h4>Dr. James Chen, DO</h4>
                                                                <p>Primary Care & Urgent Care</p>
                                                            </div>
                                                            <div class="dior-doctor-card-select" onclick="diorSelectDoctor(1693, 'Dr. Marcus Sterling, DO')">
                                                                <h4>Dr. Marcus Sterling, DO</h4>
                                                                <p>Urgent Care Physician</p>
                                                            </div>`;
            });
    }

    function diorSelectDoctor(id, name) {
        diorBookingState.doctorId = id;
        diorBookingState.doctorName = name;
        document.getElementById('time-slots-list').innerHTML = '';
        document.getElementById('booking-date').value = '';
        diorBookingGoToStep(3);
    }

    function diorFetchAvailability() {
        let dateStr = document.getElementById('booking-date').value;
        if (!dateStr) return;

        document.getElementById('time-slots-list').innerHTML = '<p>Loading availability...</p>';
        diorBookingState.date = dateStr;

        function renderDefaultTimes() {
            const defaultTimes = ['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'];
            let h = '<h4>Available Telehealth Slots</h4><div class="dior-time-grid">';
            defaultTimes.forEach(t => {
                h += `<button type="button" class="dior-time-btn" onclick="diorSelectTime(1, '${t}')">${t}</button>`;
            });
            h += '</div>';
            document.getElementById('time-slots-list').innerHTML = h;
        }

        fetch(diorRestUrl + `doctor-details-booking/v1/doctors/${diorBookingState.doctorId}/availability?date=${dateStr}`, {
            headers: { 'X-WP-Nonce': diorRestNonce }
        })
            .then(res => res.json())
            .then(data => {
                let html = '';
                if (data && data.clinics && data.clinics.length > 0) {
                    diorBookingState.day = data.day;
                    data.clinics.forEach(clinic => {
                        if (!clinic.is_on_holiday && clinic.timings && clinic.timings.length > 0) {
                            html += `<h4>${clinic.name}</h4><div class="dior-time-grid">`;
                            clinic.timings.forEach(timing => {
                                if (timing.is_available) {
                                    html += `<button type="button" class="dior-time-btn" onclick="diorSelectTime(${clinic.id}, '${timing.time}')">${timing.time}</button>`;
                                } else {
                                    html += `<button type="button" class="dior-time-btn disabled" disabled>${timing.time}</button>`;
                                }
                            });
                            html += `</div>`;
                        }
                    });
                }
                if (html) {
                    document.getElementById('time-slots-list').innerHTML = html;
                } else {
                    renderDefaultTimes();
                }
            })
            .catch(() => {
                renderDefaultTimes();
            });
    }

    function diorSelectTime(clinicId, time) {
        diorBookingState.clinicId = clinicId;
        diorBookingState.time = time;

        document.getElementById('booking-summary').innerHTML = `
                                                    <p><strong>Treatment:</strong> ${diorBookingState.departmentName || 'Telehealth Urgent Care'}</p>
                                                    <p><strong>Doctor:</strong> ${diorBookingState.doctorName || 'Attending Physician'}</p>
                                                    <p><strong>Date:</strong> ${diorBookingState.date}</p>
                                                    <p><strong>Time:</strong> ${diorBookingState.time}</p>
                                                    <p><strong>Patient:</strong> ${diorBookingState.patient.name || 'Verified Patient'}</p>
                                                `;
        diorBookingGoToStep(4);
    }

    function diorSubmitPatientAppointmentForm(form) {
        const message = document.getElementById('dior-patient-appointment-message');
        const submitButton = form.querySelector('button[type="submit"]');
        const formData = new FormData(form);
        const doctor = formData.get('doctor') || '';
        const time = formData.get('timeSlot') || '';
        const injury = formData.get('injury') || '';
        const note = formData.get('note') || '';

        if (!doctor || !formData.get('doa') || !time) {
            message.className = 'dior-form-message is-error';
            message.textContent = 'Please select the doctor, appointment date and time slot.';
            return;
        }

        submitButton.disabled = true;
        submitButton.textContent = 'Submitting...';
        message.className = 'dior-form-message';
        message.textContent = '';

        const request = new FormData();
        request.append('action', 'dior_patient_book_appointment');
        request.append('nonce', diorPortalNonce);
        request.append('name', [formData.get('first'), formData.get('last')].filter(Boolean).join(' '));
        request.append('email', formData.get('email') || '');
        request.append('phone', formData.get('mobile') || '');
        request.append('doctor_name', doctor);
        request.append('doctor', doctor);
        request.append('date', formData.get('doa') || '');
        request.append('time', time);
        request.append('condition', injury || 'Consultation');
        request.append('notes', note);
        request.append('type', 'Consultation');

        const reportFile = form.querySelector('input[name="uploadFile"]')?.files?.[0];
        if (reportFile) {
            request.append('uploadFile', reportFile, reportFile.name);
        }

        fetch(diorAjaxUrl, { method: 'POST', body: request })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    throw new Error((data.data && data.data.message) || data.message || 'Unable to book the appointment.');
                }
                message.className = 'dior-form-message is-success';
                message.textContent = (data.data && data.data.message) || 'Appointment booked successfully.';
                form.reset();
                setTimeout(() => window.location.reload(), 900);
            })
            .catch(error => {
                message.className = 'dior-form-message is-error';
                message.textContent = error.message || 'Unable to book the appointment. Please try again.';
                submitButton.disabled = false;
                submitButton.textContent = 'Submit';
            });
    }

    function diorSubmitBooking() {
        let btn = document.getElementById('btn-confirm-booking');
        let msg = document.getElementById('booking-message');
        btn.disabled = true;
        btn.innerText = 'Booking Consultation...';

        const formData = new FormData();
        formData.append('action', 'dior_patient_book_appointment');
        formData.append('nonce', diorPortalNonce);
        formData.append('doctorId', diorBookingState.doctorId || 1695);
        formData.append('doctor_name', diorBookingState.doctorName || 'Doctor');
        formData.append('date', diorBookingState.date || '');
        formData.append('time', diorBookingState.time || '');
        formData.append('condition', diorBookingState.departmentName || 'Telehealth Consultation');
        formData.append('name', diorBookingState.patient.name || '');
        formData.append('email', diorBookingState.patient.email || '');
        formData.append('phone', diorBookingState.patient.phone || '');

        fetch(diorAjaxUrl, {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    msg.style.color = '#059669';
                    msg.innerText = 'Appointment booked successfully! Redirecting to your dashboard...';
                    setTimeout(() => {
                        // Keep the user on the dashboard page they came from instead of
                        // dropping back to the bare dashboard URL (which renders Overview).
                        let target = (window.dior_patient_dashboard && window.dior_patient_dashboard.dashboard_url) || (window.dior_vars && window.dior_vars.portal_url) || '/patient-dashboard/';
                        const currentHash = window.location.hash || '';
                        const targetHash = currentHash.indexOf('#tab=') === 0
                            ? currentHash
                            : '#tab=appointments&subtab=today';
                        const hashIndex = target.indexOf('#');
                        if (hashIndex !== -1) target = target.substring(0, hashIndex);
                        window.location.href = target + targetHash;
                    }, 1500);
                } else {
                    msg.style.color = '#DC2626';
                    msg.innerText = (data.data && data.data.message) || data.message || 'Failed to book appointment.';
                    btn.disabled = false;
                    btn.innerText = 'Confirm & Book';
                }
            })
            .catch(err => {
                msg.style.color = '#DC2626';
                msg.innerText = 'An error occurred while booking. Please try again.';
                btn.disabled = false;
                btn.innerText = 'Confirm & Book';
            });
    }

// --- Extracted dashboard script 2 ---
function diorDownloadTodayAppointmentsCSV() {
                                const table = document.getElementById('dior-today-appointments-table');
                                if (!table) return;

                                let csv = [];
                                csv.push(['Doctor', 'Specialization', 'Date', 'Time', 'Treatment', 'Contact', 'Status'].join(','));

                                const rows = table.querySelectorAll('tbody tr');
                                rows.forEach(function(row) {
                                    if (row.style.display === 'none') return;
                                    const cols = row.querySelectorAll('td');
                                    if (cols.length >= 7) {
                                        let doctor = cols[0].innerText.replace(/\s+/g, ' ').trim();
                                        let specialization = cols[1].innerText.replace(/\s+/g, ' ').trim();
                                        let date = cols[2].innerText.replace(/\s+/g, ' ').trim();
                                        let time = cols[3].innerText.replace(/\s+/g, ' ').trim();
                                        let treatment = cols[4].innerText.replace(/\s+/g, ' ').trim();
                                        let contact = cols[5].innerText.replace(/\s+/g, ' ').trim();
                                        let status = cols[6].innerText.replace(/\s+/g, ' ').trim();

                                        let rowData = [
                                            `"${doctor.replace(/"/g, '""')}"`,
                                            `"${specialization.replace(/"/g, '""')}"`,
                                            `"${date.replace(/"/g, '""')}"`,
                                            `"${time.replace(/"/g, '""')}"`,
                                            `"${treatment.replace(/"/g, '""')}"`,
                                            `"${contact.replace(/"/g, '""')}"`,
                                            `"${status.replace(/"/g, '""')}"`
                                        ];
                                        csv.push(rowData.join(','));
                                    }
                                });

                                const csvString = csv.join('\r\n');
                                const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.setAttribute('href', url);
                                link.setAttribute('download', 'todays_appointments.csv');
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                URL.revokeObjectURL(url);
                            }

                            function diorFilterTodayAppointments() {
                                const input = document.getElementById('dior-today-search-input');
                                const filter = input ? input.value.toLowerCase() : '';
                                const rows = document.querySelectorAll('#dior-today-appointments-tbody tr');
                                let visibleCount = 0;

                                rows.forEach(function(row) {
                                    const text = row.innerText.toLowerCase();
                                    if (text.includes(filter)) {
                                        row.style.display = '';
                                        visibleCount++;
                                    } else {
                                        row.style.display = 'none';
                                    }
                                });

                                const pageCountEl = document.getElementById('dior-today-page-count');
                                if (pageCountEl) {
                                    pageCountEl.innerText = `0 selected / ${visibleCount} total`;
                                }
                            }

// --- Extracted dashboard script 3 ---
let diorUpcomingCurrentPage = 1;
                            const diorUpcomingRowsPerPage = 5;

                            function diorGetUpcomingActiveRows() {
                                const input = document.getElementById('dior-upcoming-search-input');
                                const filter = input ? input.value.toLowerCase() : '';
                                const allRows = Array.from(document.querySelectorAll('#dior-upcoming-appointments-tbody tr'));
                                
                                return allRows.filter(function(row) {
                                    const text = row.innerText.toLowerCase();
                                    return text.includes(filter);
                                });
                            }

                            function diorRenderUpcomingPagination() {
                                const activeRows = diorGetUpcomingActiveRows();
                                const allRows = Array.from(document.querySelectorAll('#dior-upcoming-appointments-tbody tr'));
                                const totalPages = Math.ceil(activeRows.length / diorUpcomingRowsPerPage) || 1;

                                if (diorUpcomingCurrentPage > totalPages) {
                                    diorUpcomingCurrentPage = totalPages;
                                }
                                if (diorUpcomingCurrentPage < 1) {
                                    diorUpcomingCurrentPage = 1;
                                }

                                // First hide all rows
                                allRows.forEach(row => row.style.display = 'none');

                                // Show rows for current page
                                const startIndex = (diorUpcomingCurrentPage - 1) * diorUpcomingRowsPerPage;
                                const endIndex = startIndex + diorUpcomingRowsPerPage;
                                const pageRows = activeRows.slice(startIndex, endIndex);

                                pageRows.forEach(row => row.style.display = '');

                                // Build pagination HTML
                                const pagContainer = document.getElementById('dior-upcoming-pagination');
                                if (pagContainer) {
                                    pagContainer.innerHTML = diorBuildPagerHtml(diorUpcomingCurrentPage, totalPages, 'diorGoUpcomingPage');
                                }

                                diorUpdateUpcomingSelectedCount(activeRows.length);
                            }

                            function diorGoUpcomingPage(page) {
                                diorUpcomingCurrentPage = page;
                                diorRenderUpcomingPagination();
                            }

                            function diorDownloadUpcomingAppointmentsCSV() {
                                const table = document.getElementById('dior-upcoming-appointments-table');
                                if (!table) return;

                                let csv = [];
                                csv.push(['Doctor', 'Date', 'Time', 'Injury', 'Status', 'Notes'].join(','));

                                const activeRows = diorGetUpcomingActiveRows();
                                activeRows.forEach(function(row) {
                                    const cols = row.querySelectorAll('td');
                                    if (cols.length >= 8) {
                                        let doctor = cols[1].innerText.replace(/\s+/g, ' ').trim();
                                        let date = cols[2].innerText.replace(/\s+/g, ' ').trim();
                                        let time = cols[3].innerText.replace(/\s+/g, ' ').trim();
                                        let injury = cols[4].innerText.replace(/\s+/g, ' ').trim();
                                        let status = cols[5].innerText.replace(/\s+/g, ' ').trim();
                                        let notes = cols[6].innerText.replace(/\s+/g, ' ').trim();

                                        let rowData = [
                                            `"${doctor.replace(/"/g, '""')}"`,
                                            `"${date.replace(/"/g, '""')}"`,
                                            `"${time.replace(/"/g, '""')}"`,
                                            `"${injury.replace(/"/g, '""')}"`,
                                            `"${status.replace(/"/g, '""')}"`,
                                            `"${notes.replace(/"/g, '""')}"`
                                        ];
                                        csv.push(rowData.join(','));
                                    }
                                });

                                const csvString = csv.join('\r\n');
                                const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.setAttribute('href', url);
                                link.setAttribute('download', 'upcoming_appointments.csv');
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                URL.revokeObjectURL(url);
                            }

                            function diorFilterUpcomingAppointments() {
                                diorUpcomingCurrentPage = 1;
                                diorRenderUpcomingPagination();
                            }

                            function diorToggleSelectAllUpcoming(master) {
                                const activeRows = diorGetUpcomingActiveRows();
                                activeRows.forEach(function(row) {
                                    const cb = row.querySelector('.upcoming-row-checkbox');
                                    if (cb) cb.checked = master.checked;
                                });
                                diorUpdateUpcomingSelectedCount();
                            }

                            function diorBulkDeleteUpcomingRows() {
                                const checkedBoxes = document.querySelectorAll('.upcoming-row-checkbox:checked');
                                checkedBoxes.forEach(function(cb) {
                                    const row = cb.closest('tr');
                                    if (row) row.remove();
                                });
                                const masterCb = document.getElementById('dior-select-all-upcoming');
                                if (masterCb) masterCb.checked = false;
                                diorRenderUpcomingPagination();
                            }

                            function diorUpdateUpcomingSelectedCount(customVisibleCount) {
                                const checkboxes = document.querySelectorAll('.upcoming-row-checkbox');
                                let selectedCount = 0;
                                let visibleCount = 0;

                                checkboxes.forEach(function(cb) {
                                    const row = cb.closest('tr');
                                    if (row) {
                                        visibleCount++;
                                        if (cb.checked) selectedCount++;
                                    }
                                });

                                const bulkDeleteBtn = document.getElementById('dior-upcoming-bulk-delete-btn');
                                if (bulkDeleteBtn) {
                                    bulkDeleteBtn.style.display = selectedCount > 0 ? 'inline-flex' : 'none';
                                }

                                const total = (typeof customVisibleCount === 'number') ? customVisibleCount : visibleCount;
                                const pageCountEl = document.getElementById('dior-upcoming-page-count');
                                if (pageCountEl) {
                                    pageCountEl.innerText = `${selectedCount} selected / ${total} total`;
                                }
                            }

                            document.addEventListener('DOMContentLoaded', function() {
                                diorRenderUpcomingPagination();
                            });
                            if (document.readyState === 'interactive' || document.readyState === 'complete') {
                                diorRenderUpcomingPagination();
                            }

// --- Extracted dashboard script 4 ---
let diorPastCurrentPage = 1;
                            const diorPastRowsPerPage = 5;

                            function diorGetPastActiveRows() {
                                const input = document.getElementById('dior-past-search-input');
                                const filter = input ? input.value.toLowerCase() : '';
                                const allRows = Array.from(document.querySelectorAll('#dior-past-appointments-tbody tr'));
                                
                                return allRows.filter(function(row) {
                                    const text = row.innerText.toLowerCase();
                                    return text.includes(filter);
                                });
                            }

                            function diorRenderPastPagination() {
                                const activeRows = diorGetPastActiveRows();
                                const allRows = Array.from(document.querySelectorAll('#dior-past-appointments-tbody tr'));
                                const totalPages = Math.ceil(activeRows.length / diorPastRowsPerPage) || 1;

                                if (diorPastCurrentPage > totalPages) {
                                    diorPastCurrentPage = totalPages;
                                }
                                if (diorPastCurrentPage < 1) {
                                    diorPastCurrentPage = 1;
                                }

                                allRows.forEach(row => row.style.display = 'none');

                                const startIndex = (diorPastCurrentPage - 1) * diorPastRowsPerPage;
                                const endIndex = startIndex + diorPastRowsPerPage;
                                const pageRows = activeRows.slice(startIndex, endIndex);

                                pageRows.forEach(row => row.style.display = '');

                                const pagContainer = document.getElementById('dior-past-pagination');
                                if (pagContainer) {
                                    pagContainer.innerHTML = diorBuildPagerHtml(diorPastCurrentPage, totalPages, 'diorGoPastPage');
                                }

                                const pageCountEl = document.getElementById('dior-past-page-count');
                                if (pageCountEl) {
                                    pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
                                }
                            }

                            function diorGoPastPage(page) {
                                diorPastCurrentPage = page;
                                diorRenderPastPagination();
                            }

                            function diorFilterPastAppointments() {
                                diorPastCurrentPage = 1;
                                diorRenderPastPagination();
                            }
                            
                            function diorDownloadPastAppointmentsCSV() {
                                const table = document.getElementById('dior-past-appointments-table');
                                if (!table) return;

                                let csv = [];
                                csv.push(['Doctor', 'Date', 'Time', 'Email', 'Mobile', 'Injury', 'Type', 'Next Appointment'].join(','));

                                const activeRows = diorGetPastActiveRows();
                                activeRows.forEach(function(row) {
                                    const cols = row.querySelectorAll('td');
                                    if (cols.length >= 8) {
                                        let doctor = cols[0].innerText.replace(/\s+/g, ' ').trim();
                                        let date = cols[1].innerText.replace(/\s+/g, ' ').trim();
                                        let time = cols[2].innerText.replace(/\s+/g, ' ').trim();
                                        let email = cols[3].innerText.replace(/\s+/g, ' ').trim();
                                        let mobile = cols[4].innerText.replace(/\s+/g, ' ').trim();
                                        let injury = cols[5].innerText.replace(/\s+/g, ' ').trim();
                                        let type = cols[6].innerText.replace(/\s+/g, ' ').trim();
                                        let nextAppt = cols[7].innerText.replace(/\s+/g, ' ').trim();

                                        let rowData = [
                                            `"${doctor.replace(/"/g, '""')}"`,
                                            `"${date.replace(/"/g, '""')}"`,
                                            `"${time.replace(/"/g, '""')}"`,
                                            `"${email.replace(/"/g, '""')}"`,
                                            `"${mobile.replace(/"/g, '""')}"`,
                                            `"${injury.replace(/"/g, '""')}"`,
                                            `"${type.replace(/"/g, '""')}"`,
                                            `"${nextAppt.replace(/"/g, '""')}"`
                                        ];
                                        csv.push(rowData.join(','));
                                    }
                                });

                                const csvString = csv.join('\r\n');
                                const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
                                const url = URL.createObjectURL(blob);
                                const link = document.createElement('a');
                                link.setAttribute('href', url);
                                link.setAttribute('download', 'past_appointments.csv');
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                URL.revokeObjectURL(url);
                            }

                            document.addEventListener('DOMContentLoaded', function() {
                                diorRenderPastPagination();
                            });
                            if (document.readyState === 'interactive' || document.readyState === 'complete') {
                                diorRenderPastPagination();
                            }

// --- Extracted dashboard script 5 ---
window.diorSwitchApptSubTab = function(targetSubTab) {
                        if (!targetSubTab) targetSubTab = 'book';
                        // The calendar subtab was removed — never fall back to a pane that no longer exists.
                        if (targetSubTab === 'calendar' || !document.getElementById('dior-subtab-' + targetSubTab)) {
                            targetSubTab = 'today';
                        }
                        var navBtns = document.querySelectorAll('.dior-nav-btn');
                        var tabPanels = document.querySelectorAll('.dior-tab-panel');
                        
                        // Switch Main Tab to Appointments
                        navBtns.forEach(function(b) {
                            if (b.getAttribute('data-tab') === 'appointments' && !diorIsSubmenuParentBtn(b)) {
                                b.classList.add('active');
                            } else {
                                b.classList.remove('active');
                            }
                        });
                        tabPanels.forEach(function(p) {
                            if (p.id === 'tab-appointments') {
                                p.classList.add('active');
                                p.style.setProperty('display', 'block', 'important');
                                p.style.setProperty('visibility', 'visible', 'important');
                                p.style.setProperty('opacity', '1', 'important');
                            } else {
                                p.classList.remove('active');
                            }
                        });

                        // Switch inner tab
                        var panels = document.querySelectorAll('.dior-subtab-panel');
                        panels.forEach(function(panel) {
                            var isTarget = panel.id === 'dior-subtab-' + targetSubTab;
                            panel.style.setProperty(
                                'display',
                                isTarget ? 'block' : 'none',
                                'important'
                            );
                            if (isTarget) {
                                panel.style.setProperty('visibility', 'visible', 'important');
                                panel.style.setProperty('opacity', '1', 'important');
                            }
                        });

                        // Update dynamic breadcrumb & headers
                        var titles = {
                            'calendar': 'Appointment Calendar',
                            'book': 'Book Appointment',
                            'today': "Today's Appointments",
                            'upcoming': 'Upcoming Appointments',
                            'past': 'Past Appointments'
                        };
                        var t = titles[targetSubTab] || 'Book Appointment';
                        var mainTitleEl = document.getElementById('dior-appt-main-title');
                        var crumbTitleEl = document.getElementById('dior-appt-breadcrumb-title');
                        if (mainTitleEl) mainTitleEl.textContent = t;
                        if (crumbTitleEl) crumbTitleEl.textContent = t;

                        // Ensure dropdown is open and highlight active dropdown item
                        var dropdownWrap = document.getElementById('dior-appt-dropdown-wrap');
                        if (dropdownWrap) {
                            dropdownWrap.classList.add('open');
                            // Doctor contract: the affordance is a +/− toggle icon.
                            var toggleIcon = dropdownWrap.querySelector('.submenu-icon');
                            if (toggleIcon) {
                                toggleIcon.classList.remove('fa-plus');
                                toggleIcon.classList.add('fa-minus');
                            }
                        }
                        document.querySelectorAll('#dior-appt-dropdown-wrap .dior-nav-dropdown-item').forEach(function(item) {
                            if (item.getAttribute('data-appt-subtab') === targetSubTab) {
                                item.classList.add('active');
                            } else {
                                item.classList.remove('active');
                            }
                        });
                        document.querySelectorAll('.dior-subtab-pill').forEach(function(item) {
                            if (item.getAttribute('data-appt-subtab') === targetSubTab) {
                                item.classList.add('active');
                            } else {
                                item.classList.remove('active');
                            }
                        });

                        // If switching to calendar, trigger render
                        if (targetSubTab === 'calendar' && typeof window.diorRenderBootstrapCalendar === 'function') {
                            setTimeout(window.diorRenderBootstrapCalendar, 50);
                        }

                        // Remember active subtab in sessionStorage and URL hash so reload works reliably
                        try {
                            sessionStorage.setItem('dior_active_appt_subtab', targetSubTab);
                        } catch(e) {}
                        if (window.history && window.history.replaceState) {
                            window.history.replaceState(null, '', '#tab=appointments&subtab=' + encodeURIComponent(targetSubTab));
                        }

                        // Trigger resize for embedded forms / iframe layout recalculation
                        setTimeout(function() {
                            window.dispatchEvent(new Event('resize'));
                        }, 120);

                        window.scrollTo({ top: 0, behavior: 'smooth' });
                    };

/* ==============================================================
 * DIOR MEDICAL — PURE BOOTSTRAP 5 APPOINTMENT CALENDAR ENGINE
 * ============================================================== */
(function() {
    var calCurrentDate = new Date(); // Month/year being viewed
    var calSelectedDate = null;      // 'YYYY-MM-DD'
    var calViewMode = 'month';       // 'month' or 'agenda'
    var calTypeFilter = 'all';       // 'all', 'video', 'phone', 'clinic'
    var calStatusFilter = 'all';     // 'all', 'confirmed', 'completed', 'cancelled'
    var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    function normalizeYmd(raw) {
        if (!raw) return '';
        var str = String(raw).trim();
        if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
        var parts;
        if (/^\d{2}[-\/.]\d{2}[-\/.]\d{4}$/.test(str)) {
            parts = str.split(/[-\/.]/);
            return parts[2] + '-' + parts[0].padStart(2, '0') + '-' + parts[1].padStart(2, '0');
        }
        var d = new Date(str);
        if (!isNaN(d.getTime())) {
            var y = d.getFullYear();
            var m = String(d.getMonth() + 1).padStart(2, '0');
            var day = String(d.getDate()).padStart(2, '0');
            return y + '-' + m + '-' + day;
        }
        return '';
    }

    function getAppointments() {
        var raw = [];
        if (Array.isArray(window.dior_patient_appts_data) && window.dior_patient_appts_data.length > 0) {
            raw = window.dior_patient_appts_data;
        } else if (Array.isArray(window.dior_inline_appts_data) && window.dior_inline_appts_data.length > 0) {
            raw = window.dior_inline_appts_data;
        } else if (window.dior_patient_dashboard && Array.isArray(window.dior_patient_dashboard.appointments)) {
            raw = window.dior_patient_dashboard.appointments;
        }
        
        return raw.map(function(item, idx) {
            var dateRaw = item.date || item.appt_date || '';
            var ymd = item.ymd || normalizeYmd(dateRaw);
            var id = item.id || item.appt_uid || ('APT-' + (1000 + idx));
            var doc = item.doc || item.provider || item.doctor_name || 'Dr. Marcus Sterling, DO';
            var spec = item.spec || item.provider_spec || 'Telehealth Urgent Care';
            var time = item.time || item.appt_time || '09:00 AM - 10:00 AM';
            var status = item.status || item.appt_status || 'Confirmed';
            var type = item.type || item.visit_type || 'Video Visit (HD)';
            var join_url = item.join_url || '';
            var notes = item.notes || item.condition || 'Telehealth Consultation';
            return {
                id: id,
                doc: doc,
                spec: spec,
                date: dateRaw,
                ymd: ymd,
                time: time,
                status: status,
                type: type,
                join_url: join_url,
                notes: notes
            };
        });
    }

    function filterAppointments(list) {
        return list.filter(function(a) {
            if (calTypeFilter !== 'all') {
                var t = (a.type || '').toLowerCase();
                if (calTypeFilter === 'video' && t.indexOf('video') === -1 && t.indexOf('telehealth') === -1) return false;
                if (calTypeFilter === 'phone' && t.indexOf('phone') === -1 && t.indexOf('audio') === -1) return false;
                if (calTypeFilter === 'clinic' && t.indexOf('clinic') === -1 && t.indexOf('person') === -1) return false;
            }
            if (calStatusFilter !== 'all') {
                var s = (a.status || '').toLowerCase();
                if (calStatusFilter === 'confirmed' && s !== 'confirmed' && s !== 'scheduled' && s !== 'in-queue') return false;
                if (calStatusFilter === 'completed' && s !== 'completed' && s !== 'done' && s !== 'past') return false;
                if (calStatusFilter === 'cancelled' && s !== 'cancelled') return false;
            }
            return true;
        });
    }

    function formatFullDate(ymd) {
        if (!ymd) return '';
        var parts = ymd.split('-');
        if (parts.length !== 3) return ymd;
        var d = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return dayNames[d.getDay()] + ', ' + months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
    }

    function renderMonthGrid() {
        var gridBody = document.getElementById('dior-bs-cal-grid-body');
        var titleEl = document.getElementById('dior-bs-cal-title');
        if (!gridBody) return;

        var year = calCurrentDate.getFullYear();
        var month = calCurrentDate.getMonth();

        if (titleEl) {
            titleEl.textContent = monthNames[month] + ' ' + year;
        }

        var appts = filterAppointments(getAppointments());
        var apptsByYmd = {};
        appts.forEach(function(a) {
            if (a.ymd) {
                if (!apptsByYmd[a.ymd]) apptsByYmd[a.ymd] = [];
                apptsByYmd[a.ymd].push(a);
            }
        });

        var today = new Date();
        var todayYmd = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
        if (!calSelectedDate) {
            calSelectedDate = todayYmd;
        }

        var firstDayIndex = new Date(year, month, 1).getDay(); // 0 (Sun) to 6 (Sat)
        var daysInMonth = new Date(year, month + 1, 0).getDate();
        var daysInPrevMonth = new Date(year, month, 0).getDate();

        var html = '';
        var dayCounter = 1;
        var nextMonthDayCounter = 1;

        var totalCells = (firstDayIndex + daysInMonth > 35) ? 42 : 35;
        for (var i = 0; i < totalCells; i++) {
            if (i % 7 === 0) html += '<tr>';

            var cellYmd = '';
            var cellDayNum = 0;
            var isOtherMonth = false;
            var isToday = false;
            var isSelected = false;

            if (i < firstDayIndex) {
                isOtherMonth = true;
                cellDayNum = daysInPrevMonth - (firstDayIndex - i - 1);
                var prevM = month === 0 ? 12 : month;
                var prevY = month === 0 ? year - 1 : year;
                cellYmd = prevY + '-' + String(prevM).padStart(2, '0') + '-' + String(cellDayNum).padStart(2, '0');
            } else if (dayCounter <= daysInMonth) {
                cellDayNum = dayCounter;
                cellYmd = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(cellDayNum).padStart(2, '0');
                dayCounter++;
            } else {
                isOtherMonth = true;
                cellDayNum = nextMonthDayCounter++;
                var nextM = month === 11 ? 1 : month + 2;
                var nextY = month === 11 ? year + 1 : year;
                cellYmd = nextY + '-' + String(nextM).padStart(2, '0') + '-' + String(cellDayNum).padStart(2, '0');
            }

            if (cellYmd === todayYmd) isToday = true;
            if (cellYmd === calSelectedDate) isSelected = true;

            var cellEvents = apptsByYmd[cellYmd] || [];

            html += '<td class="dior-bs-cal-cell' + 
                    (isOtherMonth ? ' dior-bs-cal-other-month' : '') + 
                    (isToday ? ' dior-bs-cal-today' : '') + 
                    (isSelected ? ' dior-bs-cal-selected' : '') + 
                    '" data-date="' + cellYmd + '">';

            html += '<div class="dior-bs-cal-day-header">';
            html += '<span class="dior-bs-cal-day-num">' + cellDayNum + '</span>';
            if (cellEvents.length > 0) {
                html += '<span class="badge rounded-pill bg-primary" style="font-size: 10px; padding: 2px 5px;">' + cellEvents.length + '</span>';
            }
            html += '</div>';

            html += '<div class="dior-bs-cal-events-wrap">';
            var maxDisplay = 2;
            for (var evIdx = 0; evIdx < Math.min(cellEvents.length, maxDisplay); evIdx++) {
                var apt = cellEvents[evIdx];
                var typeLc = (apt.type || '').toLowerCase();
                var statusLc = (apt.status || '').toLowerCase();
                var evClass = 'event-video';
                var icon = 'fa-video';
                if (statusLc === 'completed') {
                    evClass = 'event-completed';
                    icon = 'fa-check';
                } else if (statusLc === 'cancelled') {
                    evClass = 'event-cancelled';
                    icon = 'fa-ban';
                } else if (typeLc.indexOf('phone') !== -1) {
                    evClass = 'event-phone';
                    icon = 'fa-phone';
                }
                var shortTime = (apt.time || '').split('-')[0].trim();
                html += '<div class="dior-bs-cal-event ' + evClass + '" onclick="event.stopPropagation(); if (typeof diorViewAppointmentDetails === \'function\') diorViewAppointmentDetails(\'' + apt.id + '\');" title="' + (apt.type || '') + ' - ' + (apt.doc || '') + '">';
                html += '<i class="fas ' + icon + ' me-1" style="font-size:10px;"></i>';
                html += '<strong style="font-size:10.5px;">' + shortTime + '</strong>';
                html += '</div>';
            }
            if (cellEvents.length > maxDisplay) {
                html += '<div class="small text-muted fw-bold px-1" style="font-size: 10px;">+' + (cellEvents.length - maxDisplay) + ' more</div>';
            }
            html += '</div>';

            html += '</td>';

            if (i % 7 === 6) html += '</tr>';
        }

        gridBody.innerHTML = html;

        gridBody.querySelectorAll('.dior-bs-cal-cell').forEach(function(cell) {
            cell.addEventListener('click', function() {
                var d = this.getAttribute('data-date');
                if (!d) return;
                calSelectedDate = d;
                gridBody.querySelectorAll('.dior-bs-cal-cell').forEach(function(c) {
                    c.classList.remove('dior-bs-cal-selected');
                });
                this.classList.add('dior-bs-cal-selected');
                renderDaySchedule();
            });
        });

        renderDaySchedule();
    }


    // Guard: a Join control must never point at an empty or non-http href.
    // Appointments created before the Zoom credentials were configured carry
    // an empty join_url; clicking such a link did nothing at all, which is what
    // made "Join Video Consultation Room" look broken. In that case we open the
    // Telemedicine details modal instead, so the patient still learns where and
    // when the visit is and can reschedule.
    document.addEventListener('click', function (event) {
        var joinEl = event.target.closest('a[data-dior-meeting-join], button[data-dior-meeting-join]');
        if (!joinEl) return;
        var rawHref = (joinEl.getAttribute('href') || '').trim();
        var looksUsable = joinEl.tagName === 'BUTTON' ? true : /^https?:\/\//i.test(rawHref);
        if (looksUsable) return;

        event.preventDefault();
        event.stopPropagation();

        var uid = joinEl.getAttribute('data-appt-uid') || '';
        var row = uid ? document.querySelector('#dior-tele-table tr[data-tele-id="' + uid.replace(/"/g, '') + '"]') : null;
        var portal = document.getElementById('dior-patient-portal-app');

        if (typeof window.diorSwitchTab === 'function') {
            window.diorSwitchTab('telemedicine');
        }

        if (row && typeof window.diorViewTelemedicine === 'function') {
            // Prefer the real row so the modal shows live appointment data.
            var btn = row.querySelector('.tele-join-btn') || row.querySelector('.edit-btn');
            window.setTimeout(function () {
                window.diorViewTelemedicine(btn || row);
            }, 120);
        } else if (typeof window.Swal !== 'undefined') {
            window.Swal.fire({
                icon: 'info',
                title: 'Meeting link not ready yet',
                text: 'A video link has not been created for this appointment. Please open Telemedicine for the details, or reschedule if you need to.',
                confirmButtonText: 'Open Telemedicine'
            }).then(function () {
                if (portal) portal.scrollIntoView({ behavior: 'smooth', block: 'start' });
            });
        }
    }, true);

    // Track patient clicks on Join Visit / Join Telehealth Room and notify the doctor.
    document.addEventListener('click', function (event) {
        var link = event.target.closest('a[data-dior-meeting-join], button[data-dior-meeting-join], .dior-tele-join-btn');
        if (!link) return;
        var root = document.getElementById('dior-patient-portal-app');
        var nonce = link.getAttribute('data-meeting-nonce') || (root && root.getAttribute('data-meeting-nonce')) || (window.dior_patient_dashboard && (window.dior_patient_dashboard.meeting_nonce || window.dior_patient_dashboard.portal_nonce)) || (window.dior_vars && window.dior_vars.nonce) || '';
        var apptUid = link.getAttribute('data-appt-uid') || (link.closest('[data-appt-uid]') && link.closest('[data-appt-uid]').getAttribute('data-appt-uid')) || '';
        var body = new URLSearchParams({ action: 'dior_meeting_participant_joined', appt_uid: apptUid, nonce: nonce });
        var ajaxUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '/wp-admin/admin-ajax.php';
        if (navigator.sendBeacon) {
            navigator.sendBeacon(ajaxUrl, new Blob([body.toString()], { type: 'application/x-www-form-urlencoded; charset=UTF-8' }));
        } else {
            fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', keepalive: true, headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() }).catch(function () {});
        }
    }, true);
    function renderAgendaList() {
        var agendaListEl = document.getElementById('dior-bs-cal-agenda-list');
        if (!agendaListEl) return;

        var appts = filterAppointments(getAppointments());
        appts.sort(function(a, b) {
            return (a.ymd || '').localeCompare(b.ymd || '');
        });

        if (appts.length === 0) {
            agendaListEl.innerHTML = '<div class="card border-0 bg-light p-4 text-center text-muted rounded-4">' +
                '<i class="far fa-calendar-xmark fs-2 text-secondary mb-2"></i>' +
                '<p class="mb-2 fw-medium">No appointments match the selected filters.</p>' +
                '<div><button type="button" class="btn btn-primary btn-sm rounded-pill" onclick="diorOpenDocBookerModal();"><i class="fas fa-calendar-plus me-1"></i> Book New Consultation</button></div>' +
                '</div>';
            return;
        }

        var html = '';
        var currentGroupDate = '';

        appts.forEach(function(apt) {
            if (apt.ymd !== currentGroupDate) {
                currentGroupDate = apt.ymd;
                html += '<div class="d-flex align-items-center gap-2 mt-2 pt-2 border-top">';
                html += '<span class="badge bg-primary rounded-pill px-3 py-1.5 fw-semibold fs-7"><i class="far fa-calendar me-1"></i> ' + formatFullDate(apt.ymd) + '</span>';
                html += '<span class="text-muted small">(' + apt.ymd + ')</span>';
                html += '</div>';
            }

            var statusLc = (apt.status || '').toLowerCase();
            var statusBadge = 'bg-primary-subtle text-primary';
            if (statusLc === 'confirmed') statusBadge = 'bg-success-subtle text-success';
            else if (statusLc === 'completed') statusBadge = 'bg-secondary-subtle text-secondary';
            else if (statusLc === 'cancelled') statusBadge = 'bg-danger-subtle text-danger';

            var isVideo = (apt.type || '').toLowerCase().indexOf('video') !== -1;
            var canJoin = isVideo && (statusLc === 'confirmed' || statusLc === 'scheduled' || statusLc === 'success' || statusLc === 'in progress' || statusLc === 'in-queue');

            html += '<div class="card border-0 shadow-sm rounded-3 p-3 bg-white">';
            html += '<div class="d-flex flex-wrap align-items-center justify-content-between gap-3">';
            
            html += '<div class="d-flex align-items-center gap-3">';
            html += '<div class="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold shadow-sm" style="width: 44px; height: 44px; background: linear-gradient(135deg, #1A528E 0%, #1A528E 100%); font-size: 14px;">';
            html += '<i class="fas ' + (isVideo ? 'fa-video' : 'fa-user-doctor') + '"></i>';
            html += '</div>';
            html += '<div>';
            html += '<div class="d-flex align-items-center gap-2">';
            html += '<h6 class="mb-0 fw-bold text-dark">' + apt.doc + '</h6>';
            html += '<span class="badge ' + statusBadge + ' rounded-pill px-2 py-0.5 small">' + apt.status + '</span>';
            html += '</div>';
            html += '<div class="text-muted small mt-0.5">' + apt.spec + ' &bull; <span class="text-dark fw-semibold">' + apt.type + '</span></div>';
            html += '<div class="text-primary small fw-semibold mt-1"><i class="far fa-clock me-1"></i>' + apt.time + '</div>';
            html += '</div>';
            html += '</div>';

            html += '<div class="d-flex flex-wrap align-items-center gap-2">';
            if (canJoin && apt.join_url && /^https:\/\//i.test(apt.join_url)) {
                html += '<a href="' + apt.join_url.replace(/&/g, '&amp;').replace(/\"/g, '&quot;') + '" data-dior-meeting-join data-appt-uid="' + String(apt.id).replace(/[&<>"]/g, '') + '" data-meeting-nonce="' + ((window.dior_patient_dashboard && window.dior_patient_dashboard.meeting_nonce) || '') + '" target="_blank" rel="noopener noreferrer" class="btn btn-success btn-sm rounded-pill px-3 fw-bold d-inline-flex align-items-center gap-1 shadow-sm">';
                html += '<i class="fas fa-video"></i> Join Visit';
                html += '</a>';
            }
            html += '<button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3" onclick="if (typeof diorViewAppointmentDetails === \'function\') diorViewAppointmentDetails(\'' + apt.id + '\');">';
            html += '<i class="fas fa-eye me-1"></i> Details';
            html += '</button>';
            html += '<button type="button" class="btn btn-outline-secondary btn-sm rounded-pill px-3" onclick="if (typeof diorOpenRescheduleModal === \'function\') diorOpenRescheduleModal(\'' + apt.id + '\', \'' + apt.date + '\');">';
            html += '<i class="fas fa-arrows-rotate me-1"></i> Reschedule';
            html += '</button>';
            html += '</div>';

            html += '</div>';
            html += '</div>';
        });

        agendaListEl.innerHTML = html;
    }

    function renderDaySchedule() {
        var headerEl = document.getElementById('dior-bs-cal-selected-header');
        var countEl = document.getElementById('dior-bs-cal-selected-count');
        var bodyEl = document.getElementById('dior-bs-cal-selected-body');
        if (!bodyEl) return;

        var ymd = calSelectedDate;
        if (headerEl) {
            headerEl.textContent = formatFullDate(ymd);
        }

        var appts = filterAppointments(getAppointments()).filter(function(a) {
            return a.ymd === ymd;
        });

        if (countEl) {
            countEl.textContent = appts.length + ' Visit' + (appts.length === 1 ? '' : 's');
        }

        if (appts.length === 0) {
            bodyEl.innerHTML = '<div class="text-center py-4 text-muted">' +
                '<div class="mb-3" style="font-size: 2.2rem; color: #cbd5e1;"><i class="far fa-calendar-xmark"></i></div>' +
                '<h6 class="text-dark fw-bold mb-1">No Consultations</h6>' +
                '<p class="small text-muted mb-3">There are no appointments scheduled for this date.</p>' +
                '<button type="button" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-semibold shadow-sm" onclick="diorOpenDocBookerModal();">' +
                '<i class="fas fa-calendar-plus me-1"></i> Schedule Consultation' +
                '</button>' +
                '</div>';
            return;
        }

        var html = '<div class="d-flex flex-column gap-3">';
        appts.forEach(function(apt) {
            var statusLc = (apt.status || '').toLowerCase();
            var statusBadge = 'bg-primary-subtle text-primary';
            if (statusLc === 'confirmed') statusBadge = 'bg-success-subtle text-success';
            else if (statusLc === 'completed') statusBadge = 'bg-secondary-subtle text-secondary';
            else if (statusLc === 'cancelled') statusBadge = 'bg-danger-subtle text-danger';

            var isVideo = (apt.type || '').toLowerCase().indexOf('video') !== -1;
            var canJoin = isVideo && (statusLc === 'confirmed' || statusLc === 'scheduled' || statusLc === 'success' || statusLc === 'in progress' || statusLc === 'in-queue');

            html += '<div class="card border border-light-subtle rounded-3 p-3 bg-white shadow-sm">';
            
            html += '<div class="d-flex align-items-center justify-content-between mb-2">';
            html += '<span class="badge ' + statusBadge + ' rounded-pill px-2.5 py-1 small fw-bold">' + apt.status + '</span>';
            html += '<span class="text-muted small fw-medium" style="font-size:11px;"><i class="fas fa-hashtag me-0.5"></i>' + apt.id + '</span>';
            html += '</div>';

            html += '<div class="d-flex align-items-center gap-2 mb-2">';
            html += '<div class="rounded-circle d-flex align-items-center justify-content-center text-white fw-bold shadow-sm" style="width: 38px; height: 38px; background: #1A528E; font-size: 13px; flex-shrink: 0;">';
            html += '<i class="fas ' + (isVideo ? 'fa-video' : 'fa-user-doctor') + '"></i>';
            html += '</div>';
            html += '<div class="lh-sm overflow-hidden">';
            html += '<h6 class="mb-0 text-dark fw-bold text-truncate" style="font-size: 13.5px;">' + apt.doc + '</h6>';
            html += '<small class="text-muted text-truncate d-block" style="font-size: 11.5px;">' + apt.spec + '</small>';
            html += '</div>';
            html += '</div>';

            html += '<div class="p-2 rounded-2 bg-light mb-3 text-secondary small" style="font-size: 12px;">';
            html += '<div class="d-flex align-items-center justify-content-between mb-1">';
            html += '<span><i class="far fa-clock me-1 text-primary"></i> <strong>Time:</strong></span>';
            html += '<span class="text-dark fw-bold">' + apt.time + '</span>';
            html += '</div>';
            html += '<div class="d-flex align-items-center justify-content-between">';
            html += '<span><i class="fas fa-stethoscope me-1 text-info"></i> <strong>Type:</strong></span>';
            html += '<span class="text-dark fw-medium">' + apt.type + '</span>';
            html += '</div>';
            html += '</div>';

            if (canJoin && apt.join_url && /^https:\/\//i.test(apt.join_url)) {
                html += '<a href="' + apt.join_url.replace(/&/g, '&amp;').replace(/\"/g, '&quot;') + '" data-dior-meeting-join data-appt-uid="' + String(apt.id).replace(/[&<>"]/g, '') + '" data-meeting-nonce="' + ((window.dior_patient_dashboard && window.dior_patient_dashboard.meeting_nonce) || '') + '" target="_blank" rel="noopener noreferrer" class="btn btn-success btn-sm w-100 fw-bold mb-2 shadow-sm d-flex align-items-center justify-content-center gap-1.5 py-1.5">';
                html += '<i class="fas fa-video"></i> Join Telehealth Room';
                html += '</a>';
            }

            html += '<div class="d-flex gap-2">';
            html += '<button type="button" class="btn btn-outline-primary btn-sm flex-fill" onclick="if (typeof diorViewAppointmentDetails === \'function\') diorViewAppointmentDetails(\'' + apt.id + '\');">';
            html += '<i class="fas fa-eye me-1"></i> Details';
            html += '</button>';
            html += '<button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="if (typeof diorOpenRescheduleModal === \'function\') diorOpenRescheduleModal(\'' + apt.id + '\', \'' + apt.date + '\');">';
            html += '<i class="fas fa-arrows-rotate me-1"></i> Reschedule';
            html += '</button>';
            html += '</div>';

            html += '</div>';
        });
        html += '</div>';

        bodyEl.innerHTML = html;
    }

    window.diorInitBootstrapCalendar = function() {
        var container = document.getElementById('dior-subtab-calendar');
        if (!container) return;

        var prevBtn = document.getElementById('dior-bs-cal-prev');
        if (prevBtn && !prevBtn.__diorBound) {
            prevBtn.__diorBound = true;
            prevBtn.addEventListener('click', function() {
                calCurrentDate.setMonth(calCurrentDate.getMonth() - 1);
                renderMonthGrid();
            });
        }

        var nextBtn = document.getElementById('dior-bs-cal-next');
        if (nextBtn && !nextBtn.__diorBound) {
            nextBtn.__diorBound = true;
            nextBtn.addEventListener('click', function() {
                calCurrentDate.setMonth(calCurrentDate.getMonth() + 1);
                renderMonthGrid();
            });
        }

        var todayBtn = document.getElementById('dior-bs-cal-today');
        if (todayBtn && !todayBtn.__diorBound) {
            todayBtn.__diorBound = true;
            todayBtn.addEventListener('click', function() {
                calCurrentDate = new Date();
                var today = new Date();
                calSelectedDate = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
                renderMonthGrid();
            });
        }

        var typeSelect = document.getElementById('dior-bs-cal-type-filter');
        if (typeSelect && !typeSelect.__diorBound) {
            typeSelect.__diorBound = true;
            typeSelect.addEventListener('change', function() {
                calTypeFilter = this.value;
                if (calViewMode === 'month') renderMonthGrid();
                else renderAgendaList();
            });
        }

        var statusSelect = document.getElementById('dior-bs-cal-status-filter');
        if (statusSelect && !statusSelect.__diorBound) {
            statusSelect.__diorBound = true;
            statusSelect.addEventListener('change', function() {
                calStatusFilter = this.value;
                if (calViewMode === 'month') renderMonthGrid();
                else renderAgendaList();
            });
        }

        var viewMonthBtn = document.getElementById('dior-bs-cal-view-month');
        var viewAgendaBtn = document.getElementById('dior-bs-cal-view-agenda');
        var monthWrap = document.getElementById('dior-bs-cal-month-wrap');
        var agendaWrap = document.getElementById('dior-bs-cal-agenda-wrap');

        if (viewMonthBtn && !viewMonthBtn.__diorBound) {
            viewMonthBtn.__diorBound = true;
            viewMonthBtn.addEventListener('click', function() {
                calViewMode = 'month';
                viewMonthBtn.classList.add('btn-primary', 'active');
                viewMonthBtn.classList.remove('btn-outline-secondary');
                if (viewAgendaBtn) {
                    viewAgendaBtn.classList.remove('btn-primary', 'active');
                    viewAgendaBtn.classList.add('btn-outline-secondary');
                }
                if (monthWrap) monthWrap.style.display = 'block';
                if (agendaWrap) agendaWrap.style.display = 'none';
                renderMonthGrid();
            });
        }

        if (viewAgendaBtn && !viewAgendaBtn.__diorBound) {
            viewAgendaBtn.__diorBound = true;
            viewAgendaBtn.addEventListener('click', function() {
                calViewMode = 'agenda';
                viewAgendaBtn.classList.add('btn-primary', 'active');
                viewAgendaBtn.classList.remove('btn-outline-secondary');
                if (viewMonthBtn) {
                    viewMonthBtn.classList.remove('btn-primary', 'active');
                    viewMonthBtn.classList.add('btn-outline-secondary');
                }
                if (monthWrap) monthWrap.style.display = 'none';
                if (agendaWrap) agendaWrap.style.display = 'block';
                renderAgendaList();
            });
        }

        renderMonthGrid();
    };

    window.diorRenderBootstrapCalendar = function() {
        if (calViewMode === 'month') renderMonthGrid();
        else renderAgendaList();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', window.diorInitBootstrapCalendar);
    } else {
        setTimeout(window.diorInitBootstrapCalendar, 60);
    }
})();

// --- Extracted dashboard script 6 ---
let diorBillCurrentPage = 1;
    const diorBillRowsPerPage = 5;

    function diorGetBillActiveRows() {
        const input = document.getElementById('dior-bill-search-input');
        const filter = input ? input.value.toLowerCase() : '';
        const allRows = Array.from(document.querySelectorAll('#dior-bill-tbody tr'));
        
        return allRows.filter(function(row) {
            const text = row.innerText.toLowerCase();
            return text.includes(filter);
        });
    }

    function diorRenderBillPagination() {
        const activeRows = diorGetBillActiveRows();
        const allRows = Array.from(document.querySelectorAll('#dior-bill-tbody tr'));
        const totalPages = Math.ceil(activeRows.length / diorBillRowsPerPage) || 1;

        if (diorBillCurrentPage > totalPages) {
            diorBillCurrentPage = totalPages;
        }
        if (diorBillCurrentPage < 1) {
            diorBillCurrentPage = 1;
        }

        allRows.forEach(row => row.style.display = 'none');

        const startIndex = (diorBillCurrentPage - 1) * diorBillRowsPerPage;
        const endIndex = startIndex + diorBillRowsPerPage;
        const pageRows = activeRows.slice(startIndex, endIndex);

        pageRows.forEach(row => row.style.display = '');

        const pagContainer = document.getElementById('dior-bill-pagination');
        if (pagContainer) {
            pagContainer.innerHTML = diorBuildPagerHtml(diorBillCurrentPage, totalPages, 'diorGoBillPage');
        }

        const pageCountEl = document.getElementById('dior-bill-page-count');
        if (pageCountEl) {
            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
        }
    }

    function diorGoBillPage(page) {
        diorBillCurrentPage = page;
        diorRenderBillPagination();
    }

    function diorFilterBill() {
        diorBillCurrentPage = 1;
        diorRenderBillPagination();
    }
    
    function diorDownloadBillCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Invoice No,Doctor Name,Date,Amount,Tax,Discount,Total\n";
        const activeRows = diorGetBillActiveRows();
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 7) {
                let c0 = cols[0].innerText.trim();
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                let c5 = cols[5].innerText.trim();
                let c6 = cols[6].innerText.trim();
                csvContent += `"${c0}","${c1}","${c2}","${c3}","${c4}","${c5}","${c6}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "billing.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function diorOpenBillingModal(inv, doc, date, amt, tax, disc, total) {
        document.getElementById('billModalSubtitle').innerText = doc;
        document.getElementById('billModalDocName').innerText = doc;
        document.getElementById('billModalDocName2').innerText = doc;
        document.getElementById('billModalInv').innerText = inv;
        document.getElementById('billModalDate').innerText = date;
        document.getElementById('billModalAmount').innerText = amt;
        document.getElementById('billModalTax').innerText = tax;
        document.getElementById('billModalDisc').innerText = disc;
        document.getElementById('billModalTotal').innerText = total;
        /* Initials avatar drawn inline. The modal used to request
           ui-avatars.com, which is an external image call and rendered as a
           broken-image icon whenever it was blocked or offline. */
        var initials = String(doc).replace(/^Dr\.?\s*/i, '').trim().split(/\s+/)
            .slice(0, 2).map(function (w) { return w.charAt(0).toUpperCase(); }).join('') || '?';
        var avatarSvg = '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80">' +
            '<rect width="80" height="80" rx="40" fill="#F0F6FC"/>' +
            '<text x="40" y="40" text-anchor="middle" dominant-baseline="central" ' +
            'font-family="Montserrat,Arial,sans-serif" font-size="30" font-weight="700" fill="#1A528E">' +
            initials + '</text></svg>';
        document.getElementById('billModalAvatar').src = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(avatarSvg);
        document.getElementById('diorBillingModal').style.display = 'flex';
    }
    function diorCloseBillingModal() {
        document.getElementById('diorBillingModal').style.display = 'none';
    }

    /* Insurance & Claims detail popup. The eye button on that table had no
       handler at all, so clicking it did nothing. */
    window.diorOpenInsuranceModal = function (claimId, policyId, date, type, amount, approved, submitted, status) {
        var set = function (id, value) {
            var el = document.getElementById(id);
            if (el) el.textContent = (value === '' || value == null) ? '--' : value;
        };
        set('insModalClaimId', claimId);
        set('insModalPolicyId', policyId);
        set('insModalDate', date);
        set('insModalType', type);
        set('insModalAmount', amount);
        set('insModalApproved', approved);
        set('insModalSubmitted', submitted);
        set('insModalStatus', status);

        // What the patient actually pays out of pocket on an approved claim.
        var money = function (v) {
            var n = parseFloat(String(v).replace(/[^0-9.\-]/g, ''));
            return isNaN(n) ? null : n;
        };
        var claimed = money(amount), covered = money(approved);
        var oop = document.getElementById('insModalOop');
        if (oop) {
            if (claimed !== null && covered !== null && covered <= claimed) {
                oop.textContent = '$' + (claimed - covered).toFixed(2).replace(/\.00$/, '');
            } else {
                oop.textContent = '--';
            }
        }

        var modal = document.getElementById('diorInsuranceModal');
        if (modal) {
            modal.classList.add('open');
            modal.style.display = 'flex';
        }
    };

    window.diorCloseInsuranceModal = function () {
        var modal = document.getElementById('diorInsuranceModal');
        if (modal) {
            modal.classList.remove('open');
            modal.style.display = 'none';
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        var insModal = document.getElementById('diorInsuranceModal');
        if (!insModal) return;
        insModal.addEventListener('click', function (e) {
            if (e.target === insModal) window.diorCloseInsuranceModal();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && insModal.style.display === 'flex') {
                window.diorCloseInsuranceModal();
            }
        });
    });

    /* Build the printable body of a single bill. Shared by download and print so
       both produce the same document. */
    function diorBuildBillHtml(inv, doc, date, amt, tax, disc, total) {
        var logo = (window.dior_vars && window.dior_vars.logo_url) || '';
        var row = function (label, value) {
            return '<tr><th>' + label + '</th><td>' + value + '</td></tr>';
        };
        var esc = function (v) {
            return String(v == null ? '' : v).replace(/[&<>"']/g, function (c) {
                return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
            });
        };
        return '<div class="dior-bill-doc">' +
            '<div class="bill-doc-head">' +
                (logo ? '<img src="' + esc(logo) + '" alt="Dior Medical">' : '') +
                '<div><h1>DIOR MEDICAL TELEHEALTH</h1>' +
                '<p>Billing Statement &middot; Invoice ' + esc(inv) + '</p></div>' +
            '</div>' +
            '<table class="bill-doc-table">' +
                row('Invoice No', esc(inv)) +
                row('Doctor', esc(doc)) +
                row('Date', esc(date)) +
                row('Amount', esc(amt)) +
                row('Tax', esc(tax)) +
                row('Discount', esc(disc)) +
                '<tr class="bill-doc-total"><th>Total</th><td>' + esc(total) + '</td></tr>' +
            '</table>' +
            '<p class="bill-doc-foot">This statement was generated from the Dior Medical patient portal. ' +
            'For billing questions, contact the clinic using the details on our website.</p>' +
            '</div>';
    }

    /* Download the bill as a PDF, with a print-window fallback when the PDF
       library is unavailable. */
    window.diorDownloadBillPdf = function (inv, doc, date, amt, tax, disc, total) {
        var html = diorBuildBillHtml(inv, doc, date, amt, tax, disc, total);
        var fileName = 'Dior-Bill-' + String(inv).replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

        if (typeof html2pdf === 'undefined' || !html2pdf) {
            window.diorPrintBill(inv, doc, date, amt, tax, disc, total);
            return;
        }

        var holder = document.createElement('div');
        holder.style.position = 'fixed';
        holder.style.left = '0';
        holder.style.top = '0';
        holder.style.width = '750px';
        holder.style.background = '#FFFFFF';
        holder.style.zIndex = '-999999';
        holder.style.opacity = '1';
        holder.style.pointerEvents = 'none';
        holder.innerHTML = html;
        document.body.appendChild(holder);

        html2pdf().set({
            margin: [8, 8, 8, 8],
            filename: fileName,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, logging: false, scrollY: 0, scrollX: 0, windowWidth: 794 },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        }).from(holder.firstElementChild || holder).save()
            .then(function () {
                if (holder.parentNode) holder.parentNode.removeChild(holder);
            })
            .catch(function (err) {
                console.error('Bill PDF export failed:', err);
                if (holder.parentNode) holder.parentNode.removeChild(holder);
                window.diorPrintBill(inv, doc, date, amt, tax, disc, total);
            });
    };

    /* Print the bill in its own window so the dashboard chrome is not printed. */
    window.diorPrintBill = function (inv, doc, date, amt, tax, disc, total) {
        var body = diorBuildBillHtml(inv, doc, date, amt, tax, disc, total);
        var css = (window.dior_patient_dashboard && window.dior_patient_dashboard.refactor_css_url) || '';
        var styles =
            '@page{size:A4 portrait;margin:14mm}' +
            'body{margin:0;background:#fff;color:#0F172A;font-family:Montserrat,Arial,sans-serif;' +
            '-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
            '.bill-doc-head{display:flex;align-items:center;justify-content:space-between;gap:16px;' +
            'padding-bottom:14px;margin-bottom:20px;border-bottom:2px solid #1A528E}' +
            '.bill-doc-head img{max-height:52px;width:auto;object-fit:contain}' +
            '.bill-doc-head h1{font-size:17px;margin:0;color:#1A528E}' +
            '.bill-doc-head p{margin:4px 0 0;font-size:12px;color:#64748B}' +
            '.bill-doc-table{width:100%;border-collapse:collapse}' +
            '.bill-doc-table th{text-align:left;font-size:11px;letter-spacing:.05em;text-transform:uppercase;' +
            'color:#64748B;font-weight:700;padding:10px 12px;border-bottom:1px solid #E2E8F0;width:38%}' +
            '.bill-doc-table td{padding:10px 12px;border-bottom:1px solid #E2E8F0;font-size:13px;font-weight:600}' +
            '.bill-doc-total th,.bill-doc-total td{border-top:2px solid #1A528E;border-bottom:0;' +
            'font-size:15px;color:#00346C;font-weight:700}' +
            '.bill-doc-foot{margin-top:18px;font-size:10px;color:#64748B;line-height:1.5}';

        var win = window.open('', '_blank');
        if (!win) {
            window.print();
            return;
        }
        win.document.open();
        win.document.write('<!DOCTYPE html><html><head><meta charset="utf-8"><title>Invoice ' +
            String(inv).replace(/[<>]/g, '') + '</title>' +
            (css ? '<link rel="stylesheet" href="' + css + '">' : '') +
            '<style>' + styles + '</style></head><body>' + body + '</body></html>');
        win.document.close();
        win.focus();
        setTimeout(function () { win.print(); }, 350);
    };

    document.addEventListener('DOMContentLoaded', function() {
        diorRenderBillPagination();
    });
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
        diorRenderBillPagination();
    }

// --- Extracted dashboard script 7 ---
let diorInsuranceCurrentPage = 1;
    const diorInsuranceRowsPerPage = 5;

    function diorGetInsuranceActiveRows() {
        const input = document.getElementById('dior-insurance-search-input');
        const filter = input ? input.value.toLowerCase() : '';
        const allRows = Array.from(document.querySelectorAll('#dior-insurance-tbody tr'));
        
        return allRows.filter(function(row) {
            const text = row.innerText.toLowerCase();
            return text.includes(filter);
        });
    }

    function diorRenderInsurancePagination() {
        // Insurance & Claims has a single paginator: the shared table controller
        // (dior-static-table-interactions.js) renders it inside the card's
        // `.master-table-footer`. Running this 5-per-page helper as well produced
        // a second pager and made both fight over row visibility.
        if (document.getElementById('dior-insurance-table')) {
            return;
        }

        const activeRows = diorGetInsuranceActiveRows();
        const allRows = Array.from(document.querySelectorAll('#dior-insurance-tbody tr'));
        const totalPages = Math.ceil(activeRows.length / diorInsuranceRowsPerPage) || 1;

        if (diorInsuranceCurrentPage > totalPages) {
            diorInsuranceCurrentPage = totalPages;
        }
        if (diorInsuranceCurrentPage < 1) {
            diorInsuranceCurrentPage = 1;
        }

        allRows.forEach(row => row.style.display = 'none');

        const startIndex = (diorInsuranceCurrentPage - 1) * diorInsuranceRowsPerPage;
        const endIndex = startIndex + diorInsuranceRowsPerPage;
        const pageRows = activeRows.slice(startIndex, endIndex);

        pageRows.forEach(row => row.style.display = '');

        const pagContainer = document.getElementById('dior-insurance-pagination');
        if (pagContainer) {
            pagContainer.innerHTML = diorBuildPagerHtml(diorInsuranceCurrentPage, totalPages, 'diorGoInsurancePage');
        }

        const pageCountEl = document.getElementById('dior-insurance-page-count');
        if (pageCountEl) {
            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
        }
    }

    function diorGoInsurancePage(page) {
        diorInsuranceCurrentPage = page;
        diorRenderInsurancePagination();
    }

    function diorFilterInsurance() {
        diorInsuranceCurrentPage = 1;
        diorRenderInsurancePagination();
    }
    
    function diorDownloadInsuranceCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Claim ID,Policy ID,Claim Date,Claim Type,Claim Amount,Approved,Submitted,Status\n";
        const activeRows = diorGetInsuranceActiveRows();
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 9) {
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                let c5 = cols[5].innerText.trim();
                let c6 = cols[6].innerText.trim();
                let c7 = cols[7].innerText.trim();
                let c8 = cols[8].innerText.trim();
                csvContent += `"${c1}","${c2}","${c3}","${c4}","${c5}","${c6}","${c7}","${c8}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "insurance.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    document.addEventListener('DOMContentLoaded', function() {
        diorRenderInsurancePagination();
    });
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
        diorRenderInsurancePagination();
    }

// --- Extracted dashboard script 8 ---
let diorRxCurrentPage = 1;
                    const diorRxRowsPerPage = 5;

                    function diorGetRxActiveRows() {
                        const input = document.getElementById('dior-rx-search-input');
                        const filter = input ? input.value.toLowerCase() : '';
                        const allRows = Array.from(document.querySelectorAll('#dior-rx-tbody tr'));
                        
                        return allRows.filter(function(row) {
                            const text = row.innerText.toLowerCase();
                            return text.includes(filter);
                        });
                    }

                    function diorRenderRxPagination() {
                        const activeRows = diorGetRxActiveRows();
                        const allRows = Array.from(document.querySelectorAll('#dior-rx-tbody tr'));
                        const totalPages = Math.ceil(activeRows.length / diorRxRowsPerPage) || 1;

                        if (diorRxCurrentPage > totalPages) {
                            diorRxCurrentPage = totalPages;
                        }
                        if (diorRxCurrentPage < 1) {
                            diorRxCurrentPage = 1;
                        }

                        allRows.forEach(row => row.style.display = 'none');

                        const startIndex = (diorRxCurrentPage - 1) * diorRxRowsPerPage;
                        const endIndex = startIndex + diorRxRowsPerPage;
                        const pageRows = activeRows.slice(startIndex, endIndex);

                        pageRows.forEach(row => row.style.display = '');

                        const pagContainer = document.getElementById('dior-rx-pagination');
                        if (pagContainer) {
                            pagContainer.innerHTML = diorBuildPagerHtml(diorRxCurrentPage, totalPages, 'diorGoRxPage');
                        }

                        const pageCountEl = document.getElementById('dior-rx-page-count');
                        if (pageCountEl) {
                            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
                        }
                    }

                    function diorGoRxPage(page) {
                        diorRxCurrentPage = page;
                        diorRenderRxPagination();
                    }

                    function diorFilterRx() {
                        diorRxCurrentPage = 1;
                        diorRenderRxPagination();
                    }

                    function diorDeleteRxRow(btn) {
                        const row = btn.closest('tr');
                        if (row) {
                            row.remove();
                            diorRenderRxPagination();
                        }
                    }
                    
                    function diorDownloadRxCSV() {
                        let csvContent = "data:text/csv;charset=utf-8,ID,Title,Created By,Date,Diseases\n";
                        const activeRows = diorGetRxActiveRows();
                        activeRows.forEach(function(row) {
                            let cols = row.querySelectorAll('td');
                            if(cols.length >= 5) {
                                let id = cols[0].innerText.trim();
                                let title = cols[1].innerText.trim();
                                let doc = cols[2].innerText.trim();
                                let date = cols[3].innerText.trim();
                                let disease = cols[4].innerText.trim();
                                csvContent += `"${id}","${title}","${doc}","${date}","${disease}"\n`;
                            }
                        });
                        var encodedUri = encodeURI(csvContent);
                        var link = document.createElement("a");
                        link.setAttribute("href", encodedUri);
                        link.setAttribute("download", "prescriptions.csv");
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                    }

                    document.addEventListener('DOMContentLoaded', function() {
                        diorRenderRxPagination();
                    });
                    if (document.readyState === 'interactive' || document.readyState === 'complete') {
                        diorRenderRxPagination();
                    }

// --- Extracted dashboard script 9 ---
let diorTeleCurrentPage = 1;
    const diorTeleRowsPerPage = 6;

    function diorGetTeleActiveRows() {
        const input = document.getElementById('dior-tele-search-input');
        const filter = input ? input.value.toLowerCase() : '';
        const allRows = Array.from(document.querySelectorAll('#dior-tele-tbody tr'));
        
        return allRows.filter(function(row) {
            const text = row.innerText.toLowerCase();
            return text.includes(filter);
        });
    }

    function diorRenderTelePagination() {
        const activeRows = diorGetTeleActiveRows();
        const allRows = Array.from(document.querySelectorAll('#dior-tele-tbody tr'));
        const totalPages = Math.ceil(activeRows.length / diorTeleRowsPerPage) || 1;

        if (diorTeleCurrentPage > totalPages) {
            diorTeleCurrentPage = totalPages;
        }
        if (diorTeleCurrentPage < 1) {
            diorTeleCurrentPage = 1;
        }

        allRows.forEach(row => row.style.display = 'none');

        const startIndex = (diorTeleCurrentPage - 1) * diorTeleRowsPerPage;
        const endIndex = startIndex + diorTeleRowsPerPage;
        const pageRows = activeRows.slice(startIndex, endIndex);

        pageRows.forEach(row => row.style.display = '');

        const pagContainer = document.getElementById('dior-tele-pagination');
        if (pagContainer) {
            pagContainer.innerHTML = diorBuildPagerHtml(diorTeleCurrentPage, totalPages, 'diorGoTelePage');
        }

        const pageCountEl = document.getElementById('dior-tele-page-count');
        if (pageCountEl) {
            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
        }
    }

    function diorGoTelePage(page) {
        diorTeleCurrentPage = page;
        diorRenderTelePagination();
    }

    function diorFilterTele() {
        diorTeleCurrentPage = 1;
        diorRenderTelePagination();
    }
    
    function diorDownloadTeleCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Session ID,Doctor,Specialty,Date,Time,Duration,Type,Status\n";
        const activeRows = diorGetTeleActiveRows();
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 10) {
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                let c5 = cols[5].innerText.trim();
                let c6 = cols[6].innerText.trim();
                let c7 = cols[7].innerText.trim();
                let c8 = cols[8].innerText.trim();
                csvContent += `"${c1}","${c2}","${c3}","${c4}","${c5}","${c6}","${c7}","${c8}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "telemedicine.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    document.addEventListener('DOMContentLoaded', function() {
        diorRenderTelePagination();
    });
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
        diorRenderTelePagination();
    }

// --- Extracted dashboard script 10 ---
/* Document pagination and search are owned by the shared static-table layer
   (assets/js/dior-static-table-interactions.js). The old local paginator and
   the per-category pill filter were removed with the filter bar. */

    function diorDownloadDocsCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Document Title,Category,Type,Upload Date,Size,Status\n";
        const activeRows = Array.from(document.querySelectorAll('#dior-docs-tbody tr'));
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 8) {
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                let c5 = cols[5].innerText.trim();
                let c6 = cols[6].innerText.trim();
                csvContent += `"${c1}","${c2}","${c3}","${c4}","${c5}","${c6}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "documents.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

// Medical Record tab filters: the buttons filter the existing clinical timeline without reloading.
(function () {
    'use strict';
    function initMedicalRecordFilters() {
        var panel = document.getElementById('tab-medical_record');
        if (!panel || panel.dataset.filtersReady === '1') return;
        panel.dataset.filtersReady = '1';
        var buttons = panel.querySelectorAll('.dior-medical-record-filter');
        var items = panel.querySelectorAll('.mr-timeline-item[data-record-type]');
        buttons.forEach(function (button) {
            button.addEventListener('click', function () {
                var filter = button.getAttribute('data-filter') || 'ALL';
                buttons.forEach(function (b) {
                    b.classList.remove('is-active', 'btn-primary', 'shadow-sm', 'text-white', 'btn-light');
                    b.classList.add('btn-outline-primary');
                });
                button.classList.remove('btn-outline-primary', 'btn-light');
                button.classList.add('is-active', 'btn-primary', 'shadow-sm', 'text-white');
                items.forEach(function (item) {
                    var type = item.getAttribute('data-record-type') || '';
                    item.style.display = (filter === 'ALL' || type === filter || (filter === 'CONSULTATION' && (type === 'CONSULTATION' || type === 'APPOINTMENT'))) ? '' : 'none';
                });
                var visible = Array.prototype.filter.call(items, function (item) { return item.style.display !== 'none'; });
                var empty = panel.querySelector('.mr-filter-empty');
                if (!visible.length) {
                    if (!empty) {
                        empty = document.createElement('div');
                        empty.className = 'mr-filter-empty';
                        empty.textContent = 'No records found for this category.';
                        var timeline = panel.querySelector('.modern-treatment-timeline');
                        if (timeline) timeline.appendChild(empty);
                    }
                    empty.style.display = '';
                } else if (empty) {
                    empty.style.display = 'none';
                }
            });
        });
    }
    document.addEventListener('DOMContentLoaded', initMedicalRecordFilters);
    if (document.readyState !== 'loading') initMedicalRecordFilters();
}());

// --- Extracted dashboard script 11 ---
let diorEmergCurrentPage = 1;
    const diorEmergRowsPerPage = 6;

    function diorGetEmergActiveRows() {
        const input = document.getElementById('dior-emerg-search-input');
        const filter = input ? input.value.toLowerCase() : '';
        const allRows = Array.from(document.querySelectorAll('#dior-emerg-tbody tr'));
        
        return allRows.filter(function(row) {
            const text = row.innerText.toLowerCase();
            return text.includes(filter);
        });
    }

    function diorRenderEmergPagination() {
        const activeRows = diorGetEmergActiveRows();
        const allRows = Array.from(document.querySelectorAll('#dior-emerg-tbody tr'));
        const totalPages = Math.ceil(activeRows.length / diorEmergRowsPerPage) || 1;

        if (diorEmergCurrentPage > totalPages) {
            diorEmergCurrentPage = totalPages;
        }
        if (diorEmergCurrentPage < 1) {
            diorEmergCurrentPage = 1;
        }

        allRows.forEach(row => row.style.display = 'none');

        const startIndex = (diorEmergCurrentPage - 1) * diorEmergRowsPerPage;
        const endIndex = startIndex + diorEmergRowsPerPage;
        const pageRows = activeRows.slice(startIndex, endIndex);

        pageRows.forEach(row => row.style.display = '');

        const pagContainer = document.getElementById('dior-emerg-pagination');
        if (pagContainer) {
            pagContainer.innerHTML = diorBuildPagerHtml(diorEmergCurrentPage, totalPages, 'diorGoEmergPage');
        }

        const pageCountEl = document.getElementById('dior-emerg-page-count');
        if (pageCountEl) {
            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
        }
    }

    function diorGoEmergPage(page) {
        diorEmergCurrentPage = page;
        diorRenderEmergPagination();
    }

    function diorFilterEmerg() {
        diorEmergCurrentPage = 1;
        diorRenderEmergPagination();
    }
    
    function diorDownloadEmergCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Contact Name,Relation,Phone Number,Priority\n";
        const activeRows = diorGetEmergActiveRows();
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 6) {
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                csvContent += `"${c1}","${c2}","${c3}","${c4}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "emergency_contacts.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    document.addEventListener('DOMContentLoaded', function() {
        diorRenderEmergPagination();
    });
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
        diorRenderEmergPagination();
    }

// --- Extracted dashboard script 12 ---
function diorSendChatMessage() {
            var input = document.getElementById('dior-chat-input');
            var container = document.getElementById('dior-chat-messages-container');
            if(!input || !container) return;
            var text = input.value.trim();
            if(!text) return;
            
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12;
            minutes = minutes < 10 ? '0'+minutes : minutes;
            var timeString = hours + ':' + minutes + ' ' + ampm;
            
            var msgHtml = `
                <div class="dior-ic-5d9c324602">
                    <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=100" class="dior-ic-5fc13777e2">
                    <div>
                        <div class="dior-ic-dff7aabfd2">
                            <span class="dior-ic-8fa9cd12a9">Sarah Jenkins</span>
                            <span class="dior-ic-0b48e6248d">${timeString}</span>
                        </div>
                        <div class="dior-ic-60cdfae882">
                            ${text.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', msgHtml);
            input.value = '';
            container.scrollTop = container.scrollHeight;
        }

// --- Extracted dashboard script 13 ---
let diorNotifCurrentPage = 1;
    const diorNotifRowsPerPage = 6;

    function diorGetNotifActiveRows() {
        const input = document.getElementById('dior-notif-search-input');
        const filter = input ? input.value.toLowerCase() : '';
        const allRows = Array.from(document.querySelectorAll('#dior-notif-tbody tr'));
        
        return allRows.filter(function(row) {
            const text = row.innerText.toLowerCase();
            return text.includes(filter);
        });
    }

    function diorRenderNotifPagination() {
        const activeRows = diorGetNotifActiveRows();
        const allRows = Array.from(document.querySelectorAll('#dior-notif-tbody tr'));
        const totalPages = Math.ceil(activeRows.length / diorNotifRowsPerPage) || 1;

        if (diorNotifCurrentPage > totalPages) {
            diorNotifCurrentPage = totalPages;
        }
        if (diorNotifCurrentPage < 1) {
            diorNotifCurrentPage = 1;
        }

        allRows.forEach(row => row.style.display = 'none');

        const startIndex = (diorNotifCurrentPage - 1) * diorNotifRowsPerPage;
        const endIndex = startIndex + diorNotifRowsPerPage;
        const pageRows = activeRows.slice(startIndex, endIndex);

        pageRows.forEach(row => row.style.display = '');

        const pagContainer = document.getElementById('dior-notif-pagination');
        if (pagContainer) {
            pagContainer.innerHTML = diorBuildPagerHtml(diorNotifCurrentPage, totalPages, 'diorGoNotifPage');
        }

        const pageCountEl = document.getElementById('dior-notif-page-count');
        if (pageCountEl) {
            pageCountEl.innerText = `0 selected / ${activeRows.length} total`;
        }
    }

    function diorGoNotifPage(page) {
        diorNotifCurrentPage = page;
        diorRenderNotifPagination();
    }

    function diorFilterNotif() {
        diorNotifCurrentPage = 1;
        diorRenderNotifPagination();
        diorUpdateNotifSelectionCount();
    }
    
    function diorDownloadNotifCSV() {
        let csvContent = "data:text/csv;charset=utf-8,Title,Message,Type,Date,Time,Status\n";
        const activeRows = diorGetNotifActiveRows();
        activeRows.forEach(function(row) {
            let cols = row.querySelectorAll('td');
            if(cols.length >= 7) {
                let c1 = cols[1].innerText.trim();
                let c2 = cols[2].innerText.trim();
                let c3 = cols[3].innerText.trim();
                let c4 = cols[4].innerText.trim();
                let c5 = cols[5].innerText.trim();
                let c6 = cols[6].innerText.trim();
                csvContent += `"${c1}","${c2}","${c3}","${c4}","${c5}","${c6}"\n`;
            }
        });
        var encodedUri = encodeURI(csvContent);
        var link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "notifications.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    function diorToggleSelectAllNotifs(masterCb) {
        const isChecked = masterCb.checked;
        const activeRows = diorGetNotifActiveRows();
        activeRows.forEach(row => {
            const cb = row.querySelector('.dior-notif-row-cb, input[type="checkbox"]');
            if (cb) cb.checked = isChecked;
        });
        diorUpdateNotifSelectionCount();
    }
    window.diorToggleSelectAllNotifs = diorToggleSelectAllNotifs;

    function diorUpdateNotifSelectionCount() {
        const activeRows = diorGetNotifActiveRows();
        const selected = activeRows.filter(row => {
            const cb = row.querySelector('.dior-notif-row-cb, input[type="checkbox"]');
            return cb && cb.checked;
        }).length;
        const countEl = document.getElementById('dior-notif-page-count');
        if (countEl) {
            countEl.innerText = `${selected} selected / ${activeRows.length} total`;
        }
        const masterCb = document.getElementById('dior-notif-select-all');
        if (masterCb) {
            masterCb.checked = activeRows.length > 0 && selected === activeRows.length;
        }
    }
    window.diorUpdateNotifSelectionCount = diorUpdateNotifSelectionCount;

    function diorBulkDeleteNotifications(btn) {
        const table = document.getElementById('dior-notif-table');
        if (!table) return;
        const checkedRows = Array.from(table.querySelectorAll('#dior-notif-tbody tr')).filter(row => {
            const cb = row.querySelector('.dior-notif-row-cb, input[type="checkbox"]');
            return cb && cb.checked;
        });

        if (checkedRows.length === 0) {
            Swal.fire({ icon: 'info', title: 'No Notifications Selected', text: 'Please select at least one notification to delete.' });
            return;
        }

        const notifIds = checkedRows.map(r => r.getAttribute('data-notif-id')).filter(Boolean);

        const doDelete = function() {
            const ajaxUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '';
            const nonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.portal_nonce) || (window.dior_vars && window.dior_vars.nonce) || '';

            const body = new URLSearchParams({
                action: 'dior_patient_bulk_delete_notifications',
                nonce: nonce
            });
            notifIds.forEach(id => body.append('notif_ids[]', id));

            fetch(ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            })
            .then(res => res.json())
            .then(data => {
                if (data && data.success) {
                    checkedRows.forEach(r => r.remove());
                    const masterCb = document.getElementById('dior-notif-select-all');
                    if (masterCb) masterCb.checked = false;
                    diorRenderNotifPagination();
                    diorUpdateNotifSelectionCount();
                    if (window.Swal) {
                        Swal.fire({ position: 'top-end', icon: 'success', title: data.data?.message || 'Notifications Deleted', showConfirmButton: false, timer: 1500 });
                    }
                } else {
                    Swal.fire({ icon: 'error', title: 'Error', text: (data && data.data && data.data.message) || 'Failed to delete notifications.' });
                }
            })
            .catch(() => {
                Swal.fire({ icon: 'error', title: 'Error', text: 'Network error deleting notifications.' });
            });
        };

        if (window.Swal) {
            Swal.fire({
                title: 'Delete Notifications?',
                text: `You are about to delete ${checkedRows.length} selected notification(s).`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Yes, delete!'
            }).then(result => {
                if (result.isConfirmed) {
                    doDelete();
                }
            });
        }
    }
    window.diorBulkDeleteNotifications = diorBulkDeleteNotifications;

    function diorMarkAllNotificationsRead() {
        const rows = Array.from(document.querySelectorAll('#dior-notif-tbody tr[data-notif-id]'));
        if (rows.length === 0) {
            Swal.fire({ icon: 'info', title: 'No Notifications', text: 'There are no notifications to mark as read.' });
            return;
        }

        const ajaxUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '';
        const nonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.portal_nonce) || (window.dior_vars && window.dior_vars.nonce) || '';

        const body = new URLSearchParams({
            action: 'dior_patient_mark_all_notifications_read',
            nonce: nonce
        });

        fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        })
        .then(res => res.json())
        .then(data => {
            if (data && data.success) {
                rows.forEach(r => {
                    const statusCell = r.querySelector('.dior-dyn-status');
                    if (statusCell) {
                        statusCell.textContent = 'Read';
                        statusCell.className = 'dior-dyn-status dior-dyn-bg-D1FAE5 dior-dyn-color-10B981';
                    }
                    const readBtn = r.querySelector('.dior-mark-notification-read');
                    if (readBtn) readBtn.remove();
                });
                const badges = document.querySelectorAll('.unread-badge-count');
                badges.forEach(b => b.style.display = 'none');
                if (window.Swal) {
                    Swal.fire({ position: 'top-end', icon: 'success', title: 'All marked as read', showConfirmButton: false, timer: 1500 });
                }
            }
        })
        .catch(() => {});
    }
    window.diorMarkAllNotificationsRead = diorMarkAllNotificationsRead;

    function diorRefreshNotifications() {
        const tbody = document.getElementById('dior-notif-tbody');
        const refreshIcon = document.querySelector('.action-btn-info i');
        if (refreshIcon) refreshIcon.classList.add('fa-spin');

        const ajaxUrl = (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '';
        const nonce = (window.dior_patient_dashboard && window.dior_patient_dashboard.portal_nonce) || (window.dior_vars && window.dior_vars.nonce) || '';

        const body = new URLSearchParams({
            action: 'dior_patient_get_live_notifications',
            nonce: nonce
        });

        fetch(ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        })
        .then(res => res.json())
        .then(data => {
            if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            if (data && data.success && data.data && data.data.full_html && tbody) {
                tbody.innerHTML = data.data.full_html;
                diorNotifCurrentPage = 1;
                diorRenderNotifPagination();
                diorUpdateNotifSelectionCount();
                if (window.Swal) {
                    Swal.fire({ position: 'top-end', icon: 'success', title: 'Notifications Refreshed', showConfirmButton: false, timer: 1000 });
                }
            } else {
                window.location.reload();
            }
        })
        .catch(() => {
            if (refreshIcon) refreshIcon.classList.remove('fa-spin');
            window.location.reload();
        });
    }
    window.diorRefreshNotifications = diorRefreshNotifications;

    let notifSortDirection = {};
    function diorSortNotifTable(colIndex) {
        const tbody = document.getElementById('dior-notif-tbody');
        if (!tbody) return;
        const rows = Array.from(tbody.querySelectorAll('tr:not(.dior-empty-state)'));
        if (rows.length === 0) return;

        notifSortDirection[colIndex] = !notifSortDirection[colIndex];
        const asc = notifSortDirection[colIndex];

        rows.sort((a, b) => {
            const cellA = (a.querySelectorAll('td')[colIndex]?.innerText || '').trim();
            const cellB = (b.querySelectorAll('td')[colIndex]?.innerText || '').trim();
            return asc ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA);
        });

        rows.forEach(r => tbody.appendChild(r));
        diorRenderNotifPagination();
    }
    window.diorSortNotifTable = diorSortNotifTable;

    // View Notification Details modal / alert
    document.addEventListener('click', function(e) {
        const viewBtn = e.target.closest('.dior-view-notif-btn');
        if (!viewBtn) return;
        const notifId = viewBtn.getAttribute('data-notif-id');
        const title = viewBtn.getAttribute('data-notif-title') || 'Notification';
        const message = viewBtn.getAttribute('data-notif-message') || '';
        const date = viewBtn.getAttribute('data-notif-date') || '';
        const type = viewBtn.getAttribute('data-notif-type') || 'Info';
        const actionUrl = viewBtn.getAttribute('data-notif-action') || '';

        // Auto mark as read on view
        if (notifId) {
            const row = viewBtn.closest('tr');
            const readBtn = row ? row.querySelector('.dior-mark-notification-read') : null;
            if (readBtn) readBtn.click();
        }

        const isMeetingAction = (actionUrl && /(zoom\.us|meet\.google\.com)/i.test(actionUrl)) ||
            /video consultation|patient joined|doctor started|meeting ready|telehealth/i.test(title + ' ' + message);
        if (isMeetingAction && actionUrl && /^https?:\/\//i.test(actionUrl)) {
            if (typeof diorShowMeetingJoinModal === 'function') {
                diorShowMeetingJoinModal({
                    id: notifId,
                    title: title,
                    message: message,
                    action_url: actionUrl
                }, true);
                return;
            }
        }

        const hasAction = actionUrl && actionUrl.trim() !== '';
        if (window.Swal) {
            Swal.fire({
                title: `<span style="font-size:18px;font-weight:700;color:#1e293b;">${title}</span>`,
                html: `
                    <div style="text-align:left;font-size:14px;color:#475569;line-height:1.6;margin-top:10px;">
                        <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center;">
                            <span style="font-size:11px;font-weight:600;padding:3px 10px;border-radius:12px;background:#e0e7ff;color:#1A528E;">${type}</span>
                            <span style="font-size:12px;color:#94a3b8;">${date}</span>
                        </div>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px;color:#334155;white-space:pre-wrap;">${message}</div>
                    </div>
                `,
                icon: 'info',
                showCancelButton: hasAction,
                confirmButtonText: hasAction ? 'Go to Page' : 'Close',
                cancelButtonText: 'Close',
                confirmButtonColor: '#3b82f6',
                cancelButtonColor: '#64748b'
            }).then(result => {
                if (result.isConfirmed && hasAction) {
                    if (actionUrl.startsWith('#tab=')) {
                        const tabName = actionUrl.replace('#tab=', '');
                        if (typeof diorSwitchTab === 'function') {
                            diorSwitchTab(tabName);
                        } else {
                            window.location.hash = actionUrl;
                        }
                    } else {
                        window.location.href = actionUrl;
                    }
                }
            });
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        diorRenderNotifPagination();
        diorUpdateNotifSelectionCount();
    });
    if (document.readyState === 'interactive' || document.readyState === 'complete') {
        diorRenderNotifPagination();
        diorUpdateNotifSelectionCount();
    }

// --- Extracted dashboard script 14 ---
window.dior_patient_appts_data = (window.dior_patient_dashboard && window.dior_patient_dashboard.appointments) || [];
        window.dior_patient_rxs_data = (window.dior_patient_dashboard && window.dior_patient_dashboard.prescriptions) || [];
        window.diorOpenModal = function (modalId) {
            var el = document.getElementById(modalId);
            if (el) {
                el.classList.add('open');
                el.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        };

        window.diorCloseModal = function (modalId) {
            var el = document.getElementById(modalId);
            if (el) {
                el.classList.remove('open');
                el.style.display = 'none';
                document.body.style.overflow = '';
            }
        };

        window.diorViewRxDetails = function (rxId, fallbackMed, fallbackInst) {
            var rxs = window.dior_patient_rxs_data || [];
            var found = null;
            if (rxs && rxs.length) {
                for (var i = 0; i < rxs.length; i++) {
                    var r = rxs[i];
                    if (String(r.id).trim().toLowerCase() === String(rxId).trim().toLowerCase() ||
                        (r.raw_ids && r.raw_ids.some(function (rid) { return String(rid).trim().toLowerCase() === String(rxId).trim().toLowerCase(); }))) {
                        found = r;
                        break;
                    }
                }
            }

            var idEl = document.getElementById('pat-modal-rx-id');
            var docEl = document.getElementById('pat-modal-rx-doc');
            var docHeaderEl = document.getElementById('pat-modal-rx-doc-header');
            var docCellEl = document.getElementById('pat-modal-rx-doc-name-cell');
            var dateEl = document.getElementById('pat-modal-rx-date');
            var routingEl = document.getElementById('pat-modal-rx-routing');
            var statusBadge = document.getElementById('pat-modal-rx-status-badge');
            var pharmNameEl = document.getElementById('pat-modal-rx-pharm-name');
            var adviceEl = document.getElementById('pat-modal-rx-advice');
            var pdfBtn = document.getElementById('pat-modal-rx-pdf-btn');
            var refillBtn = document.getElementById('pat-modal-rx-refill-btn');
            var tableBody = document.getElementById('pat-modal-rx-table-body');

            var actualId = found ? (found.id || rxId) : rxId;
            var rawDoc = found ? (found.prescribed_by || 'Dr. Marcus Sterling') : 'Dr. Marcus Sterling';
            var cleanDoc = rawDoc.replace(/^(Dr\.?\s*)+/i, 'Dr. ').replace(/\s*\(NPI:[^)]*\)/i, '').replace(/,\s*MD\b/i, '').replace(/\s*\bMD\b/i, '').trim();
            var actualDate = found ? (found.date_prescribed || found.date || '—') : '—';
            var actualRouting = found ? (found.routing_status || 'Sent to Pharmacy') : 'Sent to Pharmacy';
            var actualPharm = found ? (found.pharmacy || 'Preferred Pharmacy on File') : 'Preferred Pharmacy on File';

            if (idEl) idEl.textContent = 'Rx #' + actualId;
            if (docEl) docEl.textContent = cleanDoc;
            if (docHeaderEl) docHeaderEl.innerHTML = '<span>' + escapeHtml(cleanDoc) + ', MD</span>';
            if (docCellEl) docCellEl.textContent = cleanDoc + ', MD';
            if (dateEl) dateEl.textContent = actualDate;
            var padDateEl = document.getElementById('pat-modal-rx-pad-date');
            if (padDateEl) padDateEl.textContent = actualDate;

            // Dynamically populate patient demographics (Patient Name, Date, Age, Gender, Weight, Diagnosis)
            var patNameEl = document.getElementById('pat-modal-rx-pat-name');
            var patAgeEl = document.getElementById('pat-modal-rx-pat-age');
            var patGenderEl = document.getElementById('pat-modal-rx-pat-gender');
            var patWeightEl = document.getElementById('pat-modal-rx-pat-weight');
            var patDiagEl = document.getElementById('pat-modal-rx-diagnosis');

            var profileObj = (window.dior_vars && window.dior_vars.patient_profile) || {};
            var patName = (found && (found.patient_name || found.patient)) || profileObj.full_name || (window.dior_patient_dashboard && window.dior_patient_dashboard.patient && window.dior_patient_dashboard.patient.name) || 'Patient';
            var patGender = (found && found.patient_gender) || profileObj.gender || '—';
            var rawWeight = (found && found.patient_weight) || profileObj.weight || '';
            var patWeight = rawWeight ? (isFinite(rawWeight) ? rawWeight + ' kg' : rawWeight) : '—';
            var patDiag = (found && (found.diagnosis || found.condition || found.title)) || 'Clinical Telehealth Consultation';
            if (patDiag === 'General Medical Prescription' || patDiag === 'Prescription') {
                patDiag = 'Clinical Telehealth Consultation';
            }

            var patAge = '—';
            var dob = (found && found.patient_dob) || profileObj.dob;
            if (dob) {
                var d = new Date(dob);
                if (!isNaN(d.getTime())) {
                    var ageDiff = new Date().getFullYear() - d.getFullYear();
                    patAge = ageDiff + ' years';
                }
            } else if (found && found.patient_age) {
                patAge = found.patient_age;
            }

            if (patNameEl) patNameEl.textContent = patName;
            if (patAgeEl) patAgeEl.textContent = patAge;
            if (patGenderEl) patGenderEl.textContent = patGender ? (patGender.charAt(0).toUpperCase() + patGender.slice(1)) : '—';
            if (patWeightEl) patWeightEl.textContent = patWeight;
            if (patDiagEl) patDiagEl.textContent = patDiag;

            if (routingEl) routingEl.innerHTML = '<i class="fa-solid fa-circle-check dior-ic-2eb9f328f2"></i> ' + actualRouting;
            if (statusBadge) statusBadge.innerHTML = '<i class="fa-solid fa-check"></i> ' + (found.routing_status || (actualRouting === 'Sent to Pharmacy' ? 'Transmission Confirmed' : actualRouting));
            if (pharmNameEl) pharmNameEl.textContent = actualPharm;
            function escapeHtml(str) {
                if (!str) return '';
                var d = document.createElement('div');
                d.textContent = str;
                return d.innerHTML;
            }

            var items = [];
            if (found && found.items && found.items.length) {
                items = found.items;
            } else {
                var rawMedText = (found ? (found.medication || found.name) : '') || fallbackMed || 'Prescription Medication';
                var rawDosageText = (found ? (found.dosage || found.dose) : '') || 'As Prescribed';
                var rawInstText = (found ? (found.instructions || found.notes) : '') || fallbackInst || 'Take as directed by prescribing physician.';

                var medParts = rawMedText.split(/;\s*|\r\n|\n/).map(function(s) { return s.trim(); }).filter(Boolean);
                var doseParts = rawDosageText.split(/\|\s*|;\s*|\r\n|\n/).map(function(s) { return s.trim(); }).filter(Boolean);
                var instParts = rawInstText.split(/\|\|\s*|\r\n|\n/).map(function(s) { return s.trim(); }).filter(Boolean);

                if (medParts.length > 1) {
                    items = medParts.map(function(m, idx) {
                        return {
                            id: actualId + '-' + (idx + 1),
                            medication: m.replace(/^\d+\.\s*/, ''),
                            dosage: doseParts[idx] ? doseParts[idx].replace(/^\d+\.\s*/, '') : rawDosageText,
                            instructions: instParts[idx] ? instParts[idx].replace(/^\d+\.\s*/, '') : rawInstText,
                            quantity: (found ? found.quantity : '') || 'As Prescribed',
                            refills: (found ? found.refills : '') || '0 Refills Remaining'
                        };
                    });
                } else {
                    items = [{
                        id: actualId + '-1',
                        medication: rawMedText,
                        dosage: rawDosageText,
                        instructions: rawInstText,
                        quantity: (found ? found.quantity : '') || 'As Prescribed',
                        refills: (found ? found.refills : '') || '0 Refills Remaining'
                    }];
                }
            }

            if (tableBody) {
                var html = '';
                var adviceNotes = [];
                for (var j = 0; j < items.length; j++) {
                    var it = items[j];
                    var itemUid = (it && it.id) ? it.id : (actualId + '-' + (j + 1));
                    var medName = escapeHtml(it.medication);
                    var doseStr = escapeHtml(it.dosage);
                    var sigStr = escapeHtml(it.instructions || it.dosage || 'Take as directed by physician.');
                    var qtyStr = escapeHtml(it.quantity || 'As Prescribed');
                    var refillStr = escapeHtml(it.refills || '0 Refills Remaining');

                    if (it.notes && it.notes !== sigStr) {
                        adviceNotes.push(escapeHtml(it.notes));
                    }

                    var formattedMed = medName;
                    if (!/^(TAB|CAP|SYR|INJ|SOL)\b/i.test(formattedMed)) {
                        formattedMed = 'TAB. ' + formattedMed;
                    }

                    html += '<tr>' +
                        '<td class="text-secondary small fw-bold text-center align-top pt-3" style="width: 32px;">' + (j + 1) + '</td>' +
                        '<td class="align-top py-2.5">' +
                        '<div class="fw-bold text-dark fs-6 mb-1">' + formattedMed + '</div>' +
                        '<div class="d-flex align-items-center gap-2 flex-wrap small">' +
                        '<span class="badge bg-light text-secondary border">Rx Item: ' + escapeHtml(itemUid) + '</span>' +
                        '<span class="badge bg-success-subtle text-success border border-success-subtle"><i class="fa-solid fa-check me-1"></i>FDA Approved</span>' +
                        '<span class="text-muted small">Oral Formulation &bull; Single Patient</span>' +
                        '</div>' +
                        '</td>' +
                        '<td class="align-top py-2.5">' +
                        '<div class="small mb-1"><strong class="text-primary text-uppercase me-1">SIG:</strong> <span class="text-dark fw-medium">' + sigStr + '</span></div>' +
                        '<div class="small text-muted">Dosage: <strong class="text-dark">' + doseStr + '</strong> &bull; Route: Oral</div>' +
                        '</td>' +
                        '<td class="align-top py-2.5 text-nowrap">' +
                        '<div class="fw-bold text-dark small mb-0.5">Qty: ' + qtyStr + '</div>' +
                        '<div class="small text-secondary mb-1">' + refillStr + '</div>' +
                        '<span class="badge bg-light text-secondary border small">DAW-0 (Generic Auth)</span>' +
                        '</td>' +
                        '</tr>';
                }
                tableBody.innerHTML = html;

                if (adviceEl) {
                    var adviceHtml = '&bull; Take medication strictly as directed with a full glass of water.<br>' +
                        '&bull; Complete the full course of treatment unless instructed otherwise by your doctor.<br>' +
                        '&bull; Avoid alcohol during the active course of treatment.';
                    if (adviceNotes.length > 0) {
                        adviceHtml += '<br>&bull; <strong>Physician Notes:</strong> ' + adviceNotes.join('; ');
                    }
                    adviceEl.innerHTML = adviceHtml;
                }
            }

            if (pdfBtn) {
                pdfBtn.onclick = function () { window.diorDownloadRxPdf(actualId); };
            }
            if (refillBtn) {
                refillBtn.onclick = function () { window.diorRequestRefill(actualId); };
            }

            window.diorOpenModal('modal-view-rx-detail');
        };

        window.diorRequestRefill = function (rxId) {
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Refill Requested',
                text: 'Refill request submitted electronically to prescribing physician for Rx #' + rxId,
                showConfirmButton: false,
                timer: 2500
            });
        };

        window.diorViewDocumentModal = function (title, category, author, date, id) {
            var t = document.getElementById('doc-preview-title');
            var c = document.getElementById('doc-preview-category');
            var a = document.getElementById('doc-preview-author');
            var d = document.getElementById('doc-preview-date');
            var i = document.getElementById('doc-preview-id');
            if (t) t.textContent = title || 'Medical Record';
            if (c) c.textContent = category || 'Official Document';
            if (a) a.textContent = author || 'Dior Medical Urgent Care';
            if (d) d.textContent = date || '';
            if (i) i.textContent = id || 'DOC-88219';
            window.diorOpenModal('modal-view-document');
        };

        window.diorViewAppointmentDetails = function (apptId) {
            var appts = window.dior_patient_appts_data || [];
            var found = null;
            for (var i = 0; i < appts.length; i++) {
                if (String(appts[i].id) === String(apptId) || String(appts[i].appt_uid) === String(apptId)) {
                    found = appts[i];
                    break;
                }
            }

            var idEl = document.getElementById('pat-modal-appt-id');
            var provEl = document.getElementById('pat-modal-appt-provider');
            var specEl = document.getElementById('pat-modal-appt-spec');
            var statusBadge = document.getElementById('pat-modal-appt-status-badge');
            var dtEl = document.getElementById('pat-modal-appt-datetime');
            var modeEl = document.getElementById('pat-modal-appt-mode');
            var condEl = document.getElementById('pat-modal-appt-condition');
            var notesEl = document.getElementById('pat-modal-appt-notes');
            var zoomWrap = document.getElementById('pat-modal-zoom-wrap');
            var zoomLink = document.getElementById('pat-modal-zoom-link');

            if (found) {
                if (idEl) idEl.textContent = 'APPT #' + (found.id || found.appt_uid || apptId);
                if (provEl) provEl.textContent = found.provider || found.doctor_name || 'Attending Physician';
                if (specEl) specEl.textContent = found.provider_spec || found.provider_title || 'Telehealth Urgent Care';
                if (statusBadge) {
                    var st = found.status || found.appt_status || 'Confirmed';
                    statusBadge.textContent = st;
                    statusBadge.className = 'dior-st ' + (st === 'Confirmed' || st === 'Completed' ? 'ok' : (st === 'Cancelled' ? 'error' : 'pending'));
                }
                if (dtEl) dtEl.textContent = (found.date || found.appt_date || '') + ' ' + (found.time || found.appt_time || '');
                if (modeEl) modeEl.innerHTML = '<i class="fa-solid fa-video dior-ic-be91c47dad"></i> ' + (found.type || found.visit_type || 'Video Visit');
                if (condEl) condEl.textContent = found.condition || found.condition_name || 'Telehealth Consultation';
                if (notesEl) notesEl.textContent = found.notes || 'Standard telehealth clinical consultation scheduled. All submitted medical intake questionnaires are pre-verified.';

                var joinUrl = found.join_url || '';
                var isLive = ['confirmed', 'scheduled', 'success', 'in progress', 'in-queue'].indexOf(String(found.status || found.appt_status || '').toLowerCase()) !== -1;
                var isValidJoinUrl = /^https:\/\//i.test(joinUrl);
                if (zoomWrap) {
                    zoomWrap.style.display = (isLive && isValidJoinUrl) ? 'flex' : 'none';
                    if (zoomLink) zoomLink.href = isValidJoinUrl ? joinUrl : '#';
                }
            } else if (idEl) {
                idEl.textContent = 'APPT #' + apptId;
            }

            window.diorOpenModal('modal-view-appointment-detail');
        };

        window.diorDownloadCurrentDocumentPdf = function () {
            var title = (document.getElementById('doc-preview-title') && document.getElementById('doc-preview-title').textContent) || 'Clinical Medical Certificate';
            var docId = (document.getElementById('doc-preview-id') && document.getElementById('doc-preview-id').textContent) || 'DOC-88219';
            var cat = (document.getElementById('doc-preview-category') && document.getElementById('doc-preview-category').textContent) || 'Official Document';
            var author = (document.getElementById('doc-preview-author') && document.getElementById('doc-preview-author').textContent) || 'Dr. Marcus Sterling, MD';
            var date = (document.getElementById('doc-preview-date') && document.getElementById('doc-preview-date').textContent) || 'Sept 14, 2026';
            var patientName = (document.getElementById('doc-preview-patient') && document.getElementById('doc-preview-patient').textContent) || 'Verified Patient';

            var logoUrl = (window.dior_vars && window.dior_vars.logo_url) ? window.dior_vars.logo_url : '';
            var docSigUrl = (window.dior_vars && window.dior_vars.default_doctor_signature) ? window.dior_vars.default_doctor_signature : '';

            var cleanFileName = 'Dior-' + title.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var sigHtml = '';
            if (docSigUrl) {
                sigHtml = '<img src="' + docSigUrl + '" alt="Doctor Signature" class="dior-ic-f119b60852">';
            } else {
                sigHtml = '<span class="dior-ic-c127c4ee04">/s/ ' + author + '</span>';
            }

            var printContent = '<div class="dior-ic-4e97191df6">' +
                '<!-- Logo Watermark -->' +
                '<div class="dior-ic-2dca51d9b9">' +
                '<img src="' + logoUrl + '" alt="" class="dior-ic-61a516548a">' +
                '</div>' +
                '<div class="dior-ic-e544702ffd">' +
                '<!-- Top Header: Logo on Left, Clinic Details on Right -->' +
                '<table class="dior-ic-1290c468f2">' +
                '<tr>' +
                '<td class="dior-ic-5578310519">' +
                '<div class="dior-ic-34fd8ff897">' +
                '<img src="' + logoUrl + '" alt="Dior Medical" class="dior-ic-b7e858e031">' +
                '<div>' +
                '<div class="dior-ic-be9709a90d">DIOR MEDICAL</div>' +
                '<div class="dior-ic-504d7a84a3">TELEHEALTH &bull; VIRTUAL URGENT CARE</div>' +
                '<div class="dior-ic-1f31aa02a5">Clinical Telemedicine Division &bull; Surescripts Certified</div>' +
                '</div>' +
                '</div>' +
                '</td>' +
                '<td class="dior-ic-a4e1c0e520">' +
                '<div class="dior-ic-f113437294">+1 (800) 555-DIOR</div>' +
                '<div>www.diormedical.com &bull; care@diormedical.com</div>' +
                '<div>100 Medical Plaza, Suite 400</div>' +
                '<div class="dior-ic-bb89dd9892">Doc Ref: <strong class="dior-ic-1a41cb2399">' + docId + '</strong></div>' +
                '</td>' +
                '</tr>' +
                '</table>' +

                '<!-- Recipient & Date Bar (Exact Match to Reference Letterhead) -->' +
                '<table class="dior-ic-153b4cb4de">' +
                '<tr>' +
                '<td class="dior-ic-e998f6b88b">' +
                '<div class="dior-ic-b0a7f14502">TO:</div>' +
                '<div class="dior-ic-3934b99ce3">' + patientName + '</div>' +
                '<div class="dior-ic-6efa43ac99">Dior Medical Telehealth Patient Registry &bull; Verified Record</div>' +
                '</td>' +
                '<td class="dior-ic-bdab288cbf">' +
                '<div class="dior-ic-6bad4995ba">' + date + '</div>' +
                '<div class="dior-ic-9e35db7fae">&#10003; HIPAA Certified</div>' +
                '</td>' +
                '</tr>' +
                '</table>' +

                '<!-- Document Subject Banner -->' +
                '<div class="dior-ic-5f5ee0a219">' +
                '<span class="dior-ic-8f438ba192">' + cat + '</span>' +
                '<h2 class="dior-ic-8562135e54">' + title + '</h2>' +
                '</div>' +

                '<!-- Salutation -->' +
                '<p class="dior-ic-89e78b203c">Dear ' + patientName + ',</p>' +

                '<!-- Clinical Statement Body -->' +
                '<div class="dior-ic-e8b72bdfbb">' +
                '<p class="dior-ic-777d73194a">This official medical document confirms that you have satisfactorily completed your clinical telehealth consultation with Dior Medical Telehealth. All clinical assessments, patient intake questionnaires, and healthcare evaluations were conducted in strict compliance with state and federal telemedicine practice guidelines.</p>' +
                '<p class="dior-ic-777d73194a">The attending clinical provider has reviewed your health status and rendered the clinical determinations documented herein for <strong>' + title + '</strong> under clinical directive <strong>' + cat + '</strong>. All clinical guidance, medical advice, and instructions have been communicated directly through the encrypted secure patient portal.</p>' +
                '<p class="dior-ic-add2ef3fed">This certified electronic clinical record is cryptographically archived and protected under 45 CFR Parts 160 and 164 (HIPAA Security &amp; Privacy Rules) and DEA Title 21 electronic healthcare regulations.</p>' +
                '</div>' +

                '<!-- Sign-off & Electronic Signature (Exact Image Match) -->' +
                '<table class="dior-ic-edb5e701ab">' +
                '<tr>' +
                '<td class="dior-ic-844ca8103e">' +
                '<strong class="dior-ic-2eb9f328f2">&#10003; Cryptographically Certified Electronic Record</strong><br>' +
                'Security Hash: SHA-256 Verified &bull; Federal ESIGN &amp; UETA Act Compliant<br>' +
                'DEA 21 CFR Part 1311 &bull; Surescripts Real-Time EDI Network' +
                '</td>' +
                '<td class="dior-ic-1b4e3085b1">' +
                '<div class="dior-ic-022c3acb10">Sincerely yours,</div>' +
                '<div class="dior-ic-9e400e21a8">' +
                sigHtml +
                '</div>' +
                '<div class="dior-ic-03bccab797">' + author + '</div>' +
                '<div class="dior-ic-a9370e80c1">Attending Telemedicine Physician &bull; Dior Medical</div>' +
                '<div class="dior-ic-b11064f3b0">DEA: MV8492019 &bull; NPI: 1849201948 &bull; Verified</div>' +
                '</td>' +
                '</tr>' +
                '</table>' +
                '</div>' +
                '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '0';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.style.zIndex = '-999999';
            tempContainer.style.background = '#FFFFFF';
            tempContainer.style.opacity = '1';
            tempContainer.style.pointerEvents = 'none';
            tempContainer.style.margin = '0';
            tempContainer.style.padding = '0';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined' && html2pdf) {
                var opt = {
                    margin: [8, 8, 8, 8],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        scrollY: 0,
                        scrollX: 0,
                        windowWidth: 794
                    },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
                    pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
                };
                try {
                    html2pdf().set(opt).from(tempContainer.firstElementChild || tempContainer).save().then(function () {
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    }).catch(function (err) {
                        console.error('PDF export error:', err);
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                        fallbackPrintWindow(printContent, title);
                    });
                } catch (e) {
                    console.error('PDF generation error:', e);
                    if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    fallbackPrintWindow(printContent, title);
                }
            } else {
                console.warn('html2pdf library not loaded, falling back to print');
                if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                fallbackPrintWindow(printContent, title);
            }
        };

        function fallbackPrintWindow(htmlContent, title) {
            var printWindow = window.open('', '_blank');
            if (printWindow) {
                printWindow.document.write('<html><head><title>' + title + '</title><link rel="stylesheet" href="' + ((window.dior_patient_dashboard && window.dior_patient_dashboard.refactor_css_url) || '') + '"></head><body class="dior-print-document">' + htmlContent + '</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(function () { printWindow.print(); }, 250);
            } else {
                window.print();
            }
        }

        window.diorDownloadReceiptPdf = function () {
            var invId = (document.getElementById('rec-inv-id') && document.getElementById('rec-inv-id').textContent) || 'INV-8829';
            var date = (document.getElementById('rec-date') && document.getElementById('rec-date').textContent) || 'Sept 4, 2026';
            var patientInfo = (document.getElementById('rec-patient-info') && document.getElementById('rec-patient-info').textContent) || 'Patient';
            var service = (document.getElementById('rec-service') && document.getElementById('rec-service').textContent) || 'Urgent Care Telehealth Consultation';
            var amount = (document.getElementById('rec-amount') && document.getElementById('rec-amount').textContent) || '$49.00';
            var logoUrl = (window.dior_vars && window.dior_vars.logo_url) ? window.dior_vars.logo_url : '';

            var cleanFileName = 'Dior-Receipt-' + invId.replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';

            var printContent = '<div class="dior-ic-1b6ae23462">' +
                '<div class="dior-receipt-print-wrapper">' +
                '<div class="dior-receipt-header-box">' +
                '<img src="' + logoUrl + '" alt="Dior Medical">' +
                '<h1>DIOR MEDICAL TELEHEALTH</h1>' +
                '<p>Official Medical Statement &amp; Itemized Receipt</p>' +
                '</div>' +

                '<table class="dior-receipt-table">' +
                '<tr>' +
                '<td class="label-col">Invoice #:</td>' +
                '<td class="val-col">' + invId + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td class="label-col">Date of Transaction:</td>' +
                '<td>' + date + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td class="label-col">Patient Name &amp; ID:</td>' +
                '<td>' + patientInfo + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td class="label-col">Service Description:</td>' +
                '<td>' + service + '</td>' +
                '</tr>' +
                '<tr>' +
                '<td class="label-col">Payment Method:</td>' +
                '<td>Stripe (Credit Card / Apple Pay) &bull; Verified &bull; Paid in Full</td>' +
                '</tr>' +
                '<tr class="total-row">' +
                '<td class="label-col">Total Paid:</td>' +
                '<td class="val-col">' + amount + '</td>' +
                '</tr>' +
                '</table>' +

                '<div class="dior-receipt-notice">' +
                '<strong>Tax Compliance &amp; Insurance Reimbursement Notice:</strong><br>' +
                'Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for HSA / FSA Flexible Spending Account Reimbursement' +
                '</div>' +

                '<table class="dior-receipt-footer">' +
                '<tr>' +
                '<td class="left-col">' +
                '<strong>&#10003; Official Electronic Payment Receipt</strong><br>' +
                'Transaction ID: ' + invId + ' &bull; Status: Completed' +
                '</td>' +
                '<td class="right-col">' +
                '<div class="signature-line">' +
                'Dior Billing Directorate' +
                '</div>' +
                '<div class="signature-title">Authorized Financial Officer</div>' +
                '</td>' +
                '</tr>' +
                '</table>' +
                '</div>';

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '0';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.style.zIndex = '-999999';
            tempContainer.style.background = '#FFFFFF';
            tempContainer.style.opacity = '1';
            tempContainer.style.pointerEvents = 'none';
            tempContainer.style.margin = '0';
            tempContainer.style.padding = '0';
            tempContainer.innerHTML = printContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined' && html2pdf) {
                var opt = {
                    margin: [8, 8, 8, 8],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        scrollY: 0,
                        scrollX: 0,
                        windowWidth: 794
                    },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
                    pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
                };
                try {
                    html2pdf().set(opt).from(tempContainer.firstElementChild || tempContainer).save().then(function () {
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    }).catch(function (err) {
                        console.error('PDF receipt export error:', err);
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                        fallbackPrintWindow(printContent, invId);
                    });
                } catch (e) {
                    console.error('PDF generation error:', e);
                    if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    fallbackPrintWindow(printContent, invId);
                }
            } else {
                console.warn('html2pdf library not loaded, falling back to print');
                if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                fallbackPrintWindow(printContent, invId);
            }
        };

        window.diorPrintReceiptModal = function () {
            window.diorDownloadReceiptPdf();
        };

        window.diorDownloadRxPdf = function (rxId) {
            var element = document.getElementById('rx-pdf-template-' + rxId);
            if (!element) {
                var allTemplates = document.querySelectorAll('[id^="rx-pdf-template-"]');
                if (allTemplates && allTemplates.length > 0) {
                    for (var k = 0; k < allTemplates.length; k++) {
                        var rawIds = (allTemplates[k].getAttribute('data-raw-ids') || '').split(',');
                        if (allTemplates[k].id.indexOf(rxId) !== -1 || rawIds.indexOf(String(rxId)) !== -1) {
                            element = allTemplates[k];
                            break;
                        }
                    }
                }
            }
            if (!element) { Swal.fire({ title: 'Not Found', text: 'Prescription details not found for Rx #' + rxId, icon: 'warning' }); return; }

            var cleanFileName = 'Dior-Prescription-' + String(rxId).replace(/[^a-zA-Z0-9]/g, '-') + '.pdf';
            var innerContent = element.innerHTML;

            var tempContainer = document.createElement('div');
            tempContainer.style.position = 'fixed';
            tempContainer.style.left = '0';
            tempContainer.style.top = '0';
            tempContainer.style.width = '750px';
            tempContainer.style.background = '#FFFFFF';
            tempContainer.style.zIndex = '-999999';
            tempContainer.style.opacity = '1';
            tempContainer.style.pointerEvents = 'none';
            tempContainer.style.margin = '0';
            tempContainer.style.padding = '0';
            tempContainer.innerHTML = innerContent;
            document.body.appendChild(tempContainer);

            if (typeof html2pdf !== 'undefined' && html2pdf) {
                var opt = {
                    margin: [6, 6, 6, 6],
                    filename: cleanFileName,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: {
                        scale: 2,
                        useCORS: true,
                        logging: false,
                        scrollY: 0,
                        scrollX: 0,
                        windowWidth: 794
                    },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
                    pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
                };
                try {
                    html2pdf().set(opt).from(tempContainer.firstElementChild || tempContainer).save().then(function () {
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    }).catch(function (err) {
                        console.error('PDF export error:', err);
                        if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                        fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
                    });
                } catch (e) {
                    console.error('PDF generation error:', e);
                    if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                    fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
                }
            } else {
                console.warn('html2pdf library not loaded, falling back to print');
                if (tempContainer.parentNode) tempContainer.parentNode.removeChild(tempContainer);
                fallbackPrintWindow(innerContent, 'Prescription #' + rxId);
            }
        };

        function diorInitThemeMode() {
            localStorage.removeItem('dior_theme_mode');
            var portal = document.getElementById('dior-patient-portal-app') || document.body;
            if (portal) {
                portal.classList.remove('dior-dark-theme');
            }
        }

        if (typeof window.diorInitTablePagination !== 'function') {
            window.diorInitTablePagination = function (tableEl, pageSize) {
                if (!tableEl) return;
                pageSize = pageSize || 5;
                var tbody = tableEl.querySelector('tbody');
                if (!tbody) return;

                var parent = tableEl.parentElement;
                var paginationWrap = parent.querySelector(':scope > .dior-table-pagination') || (parent.parentElement ? parent.parentElement.querySelector(':scope > .dior-table-pagination') : null);

                if (!paginationWrap) {
                    paginationWrap = document.createElement('div');
                    paginationWrap.className = 'dior-table-pagination';
                    if (parent.classList.contains('dior-table-responsive') || parent.classList.contains('dior-card-body') || parent.style.overflowX === 'auto' || parent.style.overflow === 'auto') {
                        parent.after(paginationWrap);
                    } else {
                        parent.appendChild(paginationWrap);
                    }
                }

                var currentPage = 1;

                function renderPage(page) {
                    currentPage = page || 1;
                    var allRows = Array.from(tbody.querySelectorAll(':scope > tr')).filter(function (tr) {
                        return !tr.classList.contains('dior-no-data-row') && tr.querySelectorAll(':scope > td').length > 0;
                    });

                    if (allRows.length === 0) {
                        paginationWrap.style.display = 'none';
                        paginationWrap.innerHTML = '';
                        return;
                    }

                    var activeRows = allRows.filter(function (tr) {
                        return tr.getAttribute('data-filter-hidden') !== 'true';
                    });
                    var total = activeRows.length;
                    var totalPages = Math.max(1, Math.ceil(total / pageSize));

                    // If total entries are 5 or fewer, or only 1 page exists, show all rows and hide pagination bar completely
                    if (total <= pageSize || totalPages <= 1) {
                        allRows.forEach(function (tr) {
                            if (tr.getAttribute('data-filter-hidden') === 'true') {
                                tr.style.display = 'none';
                            } else {
                                tr.style.display = '';
                            }
                        });
                        paginationWrap.style.display = 'none';
                        paginationWrap.innerHTML = '';
                        return;
                    }

                    if (currentPage > totalPages) currentPage = totalPages;
                    if (currentPage < 1) currentPage = 1;

                    var startIndex = (currentPage - 1) * pageSize;
                    var endIndex = startIndex + pageSize;

                    allRows.forEach(function (tr) {
                        if (tr.getAttribute('data-filter-hidden') === 'true') {
                            tr.style.display = 'none';
                        }
                    });

                    activeRows.forEach(function (tr, index) {
                        if (index >= startIndex && index < endIndex) {
                            tr.style.display = '';
                        } else {
                            tr.style.display = 'none';
                        }
                    });

                    var fromItem = total === 0 ? 0 : startIndex + 1;
                    var toItem = Math.min(endIndex, total);

                    var navHtml = '';
                    if (totalPages > 1) {
                        navHtml += '<button type="button" class="dior-page-btn" ' + (currentPage === 1 ? 'disabled' : '') + ' data-page="' + (currentPage - 1) + '" title="Previous Page"><i class="fa-solid fa-chevron-left dior-ic-c2e1a240e8"></i></button>';

                        if (totalPages <= 7) {
                            for (var i = 1; i <= totalPages; i++) {
                                navHtml += '<button type="button" class="dior-page-btn ' + (i === currentPage ? 'active' : '') + '" data-page="' + i + '">' + i + '</button>';
                            }
                        } else {
                            for (var i = 1; i <= totalPages; i++) {
                                if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                                    navHtml += '<button type="button" class="dior-page-btn ' + (i === currentPage ? 'active' : '') + '" data-page="' + i + '">' + i + '</button>';
                                } else if (i === currentPage - 2 || i === currentPage + 2) {
                                    navHtml += '<span class="dior-ic-82d73650e1">...</span>';
                                }
                            }
                        }

                        navHtml += '<button type="button" class="dior-page-btn" ' + (currentPage === totalPages ? 'disabled' : '') + ' data-page="' + (currentPage + 1) + '" title="Next Page"><i class="fa-solid fa-chevron-right dior-ic-c2e1a240e8"></i></button>';
                    }

                    paginationWrap.style.display = 'flex';
                    paginationWrap.innerHTML = '<div class="dior-pagination-info">Showing <strong>' + fromItem + '</strong> to <strong>' + toItem + '</strong> of <strong>' + total + '</strong> entries</div><div class="dior-pagination-nav">' + navHtml + '</div>';

                    paginationWrap.querySelectorAll('.dior-page-btn[data-page]').forEach(function (btn) {
                        btn.onclick = function (e) {
                            e.preventDefault();
                            var p = parseInt(this.getAttribute('data-page'), 10);
                            if (!isNaN(p)) renderPage(p);
                        };
                    });
                }

                tableEl._diorRenderPage = renderPage;
                renderPage(1);
            };
        }

        function initAllDiorTablePaginations() {
            diorInitThemeMode();
            document.querySelectorAll('.dior-table, .dior-clean-table, .dior-doc-table').forEach(function (table) {
                if (typeof window.diorInitTablePagination === 'function') {
                    window.diorInitTablePagination(table, 5);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', initAllDiorTablePaginations);
        if (document.readyState === 'interactive' || document.readyState === 'complete') {
            initAllDiorTablePaginations();
        }



// Robust Patient Dashboard main-tab navigation fallback.
// This is intentionally independent from the larger dashboard controller so that
// one unrelated widget error can never disable the sidebar navigation.
(function () {
    'use strict';

    // Hash as it was before any other controller touched it, so the tab the user
    // refreshed on is still the tab that gets restored.
    var diorInitialHash = window.location.hash || '';

    function switchPatientTab(tabId, updateHash) {
        // Accept the full deep-link shape ("appointments&subtab=today").
        var requestedSubTab = null;
        if (typeof tabId === 'string') {
            if (tabId.indexOf('&subtab=') !== -1) {
                var subParts = tabId.split('&subtab=');
                tabId = subParts[0];
                requestedSubTab = subParts[1] || null;
            }
            if (tabId.indexOf('#tab=') === 0) tabId = tabId.substring(5);
        }

        if (tabId === 'profile') tabId = 'settings';

        var panel = document.getElementById('tab-' + tabId);
        if (!panel) {
            return false;
        }

        document.querySelectorAll('.dior-nav-btn[data-tab]').forEach(function (btn) {
            // A submenu parent row (Appointments) opens its list; it must not
            // take the .active fill. That fill is reserved for leaf rows and
            // is exactly the background the doctor sidebar never shows here.
            if (btn.getAttribute('data-tab') === tabId && !diorIsSubmenuParentBtn(btn)) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        document.querySelectorAll('.dior-tab-panel').forEach(function (item) {
            if (item.id === 'tab-' + tabId) {
                item.classList.add('active');
                item.style.setProperty('display', 'block', 'important');
                item.style.setProperty('visibility', 'visible', 'important');
                item.style.setProperty('opacity', '1', 'important');
            } else {
                item.classList.remove('active');
                item.style.setProperty('display', 'none', 'important');
            }
        });

        // Sync subtab pills in in-page navigation bars
        document.querySelectorAll('.dior-subtab-pill[data-patient-tab]').forEach(function(pill) {
            if (pill.getAttribute('data-patient-tab') === tabId) {
                pill.classList.add('active');
            } else {
                pill.classList.remove('active');
            }
        });


        var title = document.getElementById('dior-current-page-title');
        var titles = {
            overview: 'Patient Overview',
            appointments: 'Telehealth Appointments',
            docs_meds: 'Medical Docs & Prescriptions',
            telemedicine: 'Telemedicine',
            medical_record: 'Medical Record',
            payments: 'Billing & Payment Statements',
            insurance: 'Insurance Claim',
            documents: 'Documents & Reports',
            emergency: 'Emergency Support',
            feedback: 'Feedback & Support',
            notifications: 'Notification Inbox',
            consultation: 'Consultation Room',
            settings: 'Settings',
            questionnaire: 'Clinical Intake Questionnaires'
        };
        if (title && titles[tabId]) title.textContent = titles[tabId];

        if (tabId !== 'appointments') {
            var w = document.getElementById('dior-appt-dropdown-wrap');
            if (w) {
                w.classList.remove('open');
                if (typeof diorSetApptToggleIcon === 'function') diorSetApptToggleIcon(w, false);
            }
        }

        if (updateHash !== false && window.history && window.history.replaceState) {
            window.history.replaceState(null, '', '#tab=' + encodeURIComponent(tabId));
        }

        if (tabId === 'appointments' && requestedSubTab &&
            typeof window.diorSwitchApptSubTab === 'function') {
            window.diorSwitchApptSubTab(requestedSubTab);
        }

        return true;
    }

    // Always expose this function immediately so inline onclick handlers never throw ReferenceError
    window.diorSwitchTab = switchPatientTab;

    function initPatientMainTabNavigation() {
        var app = document.getElementById('dior-patient-portal-app');
        if (!app) return;

        // Delegated listener means dynamically rendered buttons also work.
        if (!app.__diorPatientNavBound) {
            app.__diorPatientNavBound = true;
            app.addEventListener('click', function (event) {
                var btn = event.target.closest('.dior-nav-btn[data-tab]');
                if (!btn || !app.contains(btn)) return;

                var tabId = btn.getAttribute('data-tab');
                if (!tabId) return;

                event.preventDefault();

                if (tabId === 'appointments') {
                    if (typeof window.diorToggleApptDropdown === 'function') {
                        window.diorToggleApptDropdown(event);
                    } else {
                        var w = document.getElementById('dior-appt-dropdown-wrap');
                        if (w) {
                            var isOpen = w.classList.contains('open');
                            if (isOpen) {
                                w.classList.remove('open');
                                diorSetApptToggleIcon(w, false);
                            } else {
                                w.classList.add('open');
                                diorSetApptToggleIcon(w, true);
                                switchPatientTab('appointments');
                                if (typeof window.diorSwitchApptSubTab === 'function') {
                                    window.diorSwitchApptSubTab('book');
                                }
                            }
                        }
                    }
                } else {
                    switchPatientTab(tabId);
                }
            }, true);
        }

        // Direct support for submenu links.
        app.querySelectorAll('[data-appt-subtab]').forEach(function (link) {
            if (link.__diorPatientSubtabBound) return;
            link.__diorPatientSubtabBound = true;
            link.addEventListener('click', function (event) {
                event.preventDefault();
                switchPatientTab('appointments');
                if (typeof window.diorSwitchApptSubTab === 'function') {
                    window.diorSwitchApptSubTab(link.getAttribute('data-appt-subtab'));
                }
            });
        });

        // Restore hash only when it points to an actual panel.
        var hash = diorInitialHash || window.location.hash || '';
        if (hash.indexOf('#tab=') === 0) {
            var raw = hash.substring(5);
            var requested = raw;
            var requestedSub = null;
            if (raw.indexOf('&subtab=') !== -1) {
                var p = raw.split('&subtab=');
                requested = decodeURIComponent(p[0]);
                requestedSub = decodeURIComponent(p[1]);
            } else {
                requested = decodeURIComponent(raw);
            }
            if (document.getElementById('tab-' + requested)) {
                switchPatientTab(requested, false);
                if (requested === 'appointments' && typeof window.diorSwitchApptSubTab === 'function') {
                    var s = requestedSub || (function(){
                        try { return sessionStorage.getItem('dior_active_appt_subtab'); } catch(e){ return null; }
                    })() || 'today';
                    window.diorSwitchApptSubTab(s);
                } else if (window.history && window.history.replaceState) {
                    // Keep the address bar showing the restored page without adding
                    // a history entry (deep links stay valid and shareable).
                    var desiredHash = '#tab=' + encodeURIComponent(requested);
                    if (window.location.hash !== desiredHash) {
                        window.history.replaceState(null, '', desiredHash);
                    }
                }
            }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPatientMainTabNavigation);
    } else {
        initPatientMainTabNavigation();
    }
}());

// Appointment submenu fallback for Patient Dashboard.
document.addEventListener('click', function (event) {
    const link = event.target.closest('[data-appt-subtab]');
    if (!link) return;
    event.preventDefault();
    if (typeof window.diorSwitchTab === 'function') window.diorSwitchTab('appointments');
    if (typeof window.diorSwitchApptSubTab === 'function') window.diorSwitchApptSubTab(link.getAttribute('data-appt-subtab'));
}, false);


/* v17.2.1: prescription details use a clean native Bootstrap modal. */
(function () {
  'use strict';
  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"]/g, function (ch) {
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }
  window.diorViewRxDetails = function (rxId, fallbackMed, fallbackInst) {
    var list = Array.isArray(window.dior_patient_rxs_data) ? window.dior_patient_rxs_data : [];
    var found = null;
    list.some(function (rx) {
      var ids = [rx.id].concat(Array.isArray(rx.raw_ids) ? rx.raw_ids : []).map(String);
      if (ids.some(function (id) { return id.toLowerCase() === String(rxId).toLowerCase(); })) { found = rx; return true; }
      return false;
    });
    var rx = found || {};
    var title = rx.title || rx.name || rx.medication || fallbackMed || 'Prescription';
    var instruction = rx.instructions || rx.sig || fallbackInst || 'No additional instructions available.';
    var prescribedBy = rx.prescribed_by || rx.doctor_name || '—';
    var date = rx.date_prescribed || rx.date || rx.created_at || '—';
    var status = rx.status || rx.routing_status || '—';
    var modal = document.getElementById('dior-bootstrap-rx-details-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'dior-bootstrap-rx-details-modal';
      modal.className = 'modal fade';
      modal.tabIndex = -1;
      modal.setAttribute('aria-labelledby', 'dior-bootstrap-rx-details-title');
      modal.setAttribute('aria-hidden', 'true');
      modal.innerHTML = '<div class="modal-dialog modal-dialog-centered"><div class="modal-content border-0 shadow"><div class="modal-header"><div><h5 class="modal-title" id="dior-bootstrap-rx-details-title">Prescription Details</h5><div class="small text-muted">Review the medication information below</div></div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><dl class="row mb-0"><dt class="col-sm-4">Prescription ID</dt><dd class="col-sm-8" data-rx-field="id"></dd><dt class="col-sm-4">Medication</dt><dd class="col-sm-8 fw-semibold" data-rx-field="title"></dd><dt class="col-sm-4">Prescribed by</dt><dd class="col-sm-8" data-rx-field="doctor"></dd><dt class="col-sm-4">Date prescribed</dt><dd class="col-sm-8" data-rx-field="date"></dd><dt class="col-sm-4">Status</dt><dd class="col-sm-8" data-rx-field="status"></dd><dt class="col-sm-4">Instructions</dt><dd class="col-sm-8" data-rx-field="instructions"></dd></dl></div><div class="modal-footer"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button></div></div></div>';
      document.body.appendChild(modal);
    }
    modal.querySelector('[data-rx-field="id"]').textContent = rx.id || rxId || '—';
    modal.querySelector('[data-rx-field="title"]').textContent = title;
    modal.querySelector('[data-rx-field="doctor"]').textContent = prescribedBy;
    modal.querySelector('[data-rx-field="date"]').textContent = date;
    modal.querySelector('[data-rx-field="status"]').textContent = status;
    modal.querySelector('[data-rx-field="instructions"]').textContent = instruction;
    if (window.bootstrap && window.bootstrap.Modal) window.bootstrap.Modal.getOrCreateInstance(modal).show();
    else { modal.classList.add('show'); modal.style.display = 'block'; modal.removeAttribute('aria-hidden'); }
  };
})();

/* Health Goals Modal & Dynamic Actions (100% Bootstrap 5) */
(function () {
  'use strict';

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"]/g, function (ch) {
      return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
    });
  }

  function getAjaxUrl() {
    return (window.dior_patient_dashboard && window.dior_patient_dashboard.ajax_url) || (window.dior_vars && window.dior_vars.ajax_url) || '/wp-admin/admin-ajax.php';
  }

  function getNonce() {
    return (window.dior_patient_dashboard && window.dior_patient_dashboard.portal_nonce) || (window.dior_vars && window.dior_vars.nonce) || '';
  }

  function updateModalGoalsList(goals) {
    var modalList = document.getElementById('dior-modal-goals-list');
    if (!modalList) return;
    if (!goals || goals.length === 0) {
      modalList.innerHTML = '<tr><td colspan="4" class="text-center py-3 text-muted small">No goals recorded yet.</td></tr>';
      return;
    }
    var html = '';
    goals.forEach(function (g, idx) {
      var pct = Math.min(100, Math.max(0, parseInt(g.pct || 0, 10)));
      html += '<tr>';
      html += '  <td class="ps-3 py-2 fw-semibold text-dark small">' + esc(g.name) + '</td>';
      html += '  <td class="py-2 text-secondary small">' + esc(g.val) + '</td>';
      html += '  <td class="py-2 text-center text-secondary small">' + pct + '%</td>';
      html += '  <td class="pe-3 py-2 text-end"><button type="button" class="btn btn-sm btn-link text-danger p-0 border-0 text-decoration-none dior-modal-del-goal-btn fw-semibold small" data-goal-index="' + idx + '">Delete</button></td>';
      html += '</tr>';
    });
    modalList.innerHTML = html;
  }

  function renderGoalsList(goals) {
    var container = document.getElementById('dior-goals-card-body');
    if (!container) return;
    if (!goals || goals.length === 0) {
      container.innerHTML = '<div class="text-center py-4 text-muted small" id="dior-no-goals-msg">No health goals set yet. Click the <strong>+</strong> button above to add your goals.</div>';
      updateModalGoalsList(goals);
      return;
    }

    var html = '';
    goals.forEach(function (goal, idx) {
      var pct = Math.min(100, Math.max(0, parseInt(goal.pct || 0, 10)));
      html += '<div class="goal mb-2" data-goal-index="' + idx + '">';
      html += '  <div class="d-flex justify-content-between align-items-center mb-1">';
      html += '    <span class="fw-bold text-dark small">' + esc(goal.name) + '</span>';
      html += '    <span class="text-secondary small">' + esc(goal.val) + '</span>';
      html += '  </div>';
      html += '  <div class="progress dior-progress-sm rounded-pill bg-light">';
      html += '    <div class="progress-bar rounded-pill dior-progress-orange" role="progressbar" style="width: ' + pct + '%;" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"></div>';
      html += '  </div>';
      html += '</div>';
    });
    container.innerHTML = html;
    updateModalGoalsList(goals);
  }

  document.addEventListener('DOMContentLoaded', function () {
    // Quick goal pills in modal
    document.querySelectorAll('.dior-quick-goal').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var name = this.getAttribute('data-name');
        var val = this.getAttribute('data-val');
        var pct = this.getAttribute('data-pct');
        var nameInput = document.getElementById('goal_name');
        var valInput = document.getElementById('goal_val');
        var pctInput = document.getElementById('goal_pct');
        if (nameInput && name) nameInput.value = name;
        if (valInput && val) valInput.value = val;
        if (pctInput && pct) pctInput.value = pct;
      });
    });

    // Form submission
    var form = document.getElementById('dior-form-add-health-goal');
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var alertBox = document.getElementById('dior-goal-form-alert');
        if (alertBox) { alertBox.classList.add('d-none'); alertBox.textContent = ''; }

        var submitBtn = document.getElementById('dior-btn-save-goal');
        var origText = submitBtn ? submitBtn.innerHTML : 'Save Vitals & Goal';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span> Saving...';
        }

        var heightInput = document.getElementById('goal_height');
        var weightInput = document.getElementById('goal_weight');
        var goalNameInput = document.getElementById('goal_name');
        var goalValInput = document.getElementById('goal_val');
        var goalPctInput = document.getElementById('goal_pct');

        var height = (heightInput ? heightInput.value : '').trim();
        var weight = (weightInput ? weightInput.value : '').trim();
        var goalName = (goalNameInput ? goalNameInput.value : '').trim();
        var goalVal = (goalValInput ? goalValInput.value : '').trim();
        var goalPct = parseInt(goalPctInput ? goalPctInput.value : '50', 10);

        var body = new URLSearchParams({
          action: 'dior_patient_add_health_goal',
          nonce: getNonce(),
          height: height,
          weight: weight,
          goal_name: goalName,
          goal_val: goalVal,
          goal_pct: isNaN(goalPct) ? 50 : Math.min(100, Math.max(0, goalPct))
        });

        fetch(getAjaxUrl(), {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: body.toString()
        })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origText;
          }
          if (data && data.success) {
            // Clear goal specific fields
            if (goalNameInput) goalNameInput.value = '';
            if (goalValInput) goalValInput.value = '';
            if (goalPctInput) goalPctInput.value = '50';

            var modalEl = document.getElementById('diorHealthGoalsModal');
            if (modalEl && window.bootstrap && window.bootstrap.Modal) {
              var inst = window.bootstrap.Modal.getInstance(modalEl);
              if (inst) inst.hide();
            }

            // Update patient card metrics dynamically
            if (data.data && typeof data.data.height_display !== 'undefined') {
              var hElem = document.getElementById('dior-patient-metric-height');
              if (hElem) hElem.textContent = data.data.height_display;
            }
            if (data.data && typeof data.data.weight_display !== 'undefined') {
              var wElem = document.getElementById('dior-patient-metric-weight');
              if (wElem) wElem.textContent = data.data.weight_display;
            }
            if (heightInput && data.data && typeof data.data.height !== 'undefined') {
              heightInput.value = data.data.height;
            }
            if (weightInput && data.data && typeof data.data.weight !== 'undefined') {
              weightInput.value = data.data.weight;
            }

            renderGoalsList(data.data.goals || []);

            if (typeof Swal !== 'undefined') {
              Swal.fire({
                icon: 'success',
                title: 'Saved Successfully!',
                text: (data.data && data.data.message) ? data.data.message : 'Your vitals and health goals have been updated.',
                timer: 1800,
                showConfirmButton: false
              });
            }
          } else {
            var msg = (data && data.data && data.data.message) ? data.data.message : 'Failed to save health goal.';
            if (alertBox) {
              alertBox.textContent = msg;
              alertBox.classList.remove('d-none');
            } else if (typeof Swal !== 'undefined') {
              Swal.fire({ icon: 'error', title: 'Error', text: msg });
            } else {
              alert(msg);
            }
          }
        })
        .catch(function () {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = origText;
          }
          if (alertBox) {
            alertBox.textContent = 'Network or server error. Please try again.';
            alertBox.classList.remove('d-none');
          }
        });
      });
    }

    // Delete goal event delegation (handles modal delete buttons & card delete buttons)
    document.addEventListener('click', function (e) {
      var delBtn = e.target.closest('.dior-delete-goal-btn, .dior-modal-del-goal-btn');
      if (!delBtn) return;
      e.preventDefault();
      var goalIndex = delBtn.getAttribute('data-goal-index');
      if (goalIndex === null || goalIndex === undefined) return;

      var doDelete = function () {
        var body = new URLSearchParams({
          action: 'dior_patient_delete_health_goal',
          nonce: getNonce(),
          goal_index: goalIndex
        });

        fetch(getAjaxUrl(), {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: body.toString()
        })
        .then(function (res) { return res.json(); })
        .then(function (data) {
          if (data && data.success) {
            renderGoalsList(data.data.goals || []);
          }
        });
      };

      if (typeof Swal !== 'undefined') {
        Swal.fire({
          title: 'Remove Goal?',
          text: 'Are you sure you want to remove this health goal?',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#DC2626',
          confirmButtonText: 'Yes, remove',
          cancelButtonText: 'Cancel'
        }).then(function (result) {
          if (result.isConfirmed) {
            doDelete();
          }
        });
      } else if (confirm('Are you sure you want to remove this health goal?')) {
        doDelete();
      }
    });
  });
})();



/**
 * Patient Today Appointments actions.
 * Uses the existing secured WordPress appointment AJAX endpoints.
 */
(function () {
    if (window.__diorTodayAppointmentActionsBound) return;
    window.__diorTodayAppointmentActionsBound = true;

    // The Appointments entry follows the Doctor Dashboard's affordance: a
    // +/− icon that flips with the menu state.
    function diorSetApptToggleIcon(wrap, isOpen) {
        if (!wrap) return;
        var icon = wrap.querySelector('.submenu-icon');
        if (!icon) return;
        icon.classList.toggle('fa-minus', !!isOpen);
        icon.classList.toggle('fa-plus', !isOpen);
    }

    function getAppointmentAjaxConfig() {
        const config = window.dior_patient_dashboard || window.dior_vars || {};
        return {
            url: config.ajax_url || '/wp-admin/admin-ajax.php',
            nonce: config.portal_nonce || config.nonce || ''
        };
    }

    function sendAppointmentAction(action, fields) {
        const config = getAppointmentAjaxConfig();
        const body = new URLSearchParams(Object.assign({
            action: action,
            nonce: config.nonce
        }, fields || {}));

        return fetch(config.url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        }).then(function (response) {
            return response.json();
        });
    }

    function showAppointmentMessage(type, title, message) {
        if (window.Swal) {
            return Swal.fire({ icon: type, title: title, text: message });
        }
        window.alert(message || title);
        return Promise.resolve();
    }

    // Builds the reschedule dialog. The dashboard runs on the Bootstrap alert
    // shim (window.Swal) rather than SweetAlert2, and that shim has no
    // preConfirm / showValidationMessage support, so the form lives here as a
    // plain markup block and validates itself before sending the AJAX call.
    function rescheduleTodayAppointment(button) {
        const uid = (button.getAttribute('data-appt-uid') || '').trim();
        if (!uid) return;

        const currentDate = (button.getAttribute('data-appt-date') || '').trim();
        const currentTime = (button.getAttribute('data-appt-time') || '').trim();

        if (!window.Swal) {
            showAppointmentMessage('error', 'Unavailable', 'Appointment rescheduling requires the dashboard dialog component.');
            return;
        }

        const today = new Date();
        const minDate = today.getFullYear() + '-' +
            String(today.getMonth() + 1).padStart(2, '0') + '-' +
            String(today.getDate()).padStart(2, '0');

        // Only prefill values the date/time inputs can actually display. The
        // row templates hand over a display time ("02:00 PM"), so normalise it
        // to the 24-hour value an <input type="time"> expects.
        const dateValue = /^\d{4}-\d{2}-\d{2}$/.test(currentDate) && currentDate >= minDate ? currentDate : '';
        let timeValue = '';
        const timeMatch = currentTime.match(/^\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s*$/);
        if (timeMatch) {
            let hours = parseInt(timeMatch[1], 10);
            const minutes = timeMatch[2];
            const suffix = timeMatch[3] ? timeMatch[3].toUpperCase() : '';
            if (suffix === 'PM' && hours < 12) hours += 12;
            if (suffix === 'AM' && hours === 12) hours = 0;
            if (hours >= 0 && hours <= 23) {
                timeValue = String(hours).padStart(2, '0') + ':' + minutes;
            }
        }

        Swal.fire({
            title: 'Reschedule Appointment',
            html:
                '<div class="dior-reschedule-body">' +
                    '<label class="dior-reschedule-label" for="dior-reschedule-date">New date</label>' +
                    '<input id="dior-reschedule-date" class="dior-reschedule-field" type="date" min="' + minDate + '" value="' + dateValue + '">' +
                    '<label class="dior-reschedule-label" for="dior-reschedule-time">New time</label>' +
                    '<input id="dior-reschedule-time" class="dior-reschedule-field" type="time" value="' + timeValue + '">' +
                    '<p class="dior-reschedule-error" role="alert" style="display:none;"></p>' +
                '</div>',
            showCancelButton: true,
            confirmButtonText: 'Confirm Reschedule',
            cancelButtonText: 'Keep Current Time',
            customClass: {
                popup: 'dior-meeting-swal-popup',
                confirmButton: 'dior-bs-btn-confirm',
                cancelButton: 'dior-bs-btn-cancel'
            },
            didOpen: function (modalEl) {
                const dateInput = modalEl.querySelector('#dior-reschedule-date');
                const timeInput = modalEl.querySelector('#dior-reschedule-time');
                const confirmBtn = modalEl.querySelector('.dior-bs-btn-confirm');
                const errorEl = modalEl.querySelector('.dior-reschedule-error');

                if (!dateInput || !timeInput || !confirmBtn) return;

                function showError(message) {
                    if (!errorEl) return;
                    errorEl.textContent = message;
                    errorEl.style.display = 'block';
                }

                function clearError() {
                    if (!errorEl) return;
                    errorEl.textContent = '';
                    errorEl.style.display = 'none';
                }

                function submit() {
                    const date = dateInput.value;
                    const time = timeInput.value;

                    clearError();
                    if (!date || !time) {
                        showError('Please select both a new date and a new time.');
                        return;
                    }
                    if (date < minDate) {
                        showError('Appointment date cannot be in the past.');
                        return;
                    }

                    freshConfirm.disabled = true;
                    freshConfirm.textContent = 'Rescheduling\u2026';

                    sendAppointmentAction('dior_patient_reschedule_appointment', {
                        appt_id: uid,
                        date: date,
                        time: time
                    }).then(function (response) {
                        if (!response || !response.success) {
                            throw new Error(response && response.data && response.data.message ? response.data.message : 'Unable to reschedule this appointment.');
                        }
                        if (window.Swal && typeof Swal.close === 'function') {
                            Swal.close();
                        }
                        return showAppointmentMessage('success', 'Appointment Rescheduled', response.data.message || 'Your appointment has been rescheduled.')
                            .then(function () { window.location.reload(); });
                    }).catch(function (error) {
                        freshConfirm.disabled = false;
                        freshConfirm.textContent = 'Confirm Reschedule';
                        showError(error.message || 'Please try again.');
                    });
                }

                // The shim already bound its own confirm handler (it resolves
                // the dialog without looking at the fields). Swapping the node
                // for a clone drops those listeners so only our validating
                // handler remains.
                const freshConfirm = confirmBtn.cloneNode(true);
                confirmBtn.parentNode.replaceChild(freshConfirm, confirmBtn);
                freshConfirm.addEventListener('click', function (event) {
                    event.preventDefault();
                    submit();
                });

                [dateInput, timeInput].forEach(function (input) {
                    input.addEventListener('input', clearError);
                    input.addEventListener('keydown', function (event) {
                        if (event.key === 'Enter') {
                            event.preventDefault();
                            submit();
                        }
                    });
                });

                dateInput.focus();
            }
        });
    }

    function cancelTodayAppointment(button) {
        const uid = (button.getAttribute('data-appt-uid') || '').trim();
        if (!uid) return;

        const confirm = window.Swal
            ? Swal.fire({
                icon: 'warning',
                title: 'Cancel Appointment?',
                text: 'Are you sure you want to cancel this appointment?',
                input: 'text',
                inputLabel: 'Cancellation reason (optional)',
                inputPlaceholder: 'Enter a reason',
                showCancelButton: true,
                confirmButtonText: 'Yes, Cancel Appointment',
                cancelButtonText: 'Keep Appointment',
                confirmButtonColor: '#DC2626'
            })
            : Promise.resolve({ isConfirmed: window.confirm('Cancel this appointment?'), value: '' });

        confirm.then(function (result) {
            if (!result.isConfirmed) return;
            button.disabled = true;
            return sendAppointmentAction('dior_patient_cancel_appointment', {
                appt_id: uid,
                reason: (result.value || 'Cancelled by patient')
            }).then(function (response) {
                if (!response || !response.success) {
                    throw new Error(response && response.data && response.data.message ? response.data.message : 'Unable to cancel this appointment.');
                }
                return showAppointmentMessage('success', 'Appointment Cancelled', response.data.message || 'Your appointment has been cancelled.')
                    .then(function () { window.location.reload(); });
            }).catch(function (error) {
                button.disabled = false;
                showAppointmentMessage('error', 'Cancellation Failed', error.message || 'Please try again.');
            });
        });
    }

    document.addEventListener('click', function (event) {
        // The Overview consultation card carries its own Reschedule button; it
        // opens the same dialog as the Appointments tab rows instead of just
        // switching tabs and leaving the patient to hunt for the row.
        const cardReschedule = event.target.closest('.dior-card-reschedule');
        if (cardReschedule) {
            event.preventDefault();
            rescheduleTodayAppointment(cardReschedule);
            return;
        }

        const rescheduleButton = event.target.closest('.dior-today-reschedule');
        if (rescheduleButton) {
            event.preventDefault();
            rescheduleTodayAppointment(rescheduleButton);
            return;
        }

        const cancelButton = event.target.closest('.dior-today-cancel');
        if (cancelButton) {
            event.preventDefault();
            cancelTodayAppointment(cancelButton);
        }
    });
})();



/* Auto popup modal for joining a video consultation when the doctor connects. */
function diorShowMeetingJoinModal(alert, force) {
    if (!alert || !alert.action_url) return false;
    var joinUrl = alert.action_url;
    if (!/^https?:\/\//i.test(joinUrl)) return false;

    var notifId = alert.id || ('notif_' + String(alert.timestamp || Date.now()));
    if (!force && window.sessionStorage && sessionStorage.getItem('dior_dismissed_meeting_' + notifId)) {
        return false;
    }

    // Gentle notification audio chime
    try {
        var AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
            var ctx = new AudioCtx();
            var osc = ctx.createOscillator();
            var gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.setValueAtTime(587.33, ctx.currentTime);
            osc.frequency.setValueAtTime(880, ctx.currentTime + 0.15);
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);
            osc.start();
            osc.stop(ctx.currentTime + 0.45);
        }
    } catch (e) {}

    var titleText = alert.title || 'Doctor Started Video Consultation';
    var messageText = alert.message || 'Your physician has joined the video consultation room. Click Join Now to enter the meeting.';

    if (window.Swal) {
        Swal.fire({
            title: '<div style="display:flex;align-items:center;justify-content:flex-start;gap:14px;font-size:20px;color:#0f172a;font-weight:700;text-align:left;width:100%;">' +
                     '<div style="width:44px;height:44px;border-radius:12px;background:#ecfdf5;display:flex;align-items:center;justify-content:center;color:#10b981;flex-shrink:0;">' +
                       '<i class="fas fa-video fa-sm"></i>' +
                     '</div>' +
                     '<span style="text-align:left;line-height:1.35;flex-grow:1;">' + titleText + '</span>' +
                   '</div>',
            html: '<div style="text-align:left !important;padding:4px 0 6px 0;color:#475569;font-size:14.5px;line-height:1.6;">' +
                    '<p style="margin:0 0 14px 0;font-weight:400;color:#475569;text-align:left !important;">' + messageText + '</p>' +
                    '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:9px 14px;font-size:13px;color:#64748b;display:inline-flex;align-items:center;gap:8px;text-align:left !important;width:fit-content;max-width:100%;">' +
                        '<i class="fa-solid fa-shield-halved" style="color:#0284c7;font-size:14px;flex-shrink:0;"></i>' +
                        '<span style="text-align:left !important;">Secure HIPAA-Compliant Telehealth Consultation</span>' +
                    '</div>' +
                  '</div>',
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-video me-1.5"></i> Join Now',
            cancelButtonText: '<i class="fas fa-times me-1"></i> Cancel',
            confirmButtonColor: '#00346C',
            cancelButtonColor: '#64748b',
            focusConfirm: true,
            allowOutsideClick: false,
            backdrop: 'rgba(15, 23, 42, 0.65)',
            customClass: {
                popup: 'dior-meeting-swal-popup rounded-4 border-0 shadow-lg',
                confirmButton: 'btn btn-primary btn-lg px-4 py-2.5 rounded-pill shadow-sm fw-bold',
                cancelButton: 'btn btn-outline-secondary btn-lg px-4 py-2.5 rounded-pill shadow-sm ms-2'
            },
            buttonsStyling: false
        }).then(function (result) {
            if (window.sessionStorage) {
                sessionStorage.setItem('dior_dismissed_meeting_' + notifId, '1');
            }
            if (result.isConfirmed) {
                window.open(joinUrl, '_blank', 'noopener');
            }
        });
        return true;
    }

    // Fallback HTML modal
    var modalId = 'dior-meeting-incoming-modal';
    var modalEl = document.getElementById(modalId);
    if (!modalEl) {
        modalEl = document.createElement('div');
        modalEl.id = modalId;
        modalEl.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,0.65);display:flex;align-items:center;justify-content:center;z-index:99999;padding:20px;';
        modalEl.innerHTML = '<div style="background:#fff;border-radius:20px;max-width:480px;width:100%;box-shadow:0 25px 50px -12px rgba(0,0,0,0.25);overflow:hidden;">' +
            '<div style="padding:28px 24px;text-align:left;">' +
                '<div style="display:flex;align-items:center;gap:14px;margin-bottom:16px;">' +
                    '<div style="width:44px;height:44px;border-radius:12px;background:#ecfdf5;display:inline-flex;align-items:center;justify-content:center;color:#10b981;flex-shrink:0;"><i class="fas fa-video fa-sm"></i></div>' +
                    '<h3 style="margin:0;font-size:20px;font-weight:700;color:#0f172a;line-height:1.35;" id="dior-meeting-modal-title"></h3>' +
                '</div>' +
                '<p style="margin:0 0 16px;font-size:14.5px;color:#475569;line-height:1.6;text-align:left;" id="dior-meeting-modal-desc"></p>' +
                '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:9px 14px;font-size:13px;color:#64748b;display:inline-flex;align-items:center;gap:8px;margin-bottom:24px;text-align:left;">' +
                    '<i class="fa-solid fa-shield-halved" style="color:#0284c7;font-size:14px;"></i> <span>Secure HIPAA-Compliant Telehealth Consultation</span>' +
                '</div>' +
                '<div style="display:flex;gap:12px;justify-content:flex-end;">' +
                    '<button type="button" id="dior-meeting-modal-cancel" style="padding:10px 24px;border:1px solid #cbd5e1;background:#fff;color:#475569;border-radius:999px;font-weight:600;cursor:pointer;"><i class="fas fa-times me-1"></i> Cancel</button>' +
                    '<button type="button" id="dior-meeting-modal-join" style="padding:10px 28px;border:none;background:#00346C;color:#fff;border-radius:999px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(0,52,108,0.25);"><i class="fas fa-video me-1.5"></i> Join Now</button>' +
                '</div>' +
            '</div>' +
        '</div>';
        document.body.appendChild(modalEl);
    }
    modalEl.style.display = 'flex';
    var tEl = document.getElementById('dior-meeting-modal-title');
    var dEl = document.getElementById('dior-meeting-modal-desc');
    if (tEl) tEl.textContent = titleText;
    if (dEl) dEl.textContent = messageText;

    var cancelBtn = document.getElementById('dior-meeting-modal-cancel');
    var joinBtn = document.getElementById('dior-meeting-modal-join');
    if (cancelBtn) {
        cancelBtn.onclick = function() {
            modalEl.style.display = 'none';
            if (window.sessionStorage) sessionStorage.setItem('dior_dismissed_meeting_' + notifId, '1');
        };
    }
    if (joinBtn) {
        joinBtn.onclick = function() {
            modalEl.style.display = 'none';
            if (window.sessionStorage) sessionStorage.setItem('dior_dismissed_meeting_' + notifId, '1');
            window.open(joinUrl, '_blank', 'noopener');
        };
    }
    return true;
}

// Real-time patient notification sync (polls the secured existing AJAX endpoint).
(function () {
    if (window.__diorPatientLiveNotifPolling) return;
    window.__diorPatientLiveNotifPolling = true;

    let lastNotificationId = '';
    let requestInFlight = false;

    function pollPatientNotifications() {
        if (requestInFlight || document.hidden) return;

        const config = window.dior_patient_dashboard || window.dior_vars || {};
        const ajaxUrl = config.ajax_url || '/wp-admin/admin-ajax.php';
        const nonce = config.portal_nonce || config.nonce || '';
        if (!nonce) return;

        requestInFlight = true;
        const body = new URLSearchParams({
            action: 'dior_patient_get_live_notifications',
            nonce: nonce,
            last_notif_id: lastNotificationId
        });

        fetch(ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        })
        .then(function (response) { return response.json(); })
        .then(function (response) {
            if (!response || !response.success || !response.data) return;
            const data = response.data;
            const unread = parseInt(data.unread_count, 10) || 0;

            document.querySelectorAll('.patient-unread-badge, .dior-patient-notif-indicator, .dior-notif-indicator').forEach(function (badge) {
                badge.textContent = unread;
                badge.style.display = unread > 0 ? 'inline-flex' : 'none';
            });

            const dropdown = document.getElementById('dior-patient-notif-dd');
            if (dropdown && data.dropdown_html) dropdown.innerHTML = data.dropdown_html;

            const tableBody = document.getElementById('dior-notif-tbody');
            if (tableBody && data.full_html) {
                tableBody.innerHTML = data.full_html;
                if (typeof window.diorRenderNotifPagination === 'function') window.diorRenderNotifPagination();
                if (typeof window.diorUpdateNotifSelectionCount === 'function') window.diorUpdateNotifSelectionCount();
            }

            (Array.isArray(data.new_alerts) ? data.new_alerts : []).forEach(function (alert) {
                var isMeetingAlert = alert && (
                    /video consultation|patient joined|doctor started|meeting ready|telehealth/i.test((alert.title || '') + ' ' + (alert.message || '')) ||
                    (alert.action_url && /(zoom\.us|meet\.google\.com)/i.test(alert.action_url)) ||
                    alert.icon === 'fa-video'
                );
                if (isMeetingAlert) {
                    diorShowMeetingJoinModal(alert);
                    return; // Meeting alerts ONLY show modal with Join Now / Cancel, NEVER auto-redirect
                }
                if (window.Swal && alert && alert.title) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'info',
                        title: alert.title,
                        text: alert.message || 'A new dashboard notification has arrived.',
                        showConfirmButton: false,
                        timer: 8000,
                        timerProgressBar: true
                    });
                }
            });

            if (data.latest_id) lastNotificationId = data.latest_id;
        })
        .catch(function () {})
        .finally(function () { requestInFlight = false; });
    }

    window.setTimeout(pollPatientNotifications, 1800);
    window.setInterval(pollPatientNotifications, 5000);
    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) pollPatientNotifications();
    });
})();

/* ------------------------------------------------------------------
 * Patient Appointments — one pager for all three tables.
 *
 * Previously only the Upcoming and Past tables paginated, they hid
 * rows with inline `display:none` (which the mobile card CSS beats
 * with `display:grid !important`), and the containers they render
 * into did not exist in the markup at all, so nothing was visible.
 *
 * This renderer is the single source of truth: it hides rows with a
 * class, prints "Showing X to Y of Z entries" plus the Doctor
 * Dashboard pager (prev / numbers / next), and pages 10 rows at a
 * time. The old function names stay as thin wrappers so every
 * existing onclick / init call keeps working.
 * ------------------------------------------------------------------ */
(function () {
    var PAGE_SIZE = 10;
    var HIDDEN = 'dior-appt-page-hidden';

    var TABLES = {
        today: { tbody: 'dior-today-appointments-tbody', bar: 'dior-today-pagination', input: 'dior-today-search-input' },
        upcoming: { tbody: 'dior-upcoming-appointments-tbody', bar: 'dior-upcoming-pagination', input: 'dior-upcoming-search-input' },
        past: { tbody: 'dior-past-appointments-tbody', bar: 'dior-past-pagination', input: 'dior-past-search-input' }
    };

    var state = { today: 1, upcoming: 1, past: 1 };

    function matchingRows(cfg) {
        var tbody = document.getElementById(cfg.tbody);
        if (!tbody) return [];
        var input = document.getElementById(cfg.input);
        var needle = input ? (input.value || '').toLowerCase().trim() : '';

        return Array.prototype.filter.call(tbody.querySelectorAll('tr'), function (row) {
            if (!needle) return true;
            return (row.textContent || '').toLowerCase().indexOf(needle) !== -1;
        });
    }

    function render(kind) {
        var cfg = TABLES[kind];
        if (!cfg) return;

        var tbody = document.getElementById(cfg.tbody);
        if (!tbody) return;

        // Clear any legacy inline hiding (it loses to the mobile !important rules).
        Array.prototype.forEach.call(tbody.querySelectorAll('tr'), function (row) {
            if (row.style.display) row.style.display = '';
            row.classList.add(HIDDEN);
        });

        var active = matchingRows(cfg);
        var total = active.length;
        var totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        var page = Math.min(Math.max(1, parseInt(state[kind], 10) || 1), totalPages);
        state[kind] = page;

        var start = (page - 1) * PAGE_SIZE;
        var end = Math.min(start + PAGE_SIZE, total);

        active.slice(start, end).forEach(function (row) {
            row.classList.remove(HIDDEN);
        });

        var bar = document.getElementById(cfg.bar);
        if (!bar) return;

        if (total <= PAGE_SIZE) {
            bar.style.display = 'none';
            bar.innerHTML = '';
            return;
        }

        var nav = (typeof window.diorBuildPagerHtml === 'function')
            ? window.diorBuildPagerHtml(page, totalPages, 'diorApptGoPage_' + kind)
            : '';

        bar.style.display = 'flex';
        bar.innerHTML =
            '<div class="dior-pagination-info">Showing <strong>' + (start + 1) + '</strong> to <strong>' +
            end + '</strong> of <strong>' + total + '</strong> entries</div>' +
            '<div class="dior-pagination-nav">' + nav + '</div>';
    }

    window.diorRenderApptPagination = render;

    Object.keys(TABLES).forEach(function (kind) {
        var suffix = kind.charAt(0).toUpperCase() + kind.slice(1);

        window['diorApptGoPage_' + kind] = function (page) {
            state[kind] = page;
            render(kind);
        };

        // Same names the template's onkeyup / onchange attributes call.
        window['diorFilter' + suffix + 'Appointments'] = function () {
            state[kind] = 1;
            render(kind);
        };

        // Same names the older init / bulk-delete code calls.
        window['diorRender' + suffix + 'Pagination'] = function () {
            render(kind);
        };
    });

    function boot() {
        Object.keys(TABLES).forEach(function (kind) {
            render(kind);

            // Row removal (bulk delete) or insertion must re-page immediately,
            // otherwise a page can stay empty or the pager shows stale numbers.
            var tbody = document.getElementById(TABLES[kind].tbody);
            if (tbody && window.MutationObserver && !tbody.dataset.diorPagerBound) {
                tbody.dataset.diorPagerBound = '1';
                new MutationObserver(function () { render(kind); })
                    .observe(tbody, { childList: true });
            }
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
    window.addEventListener('load', boot);
})();
