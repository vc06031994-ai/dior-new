<div class="dior-wrap dior-patient-portal-wrap" id="dior-patient-portal-app">

    <!-- Top Emergency Banner -->
    <div class="dior-top-emergency-banner">
        This is not for medical emergencies. Call 911 or go to the nearest ER.
    </div>

    <!-- Mobile Drawer Backdrop -->
    <div class="dior-drawer-backdrop" id="dior-drawer-backdrop" onclick="diorCloseMobileDrawer()"></div>

    <div class="dior-app">

        <!-- ============================================================== -->
        <!-- SIDEBAR NAVIGATION -->
        <!-- ============================================================== -->
        <aside class="dior-side" id="dior-sidebar">
            <div class="dior-side-header">
                <div class="brand">
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="brand-link">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical" class="brand-logo">
                    </a>
                </div>
                <!-- Close control for the mobile drawer. Hidden on desktop by the
                     stylesheet, shown while the drawer is open, and wired to the
                     same close helper as the backdrop. -->
                <button type="button" class="dior-side-close btn" id="dior-side-close" onclick="diorCloseMobileDrawer()"
                    aria-label="Close sidebar" title="Close menu">&times;</button>
            </div>

            <!-- Navigation Links -->
            <nav class="dior-side-nav">
                <div class="grp">
                    <span class="grp-title">PATIENT MENU</span>
                    <button type="button" class="dior-nav-btn active btn" data-tab="overview">
                        <i class="fas fa-gauge-high"></i>
                        <span class="nav-label">Dashboard</span>
                    </button>
                    <?php
                    // Same structure and class contract as the Doctor Dashboard's
                    // Appointments menu (dior-nav-item / dior-submenu / submenu-btn /
                    // submenu-icon) so the dropdown inherits the doctor styling —
                    // indented list, +/− affordance, white hover row — at every
                    // breakpoint instead of being styled separately.
                    ?>
                    <div class="dior-nav-item has-submenu dior-nav-item-has-children" id="dior-appt-dropdown-wrap">
                        <button type="button" class="dior-nav-btn btn" data-tab="appointments"
                            onclick="if(typeof window.diorToggleApptDropdown==='function'){window.diorToggleApptDropdown(event);}">
                            <i class="far fa-calendar-check"></i>
                            <span class="nav-label">Appointments</span>
                            <i class="fas fa-plus submenu-icon"></i>
                        </button>
                        <div class="dior-submenu dior-nav-dropdown">
                            <a href="#tab=appointments&subtab=book" class="dior-nav-btn submenu-btn dior-nav-dropdown-item active" data-appt-subtab="book"><i
                                    class="fas fa-calendar-plus"></i><span class="nav-label">Book Appointment</span></a>
                            <a href="#tab=appointments&subtab=today" class="dior-nav-btn submenu-btn dior-nav-dropdown-item" data-appt-subtab="today"><i
                                    class="fas fa-calendar-day"></i><span class="nav-label">Today Appointments</span></a>
                            <a href="#tab=appointments&subtab=upcoming" class="dior-nav-btn submenu-btn dior-nav-dropdown-item" data-appt-subtab="upcoming"><i
                                    class="fas fa-calendar-week"></i><span class="nav-label">Upcoming Appointments</span></a>
                            <a href="#tab=appointments&subtab=past" class="dior-nav-btn submenu-btn dior-nav-dropdown-item" data-appt-subtab="past"><i
                                    class="fas fa-clock-rotate-left"></i><span class="nav-label">Past Appointments</span></a>
                        </div>
                    </div>
                    <button type="button" class="dior-nav-btn btn" data-tab="docs_meds">
                        <i class="fas fa-prescription-bottle-medical"></i>
                        <span class="nav-label">Prescriptions</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="telemedicine">
                        <i class="fas fa-video"></i>
                        <span class="nav-label">Telemedicine</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="medical_record">
                        <i class="fas fa-notes-medical"></i>
                        <span class="nav-label">Medical Record</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="payments">
                        <i class="fas fa-wallet"></i>
                        <span class="nav-label">Billing &amp; Payment</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="insurance">
                        <i class="fas fa-shield-heart"></i>
                        <span class="nav-label">Insurance Claim</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="documents">
                        <i class="fas fa-file-lines"></i>
                        <span class="nav-label">Documents &amp; Report</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="emergency">
                        <i class="fas fa-kit-medical"></i>
                        <span class="nav-label">Emergency support</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="feedback">
                        <i class="fas fa-comments"></i>
                        <span class="nav-label">Feedback &amp; Support</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="notifications">
                        <i class="fas fa-bell"></i>
                        <span class="nav-label">Notification</span>
                    </button>
                    <button type="button" class="dior-nav-btn btn" data-tab="settings">
                        <i class="fas fa-gear"></i>
                        <span class="nav-label">Settings</span>
                    </button>

                    <!-- Collapse / Expand Sidebar Toggle (matches the Doctor Dashboard) -->
                    <button type="button" class="dior-nav-btn dior-patient-collapse-btn btn"
                        id="dior-patient-sidebar-toggle" onclick="diorTogglePatientSidebarCollapse(event)"
                        title="Collapse Menu">
                        <i class="fas fa-angles-left collapse-icon" id="dior-patient-collapse-icon"></i>
                        <span class="nav-label">Collapse Menu</span>
                    </button>
                </div>
            </nav>
            <script>
                function diorTogglePatientSidebarCollapse(e) {
                    if (e) {
                        if (e.preventDefault) e.preventDefault();
                        if (e.stopPropagation) e.stopPropagation();
                    }
                    var app = document.getElementById('dior-patient-portal-app');
                    if (!app) return;

                    var isCollapsed = app.classList.toggle('dior-sidebar-collapsed');
                    var icon = document.getElementById('dior-patient-collapse-icon');
                    var btn = document.getElementById('dior-patient-sidebar-toggle');

                    if (icon) {
                        if (isCollapsed) {
                            icon.classList.remove('fa-angles-left');
                            icon.classList.add('fa-angles-right');
                        } else {
                            icon.classList.remove('fa-angles-right');
                            icon.classList.add('fa-angles-left');
                        }
                    }
                    if (btn) {
                        var label = btn.querySelector('.nav-label');
                        if (isCollapsed) {
                            btn.setAttribute('title', 'Expand Menu');
                            if (label) label.textContent = 'Expand Menu';
                        } else {
                            btn.setAttribute('title', 'Collapse Menu');
                            if (label) label.textContent = 'Collapse Menu';
                        }
                    }

                    try {
                        localStorage.setItem('dior_patient_sidebar_collapsed', isCollapsed ? '1' : '0');
                    } catch (err) { }

                    // Let responsive widgets re-fit after the width transition.
                    setTimeout(function () {
                        window.dispatchEvent(new Event('resize'));
                    }, 280);
                }

                // Restore the saved collapsed state on load (desktop only).
                (function () {
                    try {
                        if (localStorage.getItem('dior_patient_sidebar_collapsed') === '1' && window.innerWidth >= 1025) {
                            var app = document.getElementById('dior-patient-portal-app');
                            if (app) {
                                app.classList.add('dior-sidebar-collapsed');
                                var icon = document.getElementById('dior-patient-collapse-icon');
                                var btn = document.getElementById('dior-patient-sidebar-toggle');
                                if (icon) {
                                    icon.classList.remove('fa-angles-left');
                                    icon.classList.add('fa-angles-right');
                                }
                                if (btn) {
                                    btn.setAttribute('title', 'Expand Menu');
                                    var label = btn.querySelector('.nav-label');
                                    if (label) label.textContent = 'Expand Menu';
                                }
                            }
                        }
                    } catch (e) { }
                })();
            </script>

            <!-- Bottom Sidebar User Profile Card -->
            <div class="dior-sidebar-bottom-profile">
                <div class="dior-sidebar-avatar-wrap" id="dior-sidebar-avatar-box">
                    <?php if (!empty($profile['avatar_url'])): ?>
                        <img id="dior-sidebar-avatar-img" src="<?php echo esc_url($profile['avatar_url']); ?>"
                            alt="<?php echo esc_attr($profile['full_name']); ?>">
                    <?php else: ?>
                        <img id="dior-sidebar-avatar-img"
                            src="<?php echo esc_url(get_avatar_url(get_current_user_id(), ['size' => 120])); ?>"
                            alt="<?php echo esc_attr($profile['full_name'] ?? 'User'); ?>">
                    <?php endif; ?>
                </div>
                <div class="dior-sidebar-user-info">
                    <strong
                        class="dior-sidebar-user-name"><?php echo esc_html(!empty($profile['full_name']) ? $profile['full_name'] : 'Mia Song'); ?></strong>
                    <span class="dior-sidebar-user-status">Available</span>
                </div>
            </div>
        </aside>

        <!-- ============================================================== -->
        <!-- MAIN CONTENT AREA -->
        <!-- ============================================================== -->
        <main class="dior-main-content">

            <!-- Top Bar Header -->
            <header class="dior-topbar">
                <div class="dior-topbar-left">
                    <button type="button" class="dior-mobile-menu-toggle btn" id="dior-mobile-menu-toggle"
                        onclick="diorOpenMobileDrawer()" aria-label="Open navigation menu">
                        <i class="fas fa-bars"></i>
                    </button>

                    <!-- Search Bar (Clean Reference UI) -->
                    <div class="dior-top-search" id="dior-patient-top-search">
                        <i class="fas fa-magnifying-glass"></i>
                        <input type="text" id="dior-patient-search"
                            placeholder="Search appointments, prescriptions, records...">
                    </div>
                </div>

                <div class="dior-topbar-right">
                    <!-- Notification Bell Dropdown -->
                    <div class="dior-notif-wrap" id="dior-notif-dropdown-wrap">
                        <button type="button" class="dior-notif-btn btn" onclick="diorToggleNotifDropdown(event)"
                            aria-label="Notifications">
                            <i class="fas fa-bell"></i>
                            <?php if ($unread_count > 0): ?>
                                <span class="dior-notif-indicator unread-badge-count"><?php echo $unread_count; ?></span>
                            <?php endif; ?>
                        </button>
                        <div class="dior-notif-dropdown" id="dior-notif-dropdown">
                            <div class="dior-notif-header">
                                <h4>Notifications</h4>
                                <button type="button" id="dior-quick-mark-read">Mark all read</button>
                            </div>
                            <div class="dior-notif-list">
                                <?php if (empty($notifications)): ?>
                                    <div class="dior-ic-00e4601aa1">
                                        <i class="fas fa-bell-slash dior-ic-41fd079087"></i>
                                        No new notifications
                                    </div>
                                <?php else: ?>
                                    <?php foreach (array_slice($notifications, 0, 5) as $n):
                                        $target_tab = !empty($n['action_url']) ? str_replace('#tab=', '', $n['action_url']) : 'notifications';
                                        ?>
                                        <div class="dior-notif-item <?php echo empty($n['is_read']) ? 'unread' : ''; ?>"
                                            data-notif-id="<?php echo esc_attr($n['id']); ?>"
                                            data-switch-tab="<?php echo esc_attr($target_tab); ?>"
                                            data-action-url="<?php echo esc_attr($n['action_url'] ?? ''); ?>"
                                            data-title="<?php echo esc_attr($n['title'] ?? ''); ?>"
                                            data-message="<?php echo esc_attr($n['message'] ?? ''); ?>"
                                            data-icon="<?php echo esc_attr($n['icon'] ?? ''); ?>"
                                            class="dior-ic-7f6191e48d" style="cursor:pointer;">
                                            <div class="notif-icon"><i
                                                    class="fas <?php echo esc_attr($n['icon'] ?? 'fa-bell'); ?>"></i></div>
                                            <div class="notif-body">
                                                <strong><?php echo esc_html($n['title']); ?></strong>
                                                <p><?php echo esc_html(mb_substr($n['message'], 0, 45) . (mb_strlen($n['message']) > 45 ? '...' : '')); ?>
                                                </p>
                                                <span
                                                    class="notif-time"><?php echo esc_html(dior_format_notification_time($n)); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="dior-notif-footer">
                                <button type="button" data-switch-tab="notifications">View All &rarr;</button>
                            </div>
                        </div>
                    </div>

                    <!-- User Quick Profile Pill & Dropdown -->
                    <div class="dior-user-pill-wrap">
                        <button type="button" class="dior-user-pill-btn btn" onclick="diorToggleProfileDropdown(event)"
                            aria-label="User Profile">
                            <div class="dior-user-pill-card">
                                <div class="dior-pill-avatar" id="dior-top-pill-avatar">
                                    <?php if (!empty($profile['avatar_url'])): ?>
                                        <img id="dior-topbar-avatar-img"
                                            src="<?php echo esc_url($profile['avatar_url']); ?>"
                                            alt="<?php echo esc_attr($profile['full_name']); ?>">
                                    <?php else: ?>
                                        <img id="dior-topbar-avatar-img"
                                            src="<?php echo esc_url(get_avatar_url(get_current_user_id(), ['size' => 120])); ?>"
                                            alt="<?php echo esc_attr($profile['full_name'] ?? 'User'); ?>">
                                    <?php endif; ?>
                                    <span class="dior-online-dot"></span>
                                </div>
                                <div class="dior-pill-user-meta">
                                    <strong
                                        class="dior-pill-user-name"><?php echo esc_html(!empty($profile['full_name']) ? $profile['full_name'] : 'Mia Song'); ?></strong>
                                    <span class="dior-pill-user-status">Available</span>
                                </div>
                            </div>
                        </button>

                        <div class="dior-profile-dropdown" id="dior-profile-dropdown">
                            <div class="dior-profile-dropdown-header">
                                HELLO <?php echo esc_html(strtoupper($profile['full_name'])); ?>..
                            </div>
                            <ul class="dior-profile-dropdown-menu">
                                <li>
                                    <button type="button" data-switch-tab="settings">
                                        <i class="far fa-user"></i> Profile
                                    </button>
                                </li>
                                <li>
                                    <button type="button" data-switch-tab="settings">
                                        <i class="far fa-envelope"></i> Email
                                    </button>
                                </li>
                                <li>
                                    <button type="button" data-switch-tab="settings">
                                        <i class="fas fa-gear"></i> Settings
                                    </button>
                                </li>
                                <li>
                                    <a href="<?php echo esc_url(wp_logout_url(dior_portal_login_url())); ?>"
                                        class="dior-logout-text-btn">
                                        <i class="fas fa-arrow-right-from-bracket"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>

            <!-- TAB PANELS CONTAINER -->
            <div class="dior-tab-container">

                <?php
                $is_prof_complete = Dior_Patient_Portal_Data::is_profile_complete($user_id);
                $missing_fields_list = Dior_Patient_Portal_Data::get_missing_profile_fields($user_id);
                ?>
                <?php if (!$is_prof_complete): ?>
                    <!-- Action Required Alert Banner for Incomplete Profile -->
                    <div class="dior-profile-incomplete-alert dior-ic-c03948b3c3" id="dior-profile-incomplete-banner">
                        <div class="dior-ic-29bdac4ec4">
                            <div class="dior-ic-3fb01cc77f">
                                <i class="fas fa-user-pen"></i>
                            </div>
                            <div>
                                <strong class="dior-ic-11190ca3a8">
                                    Action Required: Complete Your Personal Profile
                                </strong>
                                <span class="dior-ic-acb9b5ec47">
                                    Please complete your required personal information
                                    (<strong><?php echo esc_html(implode(', ', $missing_fields_list)); ?></strong>) to
                                    unlock appointment booking and telehealth consultations.
                                </span>
                            </div>
                        </div>
                        <button type="button" class="dior-btn-gold-primary dior-ic-4ee0445c2a btn"
                            onclick="diorOpenHipaaPopup()">
                            <i class="fas fa-id-card"></i> Complete Profile Now
                        </button>
                    </div>
                <?php endif; ?>

                <!-- ============================================================== -->
                <!-- 0. HOME / OVERVIEW TAB (Real Functional Patient Data + Clean UI) -->
                <!-- ============================================================== -->
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/overview.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/_design-static-data.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/settings.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/appointments.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/payments.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/insurance.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/docs_meds.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/telemedicine.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/medical_record.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/documents.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/emergency.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/questionnaire.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/feedback.php'; ?>
                <?php include DIOR_PORTAL_PATH . 'templates/patient-tabs/notifications.php'; ?>

            </div> <!-- /.dior-tab-container -->

        </main>
    </div> <!-- /.dior-app -->


    <!-- ============================================================== -->
    <!-- MODALS -->
    <!-- ============================================================== -->

    <!-- 1. BOOK NEW APPOINTMENT MODAL (HIPAAtizer Form Integrated) -->
    <div class="dior-modal-overlay" id="modal-book-appointment">
        <div class="dior-modal-dialog dior-modal-lg dior-ic-ee0c6b0194">
            <div class="dior-modal-header dior-ic-78529f928a">
                <div>
                    <h3 class="dior-ic-66a69ef8e4"><i class="fas fa-calendar-plus"></i> Book New Visit</h3>
                    <span class="dior-ic-23927a389b"><i class="fas fa-shield-heart dior-ic-236b5f0eb0"></i>
                        HIPAA-Compliant Medical Intake &amp; Booking</span>
                </div>
                <button type="button" class="dior-modal-close btn"
                    onclick="diorCloseModal('modal-book-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body dior-ic-1d15569872">
                <iframe id="hipaatizer-book-visit-iframe"
                    src="https://app.hipaatizer.com/workflow/01a11515-b491-79dc-b59b-e4be2a345a49"
                    allow="microphone; camera; payment" title="HIPAAtizer Booking Form" class="dior-ic-a52858ae73">
                </iframe>
                <div class="dior-ic-44a70a0420">
                    <?php echo do_shortcode('[hipaatizer id="01a11515-b491-79dc-b59b-e4be2a345a49"]'); ?>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. RESCHEDULE MODAL -->
    <div class="dior-modal-overlay" id="modal-reschedule-appointment">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="far fa-calendar"></i> Reschedule Consultation</h3>
                <button type="button" class="dior-modal-close btn"
                    onclick="diorCloseModal('modal-reschedule-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-reschedule-appt">
                    <input type="hidden" id="resched_appt_id" name="appt_id" value="">

                    <div id="resched_appt_summary" class="dior-ic-f8cd81dec3">
                    </div>

                    <p class="modal-intro-text">Select a new date and available time slot for your appointment:</p>

                    <div class="dior-form-row-2">
                        <div class="dior-form-group">
                            <label for="resched_date">New Date <span class="req">*</span></label>
                            <input type="date" id="resched_date" name="date" min="<?php echo current_time('Y-m-d'); ?>"
                                value="<?php echo current_time('Y-m-d'); ?>" required>
                        </div>
                        <div class="dior-form-group">
                            <label for="resched_time">New Time Slot <span class="req">*</span></label>
                            <select id="resched_time" name="time" required>
                                <option value="09:00 AM PST">09:00 AM PST</option>
                                <option value="10:15 AM PST">10:15 AM PST</option>
                                <option value="11:30 AM PST">11:30 AM PST</option>
                                <option value="01:00 PM PST">01:00 PM PST</option>
                                <option value="02:30 PM PST">02:30 PM PST</option>
                                <option value="04:00 PM PST">04:00 PM PST</option>
                                <option value="05:30 PM PST">05:30 PM PST</option>
                                <option value="07:00 PM PST">07:00 PM PST</option>
                            </select>
                        </div>
                    </div>

                    <div class="dior-form-group dior-ic-fb6bc20a7f">
                        <label for="resched_notes">Reason for Rescheduling (Optional)</label>
                        <input type="text" id="resched_notes" name="notes"
                            placeholder="e.g. Schedule conflict, personal travel"
                            class="dior-ic-3638e808c4 form-control">
                    </div>

                    <div class="dior-modal-footer dior-ic-78874ad7d4">
                        <button type="button" class="dior-btn-gold-secondary btn"
                            onclick="diorCloseModal('modal-reschedule-appointment')">Keep Current Time</button>
                        <button type="submit" id="dior-btn-submit-resched" class="dior-btn-gold-primary btn">
                            <i class="fas fa-check"></i> Save New Time Slot
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 3. CANCEL APPOINTMENT MODAL -->
    <div class="dior-modal-overlay" id="modal-cancel-appointment">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="fas fa-kit-medical dior-ic-557c97e141"></i> Cancel Consultation</h3>
                <button type="button" class="dior-modal-close btn"
                    onclick="diorCloseModal('modal-cancel-appointment')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-cancel-appt">
                    <input type="hidden" id="cancel_appt_id" name="appt_id" value="">

                    <div id="cancel_appt_summary" class="dior-ic-e7416a9b55">
                    </div>

                    <p class="dior-ic-e261ffabcb">
                        Are you sure you wish to cancel this consultation? You can reschedule to a future date at no
                        penalty, or schedule a new visit when needed.
                    </p>

                    <div class="dior-form-group">
                        <label for="cancel_reason">Reason for Cancellation (Optional)</label>
                        <select id="cancel_reason" name="reason">
                            <option value="Schedule conflict">Schedule conflict</option>
                            <option value="Symptoms resolved">Symptoms resolved</option>
                            <option value="Went to in-person clinic">Went to in-person clinic / ER</option>
                            <option value="Provider preference">Provider preference</option>
                            <option value="Other reason">Other reason</option>
                        </select>
                    </div>

                    <div class="dior-modal-footer dior-ic-78874ad7d4">
                        <button type="button" class="dior-btn-gold-secondary btn"
                            onclick="diorCloseModal('modal-cancel-appointment')">Keep Appointment</button>
                        <button type="submit" id="dior-btn-submit-cancel"
                            class="dior-btn-danger dior-ic-02e790ac8d btn">
                            <i class="fas fa-xmark"></i> Confirm Cancellation
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 3B. APPOINTMENT REMINDER MODAL -->
    <div class="dior-modal-overlay" id="modal-appointment-reminder">
        <div class="dior-modal-dialog">
            <div class="dior-modal-header">
                <h3><i class="fas fa-bell dior-ic-b2113a5eea"></i> Send Appointment Reminder</h3>
                <button type="button" class="dior-modal-close btn"
                    onclick="diorCloseModal('modal-appointment-reminder')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-send-reminder">
                    <input type="hidden" id="reminder_appt_id" name="appt_id" value="">

                    <div id="reminder_appt_summary" class="dior-ic-d8b0d6eace">
                    </div>

                    <p class="dior-ic-e261ffabcb">
                        Send an urgent clinical consultation reminder with scheduled date/time, patient preparation
                        checklist, and direct video consultation room link.
                    </p>

                    <div class="dior-ic-2895f37e6b">
                        <div class="dior-ic-55132245a6">
                            <i class="fas fa-tower-broadcast dior-ic-1dc44a1b66"></i> Active
                            Notification Channels:
                        </div>
                        <div class="dior-ic-dce101ce6e">
                            <label class="dior-ic-8b80aded64">
                                <input type="checkbox" checked disabled class="dior-ic-ce15c82e4d form-check-input">
                                <span><strong>Email Notification</strong> (Delivered to both patient & attending
                                    doctor)</span>
                            </label>
                            <label class="dior-ic-8b80aded64">
                                <input type="checkbox" checked disabled class="dior-ic-ce15c82e4d form-check-input">
                                <span><strong>Dashboard In-App Alert</strong> (Added to notification inbox for patient &
                                    doctor)</span>
                            </label>
                        </div>
                    </div>

                    <div class="dior-modal-footer dior-ic-78874ad7d4">
                        <button type="button" class="dior-btn-gold-secondary btn"
                            onclick="diorCloseModal('modal-appointment-reminder')">Close</button>
                        <button type="submit" id="dior-btn-submit-reminder"
                            class="dior-btn-gold-primary dior-ic-2e8ec92046 btn">
                            <i class="fas fa-bell"></i> Send Reminder Now
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 4. QUESTIONNAIRE & INTAKE MODAL (With E-Sign) -->
    <div class="dior-modal-overlay" id="modal-questionnaire-intake">
        <div class="dior-modal-dialog dior-modal-lg">
            <div class="dior-modal-header">
                <h3 id="modal-qn-title"><i class="fas fa-clipboard-question"></i> Clinical Intake & E-Sign</h3>
                <button type="button" class="dior-modal-close btn"
                    onclick="diorCloseModal('modal-questionnaire-intake')">&times;</button>
            </div>
            <div class="dior-modal-body">
                <form id="dior-form-submit-intake" class="dior-portal-form">
                    <input type="hidden" id="qn_input_id" name="qn_id" value="">
                    <input type="hidden" id="qn_input_condition" name="condition" value="">

                    <div class="dior-form-group">
                        <label for="qn_input_symptoms">Describe Your Symptoms & Duration <span
                                class="req">*</span></label>
                        <textarea id="qn_input_symptoms" name="symptoms" rows="3"
                            placeholder="When did symptoms start? Rate severity (mild/moderate/severe)..."
                            required></textarea>
                    </div>

                    <div class="dior-form-row-2">
                        <div class="dior-form-group">
                            <label for="qn_input_allergies">Known Drug Allergies</label>
                            <input type="text" id="qn_input_allergies" name="allergies"
                                placeholder="e.g. Penicillin, Sulfa, None known">
                        </div>
                        <div class="dior-form-group">
                            <label for="qn_input_meds">Current Medications / Supplements</label>
                            <input type="text" id="qn_input_meds" name="current_meds"
                                placeholder="e.g. Lisinopril 10mg, Multivitamin">
                        </div>
                    </div>

                    <div class="dior-form-group">
                        <label for="qn_input_history">Relevant Medical Conditions</label>
                        <input type="text" id="qn_input_history" name="medical_history"
                            placeholder="e.g. Asthma, High Blood Pressure, Diabetes, None">
                    </div>

                    <!-- Document / Photo Upload -->
                    <div class="dior-form-group">
                        <label>Upload Supporting Images / Documents (e.g. Photo of Rash, Previous Lab Test)</label>
                        <div class="dior-upload-dropzone" id="dior-upload-dropzone">
                            <i class="fas fa-cloud-arrow-up"></i>
                            <span>Click to upload or drag and drop image (JPG, PNG, PDF up to 10MB)</span>
                            <input type="file" id="qn_file_upload" name="file_upload" accept="image/*,application/pdf"
                                class="dior-ic-44a70a0420 form-control">
                        </div>
                        <div id="dior-upload-preview" class="dior-ic-7287548b65"></div>
                    </div>

                    <!-- HIPAA Telemedicine Consent & E-Sign Pad -->
                    <div class="dior-esign-section">
                        <h4><i class="fas fa-signature"></i> Telemedicine & HIPAA Consent Agreement</h4>
                        <div class="esign-text-box">
                            <p>By typing your legal name or signing below, you consent to receive telehealth medical
                                evaluations from licensed clinicians at Dior Medical, acknowledge our HIPAA Privacy
                                Practices, and certify that all clinical information provided is true and accurate.</p>
                        </div>

                        <div class="dior-form-row-2">
                            <div class="dior-form-group">
                                <label for="esign_name">Type Full Legal Name (Electronic Signature) <span
                                        class="req">*</span></label>
                                <input type="text" id="esign_name" name="esign_name"
                                    value="<?php echo esc_attr($profile['full_name']); ?>" required>
                            </div>
                            <div class="dior-form-group">
                                <label for="esign_date">Date of Signature</label>
                                <input type="text" id="esign_date" name="esign_date"
                                    value="<?php echo current_time('M j, Y'); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="dior-modal-footer">
                        <button type="button" class="dior-btn-gold-secondary btn"
                            onclick="diorCloseModal('modal-questionnaire-intake')">Cancel</button>
                        <button type="submit" class="dior-btn-gold-primary btn" id="dior-submit-intake-btn">
                            <i class="fas fa-paper-plane"></i> Submit Clinical Intake to Doctor &rarr;
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- 6. VIEW RECEIPT MODAL -->
    <div class="dior-modal-overlay dior-ic-44a70a0420" id="modal-view-receipt">
        <div class="dior-modal-dialog dior-ic-3eca92ddc0">
            <div class="dior-modal-header dior-ic-89e0058b3f">
                <h3 class="dior-ic-b5eb34332b">
                    <i class="fas fa-receipt dior-ic-5d59a9a58e"></i> Telehealth Itemized Receipt
                </h3>
                <button type="button" class="dior-modal-close dior-ic-926a99defe btn"
                    onclick="diorCloseModal('modal-view-receipt')">&times;</button>
            </div>

            <div class="dior-modal-body dior-ic-95a72fdada" id="modal-receipt-content">
                <div class="receipt-printable-box dior-ic-1fb1e87e73">
                    <div class="receipt-logo dior-ic-edaece9d10">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Dior Medical" class="dior-ic-a84efd2f1e">
                    </div>

                    <div class="receipt-title dior-ic-6ce126c779">
                        Official Medical Statement &amp; Receipt
                    </div>

                    <table class="receipt-info-table dior-ic-7bae9c829a table">
                        <tr class="dior-ic-d81e5f9193">
                            <td class="dior-ic-b78f557455">
                                Invoice #:</td>
                            <td id="rec-inv-id" class="dior-ic-c39367f644">INV-8829
                            </td>
                        </tr>
                        <tr class="dior-ic-d81e5f9193">
                            <td class="dior-ic-e2ed1b531d">Date:
                            </td>
                            <td id="rec-date" class="dior-ic-20b442f466">Sept 4, 2026
                            </td>
                        </tr>
                        <tr class="dior-ic-d81e5f9193">
                            <td class="dior-ic-e2ed1b531d">
                                Patient:</td>
                            <td id="rec-patient-info" class="dior-ic-20b442f466">
                                <?php echo esc_html($profile['full_name']); ?>
                                (<?php echo esc_html($profile['patient_id']); ?>)
                            </td>
                        </tr>
                        <tr class="dior-ic-d81e5f9193">
                            <td class="dior-ic-e2ed1b531d">
                                Service:</td>
                            <td id="rec-service" class="dior-ic-20b442f466">Urgent
                                Care Telehealth Consultation</td>
                        </tr>
                        <tr class="dior-ic-d81e5f9193">
                            <td class="dior-ic-e2ed1b531d">
                                Payment Method:</td>
                            <td class="dior-ic-20b442f466">Stripe (Credit Card /
                                Apple Pay)</td>
                        </tr>
                        <tr class="total-row dior-ic-94cd1e6e94">
                            <td class="dior-ic-b9354c61ff">Total
                                Paid:</td>
                            <td id="rec-amount" class="dior-ic-9a1fcd0c50">$49.00</td>
                        </tr>
                    </table>

                    <div class="receipt-footer-note dior-ic-8082556ec6">
                        <i class="fas fa-shield-heart dior-ic-4418794cf4"></i>
                        <span>Dior Medical Telehealth &amp; Urgent Care &bull; Tax ID / NPI Verified &bull; Eligible for
                            HSA/FSA Reimbursement</span>
                    </div>
                </div>
            </div>

            <div class="dior-modal-footer dior-ic-e61c613459">
                <button type="button" class="dior-btn-gold-secondary dior-ic-2cc983c6d0 btn"
                    onclick="diorCloseModal('modal-view-receipt')">Close</button>
                <button type="button" class="dior-btn-gold-secondary dior-ic-fd09076f26 btn"
                    onclick="diorPrintReceiptModal()">
                    <i class="fas fa-print me-1"></i> Print
                </button>
                <button type="button" class="dior-btn-gold-primary dior-ic-99a13c029f btn"
                    onclick="diorDownloadReceiptPdf()">
                    <i class="fas fa-file-arrow-down"></i> Download PDF
                </button>
            </div>
        </div>
    </div>

    <!-- 7. VIEW DOCUMENT MODAL -->
    <div class="dior-modal-overlay dior-ic-44a70a0420" id="modal-view-document">
        <div class="dior-modal-dialog dior-ic-c647d3a0d1">
            <div class="dior-modal-header dior-ic-89e0058b3f">
                <h3 id="doc-modal-header-title" class="dior-ic-b5eb34332b">
                    <i class="fas fa-file-shield dior-ic-5d59a9a58e"></i> Certified Medical Document
                </h3>
                <button type="button" class="dior-modal-close dior-ic-926a99defe btn"
                    onclick="diorCloseModal('modal-view-document')">&times;</button>
            </div>

            <div class="dior-modal-body dior-ic-9f59805fdf">
                <div class="doc-preview-card dior-ic-d3b67ecf4f">

                    <div class="doc-icon-large dior-ic-623e027944">
                        <i class="fas fa-file-pdf"></i>
                    </div>

                    <h4 id="doc-preview-title" class="dior-ic-b59074b5a9">
                        Document Title</h4>

                    <div class="dior-ic-6a49e78bbe">
                        <span id="doc-preview-category" class="dior-ic-0a03b45d9b">Category</span>
                    </div>

                    <div class="doc-details-grid dior-ic-bf2153c7ca">
                        <div>
                            <strong class="dior-ic-b7ab6167a8">Document
                                ID:</strong>
                            <span id="doc-preview-id" class="dior-ic-a6562b0806">DOC-88219</span>
                        </div>
                        <div>
                            <strong class="dior-ic-b7ab6167a8">Date
                                Issued:</strong>
                            <span id="doc-preview-date" class="dior-ic-a6562b0806">Sept
                                4, 2026</span>
                        </div>
                        <div>
                            <strong class="dior-ic-b7ab6167a8">Issued
                                By / Provider:</strong>
                            <span id="doc-preview-author" class="dior-ic-a6562b0806">Dior Medical Clinical
                                Team</span>
                        </div>
                        <div>
                            <strong class="dior-ic-b7ab6167a8">Patient:</strong>
                            <span id="doc-preview-patient"
                                class="dior-ic-a6562b0806"><?php echo esc_html($profile['full_name']); ?></span>
                        </div>
                    </div>

                    <div class="doc-seal dior-ic-3e0fc52c0f">
                        <i class="fas fa-shield-heart dior-ic-e3f2780fa1"></i>
                        <span>Digitally Certified &amp; E-Signed by Dior Medical Telehealth System</span>
                    </div>
                </div>
            </div>

            <div class="dior-modal-footer dior-ic-e90aec0c99">
                <button type="button" class="dior-btn-gold-secondary dior-ic-2cc983c6d0 btn"
                    onclick="diorCloseModal('modal-view-document')">Close</button>
                <button type="button" class="dior-btn-gold-primary dior-ic-99a13c029f btn"
                    onclick="diorDownloadCurrentDocumentPdf()">
                    <i class="fas fa-file-arrow-down"></i> Print / Download PDF
                </button>
            </div>
        </div>
    </div> <!-- /#modal-view-document -->

    <!-- 8. APPOINTMENT DETAIL MODAL (PATIENT PORTAL) -->
    <div class="dior-modal-overlay dior-ic-44a70a0420" id="modal-view-appointment-detail">
        <div class="dior-modal-dialog dior-ic-e9cfd8c2ad">
            <div class="dior-modal-header dior-ic-38b9f470b9">
                <h3 class="dior-ic-55d820b400">
                    <i class="fas fa-calendar-check dior-ic-5d59a9a58e"></i> Appointment Details
                </h3>
                <button type="button" class="dior-modal-close dior-ic-f476a9f033 btn"
                    onclick="diorCloseModal('modal-view-appointment-detail')">&times;</button>
            </div>

            <div class="dior-modal-body dior-ic-82b34f2b62">
                <!-- Hero Info Card -->
                <div class="dior-ic-69035811a2">
                    <div class="dior-ic-5d08ce7ec2">
                        <div>
                            <span id="pat-modal-appt-id" class="dior-ic-808a4fa3c3">APPT-ID</span>
                            <h4 id="pat-modal-appt-provider" class="dior-ic-28d0539f78">Attending Physician
                            </h4>
                            <span id="pat-modal-appt-spec" class="dior-ic-55709c3d5d">Telehealth Urgent
                                Care</span>
                        </div>
                        <span id="pat-modal-appt-status-badge" class="dior-st ok dior-ic-70c5533809">Confirmed</span>
                    </div>

                    <div class="dior-ic-d9dafa9db0">
                        <div>
                            <strong class="dior-ic-3a5e03a707">Date
                                &amp; Time</strong>
                            <span id="pat-modal-appt-datetime" class="dior-ic-035b2e7453">—</span>
                        </div>
                        <div>
                            <strong class="dior-ic-3a5e03a707">Consultation
                                Mode</strong>
                            <span id="pat-modal-appt-mode" class="dior-ic-035b2e7453"><i class="fas fa-video me-1" style="color:#059669;"></i> Video Visit</span>
                        </div>
                        <div class="dior-ic-b652b6f21e">
                            <strong class="dior-ic-3a5e03a707">Service
                                / Clinical Reason</strong>
                            <span id="pat-modal-appt-condition" class="dior-ic-ad42b18349">Telehealth
                                Urgent Care</span>
                        </div>
                    </div>
                </div>

                <!-- Live Zoom Link Strip (if available) -->
                <div id="pat-modal-zoom-wrap" class="dior-ic-5d5fe245c5">
                    <div class="dior-ic-63a4b96787">
                        <div class="dior-ic-99e83aaa9f">
                            <i class="fas fa-video" style="color:#059669;font-size:18px;"></i>
                        </div>
                        <div>
                            <strong class="dior-ic-08abd803b3">Live Virtual Consultation
                                Room</strong>
                            <span class="dior-ic-c243108e79">Join physician on secure Zoom Video</span>
                        </div>
                    </div>
                    <a id="pat-modal-zoom-link" href="#" target="_blank" rel="noopener noreferrer"
                        class="dior-ic-459d58fbd7">
                        <i class="fas fa-video me-1" style="color:#059669;"></i> Join Video Call &rarr;
                    </a>
                </div>

                <!-- Patient & Clinical Notes Card -->
                <div class="dior-ic-a9ce782a97">
                    <h5 class="dior-ic-8277d4959a">
                        <i class="fas fa-notes-medical dior-ic-5d59a9a58e"></i> Clinical Notes &amp;
                        Instructions
                    </h5>
                    <p id="pat-modal-appt-notes" class="dior-ic-d181656743">
                        Standard telehealth clinical consultation scheduled. All submitted medical intake questionnaires
                        are pre-verified.
                    </p>
                </div>

                <div class="dior-ic-3e0fc52c0f">
                    <i class="fas fa-shield-heart dior-ic-e3f2780fa1"></i>
                    <span>HIPAA Compliant &bull; Verified Dior Medical Telehealth Record</span>
                </div>
            </div>

            <div class="dior-modal-footer dior-ic-9b6b762386">
                <button type="button" class="dior-btn-gold-secondary dior-ic-d8eb827f48 btn"
                    onclick="diorCloseModal('modal-view-appointment-detail')">Close</button>
            </div>
        </div>
    </div> <!-- /#modal-view-appointment-detail -->

    <!-- 9. PRESCRIPTION DETAIL MODAL (PATIENT PORTAL) -->
    <div class="dior-modal-overlay dior-ic-9049d9cd09" id="modal-view-rx-detail">
        <div class="dior-modal-dialog dior-ic-e270dbf307">

            <!-- Modal Top Action Header -->
            <div class="dior-modal-header dior-ic-bf0665f2de">
                <div class="dior-ic-2fa3fca1f7">
                    <div>
                        <h3 class="dior-ic-5993936b7f">
                            Official Telehealth Prescription (e-Rx)
                        </h3>
                        <span class="dior-ic-25f3b27ac7">
                            DEA &bull; NPI Registered Practice &bull; Surescripts e-Rx Certified
                        </span>
                    </div>
                </div>
                <button type="button" class="dior-modal-close dior-ic-9305d040bf btn"
                    onclick="diorCloseModal('modal-view-rx-detail')">&times;</button>
            </div>

            <!-- Modal Body: Letterhead Sheet (Image 2, 3, 4) -->
            <div class="dior-modal-body dior-ic-6714f5aeeb">

                <div class="dior-rx-letterhead-sheet dior-ic-cc0172605f">

                    <!-- Top Clinic & Doctor Header (Images 2 & 3) -->
                    <div class="dior-ic-f9030d0190">
                        <div>
                            <div class="dior-rx-doc-name dior-ic-3752d6b3fd" id="pat-modal-rx-doc-header">
                                <span id="pat-modal-rx-doc">Dr. Marcus Sterling, MD</span>
                            </div>
                            <div class="dior-rx-clinic-sub dior-ic-502f59757f">
                                <strong class="dior-ic-25e0cc2c47">DIOR MEDICAL TELEHEALTH &amp; URGENT
                                    CARE</strong><br>
                                Clinical Telemedicine Division &bull; Surescripts e-Rx Certified
                            </div>
                        </div>

                        <!-- Clinic Logo -->
                        <div class="dior-ic-32c53658c7">
                            <?php
                            // /uploads/2026/08/logo.png does not exist on this
                            // install; cropped-logo.png is the real site mark.
                            $disp_logo = !empty($logo_url) ? $logo_url : site_url('/wp-content/uploads/2026/08/cropped-logo.png');
                            ?>
                            <img src="<?php echo esc_url($disp_logo); ?>" alt="Dior Medical"
                                 class="dior-ic-ac19460d69" loading="lazy" decoding="async"
                                 onerror="this.onerror=null;this.style.display='none';">
                        </div>
                    </div>

                    <!-- Barcode & Issuance Line (Image 3) -->
                    <div class="dior-ic-7b94dc2c83">
                        <div class="dior-ic-5fd58752b8">
                            <div>Prescription Date: <span id="pat-modal-rx-date" class="dior-ic-01276c62f3">—</span>
                            </div>
                            <div class="dior-ic-5e92856bee">
                                Unique Rx UID: <strong id="pat-modal-rx-id" class="dior-ic-7b6e16631f">Rx
                                    #ORDER</strong>
                            </div>
                        </div>
                    </div>

                    <!-- Patient Demographics: Classical Prescription Pad Underline Layout (Exact Match to User's Image 2) -->
                    <div class="dior-rx-patient-pad-box dior-ic-4638e80c10">
                        <!-- Row 1: Patient Name & Date -->
                        <div class="dior-ic-06b21f47ad">
                            <div class="dior-ic-afcc30d60e">
                                <span class="dior-ic-0904e4e822">Patient
                                    Name:</span>
                                <span id="pat-modal-rx-pat-name"
                                    class="dior-ic-b252d41b17"><?php echo esc_html(!empty($profile['full_name']) ? $profile['full_name'] : '—'); ?></span>
                            </div>
                            <div class="dior-ic-d866ca125a">
                                <span class="dior-ic-0904e4e822">Date:</span>
                                <span id="pat-modal-rx-pad-date" class="dior-ic-b252d41b17">—</span>
                            </div>
                        </div>

                        <!-- Row 2: Age, Gender, Weight -->
                        <div class="dior-ic-d11db2d048">
                            <div class="dior-ic-7ac7cda799">
                                <span class="dior-ic-0904e4e822">Age:</span>
                                <span id="pat-modal-rx-pat-age" class="dior-ic-b252d41b17"><?php
                                $modal_age = '—';
                                if (!empty($profile['dob'])) {
                                    $modal_dob_timestamp = strtotime($profile['dob']);
                                    if ($modal_dob_timestamp) {
                                        $modal_age_years = (new DateTime('today'))->diff(new DateTime($profile['dob']))->y;
                                        $modal_age = $modal_age_years . ' years';
                                    }
                                }
                                echo esc_html($modal_age);
                                ?></span>
                            </div>
                            <div class="dior-ic-4a82ebc967">
                                <span class="dior-ic-0904e4e822">Gender:</span>
                                <span id="pat-modal-rx-pat-gender"
                                    class="dior-ic-b252d41b17"><?php echo esc_html(!empty($profile['gender']) ? ucfirst($profile['gender']) : '—'); ?></span>
                            </div>
                            <div class="dior-ic-4a82ebc967">
                                <span class="dior-ic-0904e4e822">Weight:</span>
                                <span id="pat-modal-rx-pat-weight"
                                    class="dior-ic-b252d41b17"><?php
                                    $w = !empty($profile['weight']) ? trim($profile['weight']) : '';
                                    echo esc_html($w ? (is_numeric($w) ? $w . ' kg' : $w) : '—');
                                    ?></span>
                            </div>
                        </div>

                        <!-- Row 3: Diagnosis -->
                        <div class="dior-ic-395b20a3ba">
                            <span class="dior-ic-0904e4e822">Diagnosis:</span>
                            <span id="pat-modal-rx-diagnosis" class="dior-ic-956613932b">—</span>
                        </div>
                    </div>

                    <!-- Classical ℞ Prescription Order Bar (Image 3) -->
                    <div class="dior-rx-title-bar">
                        <div class="dior-ic-f725034276">
                            <span class="dior-rx-symbol">&#8478;</span>
                            <span class="dior-ic-0a18e0c67b">
                                Official Prescription Directive
                            </span>
                        </div>
                        <span class="dior-ic-9b6818a37f">
                            Schedule VI / Legend Non-Controlled
                        </span>
                    </div>

                    <!-- Clean Structured Medication Table (Images 3 & 4) -->
                    <table class="dior-rx-med-table table">
                        <thead>
                            <tr>
                                <th class="dior-ic-5ad98bfc70">#</th>
                                <th class="dior-ic-d44a12258f">Medicine Name &amp; Formulation</th>
                                <th class="dior-ic-06e9f6de59">Dosage &amp; Usage Instructions (SIG)</th>
                                <th class="dior-ic-a13ed7aa9b">Dispense / Refills</th>
                            </tr>
                        </thead>
                        <tbody id="pat-modal-rx-table-body">
                            <!-- Populated dynamically via diorViewRxDetails() -->
                        </tbody>
                    </table>

                    <!-- Advice Given / Clinical Instructions (Image 3) -->
                    <div class="dior-rx-advice-card">
                        <div class="dior-rx-advice-title">
                            <i class="fas fa-notes-medical"></i> Advice Given &amp; Clinical Instructions:
                        </div>
                        <div class="dior-rx-advice-body" id="pat-modal-rx-advice">
                            &bull; Take medication strictly as prescribed. Do not exceed the stated dose.<br>
                            &bull; Take with a full glass of water. Avoid alcohol and heavy unprescribed
                            interactions.<br>
                            &bull; If any hypersensitivity, rash, or adverse effect occurs, discontinue immediately and
                            contact the clinic.
                        </div>
                    </div>



                    <?php
                    // The telehealth legal-certification paragraph and the
                    // physician signature block were removed on request: the
                    // sheet is printed by the patient portal, so boilerplate
                    // legal text and an "authorized signature" panel there add
                    // nothing a patient can act on. The document title, Rx UID,
                    // issue date and clinic footer remain.
                    ?>

                    <!-- Letterhead Bottom Clinic Footer Details (Image 2) -->
                    <div class="dior-rx-footer-line">
                        <div>
                            <i class="fas fa-location-dot dior-ic-9043ac3683"></i> 100
                            Medical Plaza, Suite 400 &bull; Dior Medical Telehealth Group
                        </div>
                        <div>
                            <i class="fas fa-phone dior-ic-9043ac3683"></i> (800) 555-DIOR
                            &bull; concierge@diormedical.com
                        </div>
                    </div>

                </div> <!-- /dior-rx-letterhead-sheet -->

            </div> <!-- /dior-modal-body -->

            <!-- Modal Action Footer (Permanently Pinned, Full Visibility) -->
            <div class="dior-modal-footer dior-ic-003eb72b4a">
                <button type="button" id="pat-modal-rx-refill-btn" class="dior-ic-aef0d9cdb6 btn">
                    <i class="fas fa-arrows-rotate dior-ic-1a809d86ac"></i> Request Refill
                </button>
                <div class="dior-ic-6c5b3070b0">
                    <button type="button" id="pat-modal-rx-pdf-btn" class="dior-ic-1d1379760d btn">
                        <i class="fas fa-file-arrow-down"></i> Download Official PDF
                    </button>
                    <button type="button" onclick="diorCloseModal('modal-view-rx-detail')"
                        class="dior-ic-a340556f29 btn">Close</button>
                </div>
            </div>
        </div>
    </div> <!-- /#modal-view-rx-detail -->


</div> <!-- /#dior-patient-portal-app -->
<script>
    // Hipaatizer Popup logic
    function diorLoadHipaaFrame() {
        const frame = document.getElementById('dior-hipaatizer-intake-frame');
        if (!frame) return;
        const target = frame.getAttribute('data-src');
        if (target && frame.getAttribute('src') === 'about:blank') {
            frame.setAttribute('src', target);
        }
    }

    function diorOpenHipaaPopup() {
        const hipaatizerModal = document.getElementById('dior-custom-hipaatizer-modal');
        if (!hipaatizerModal) {
            console.error('HIPAAtizer modal not found!');
            return;
        }
        hipaatizerModal.style.display = 'flex';
        // Start HIPAAtizer only after the modal is visible.
        requestAnimationFrame(function () {
            setTimeout(diorLoadHipaaFrame, 50);
        });
    }

    function diorCloseHipaaModal() {
        const modal = document.getElementById('dior-custom-hipaatizer-modal');
        if (modal) modal.style.display = 'none';
    }

    // Keep the global name used by the registration/dashboard scripts.
    window.diorOpenHipaaPopup = diorOpenHipaaPopup;
    window.diorCloseHipaaModal = diorCloseHipaaModal;
</script>

<style>
    .dior-hipaa-swal.swal2-popup {
        max-width: 950px !important;
        padding: 0 !important;
        border-radius: 12px !important;
        overflow: hidden;
    }

    .dior-hipaa-swal .swal2-title {
        padding: 15px 15px 10px !important;
        margin: 0 !important;
    }

    .dior-hipaa-swal .swal2-html-container {
        padding: 0 !important;
        margin: 0 !important;
    }

    .dior-hipaa-swal .swal2-close {
        background: transparent !important;
        background-color: transparent !important;
        color: #666 !important;
        font-size: 32px !important;
        border: none !important;
        box-shadow: none !important;
        outline: none !important;
        width: 40px !important;
        height: 40px !important;
        border-radius: 50% !important;
        position: absolute !important;
        top: 5px !important;
        right: 5px !important;
    }

    .dior-hipaa-swal .swal2-close:hover {
        color: #d33 !important;
        background-color: transparent !important;
    }
</style>

<!-- Hidden Intake Form Overlay -->
<div id="dior-custom-hipaatizer-modal"
    style="display:none; position:fixed; inset:0; width:100vw; height:100vh; background:rgba(0,0,0,0.8); z-index:999999; justify-content:center; align-items:center;">
    <div
        style="width:min(950px, 95vw); height:90vh; background:#fff; border-radius:12px; position:relative; overflow:hidden;">
        <button type="button" onclick="diorCloseHipaaModal();" aria-label="Close HIPAAtizer form"
            style="position:absolute; right:15px; top:10px; font-size:32px; line-height:1; color:#666; background:#fff; border:none; cursor:pointer; z-index:10000;">&times;</button>
        <div id="hipaatizer-inject-target" style="width:100%; height:100%; padding:20px; box-sizing:border-box;">
            <!-- Load HIPAAtizer only after the dashboard modal becomes visible. This avoids the
                 HIPAAtizer loader getting initialized while its parent is display:none. -->
            <iframe id="dior-hipaatizer-intake-frame" title="HIPAAtizer Clinical Intake & Questionnaire Form"
                src="about:blank" data-src="https://app.hipaatizer.com/workflow/01a11515-b491-79dc-b59b-e4be2a345a49"
                allow="microphone; camera; payment"
                style="display:block; width:100%; height:100%; min-height:700px; border:0; background:#fff;"
                loading="eager"></iframe>
        </div>
    </div>
</div>
